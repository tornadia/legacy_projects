/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#include "definitions.h"

#include <QtGui>
#include <QtNetwork>
#include <QTcpSocket>

#include "iplist.h"
#include "statusreader.h"

IPList::IPList(QWidget* _parent)
	: QDialog(_parent)
{
	parent = (UserInterface*)_parent;

	/* Window Title */
	setWindowTitle("IP List");

	/* Menu */
	QMenuBar* menuBar = new QMenuBar;
	QMenu* fileMenu = new QMenu("&File", this);
	QAction* openAction = new QAction("&Open", this);
	QAction* saveAction = new QAction("&Save", this);
	QAction* saveAsAction = new QAction("Save &As...", this);
	QAction* closeAction = new QAction("&Close", this);
	openAction->setShortcut(tr("Ctrl+O"));
	saveAction->setShortcut(tr("Ctrl+S"));
	saveAsAction->setShortcut(tr("Ctrl+F12"));
	closeAction->setShortcut(tr("Ctrl+Q"));
	fileMenu->addAction(openAction);
	fileMenu->addSeparator();
	fileMenu->addAction(saveAction);
	fileMenu->addAction(saveAsAction);
	fileMenu->addSeparator();
	fileMenu->addAction(closeAction);
	connect(openAction, SIGNAL(triggered()), this, SLOT(loadList()));
	connect(saveAction, SIGNAL(triggered()), this, SLOT(saveList()));
	connect(saveAsAction, SIGNAL(triggered()), this, SLOT(saveAs()));
	connect(closeAction, SIGNAL(triggered()), this, SLOT(close()));
	menuBar->addMenu(fileMenu);

	/* Interface */
	QLabel* ipLabel = new QLabel("IP:");
	ipEdit = new QLineEdit;
	ipEdit->setMaxLength(30);
	ipLabel->setBuddy(ipEdit);

	QLabel* portLabel = new QLabel("Port:");
	portEdit = new QLineEdit;
	portEdit->setValidator(new QIntValidator(0, 65535, portEdit));
	portEdit->setMaxLength(5);
	portEdit->setStatusTip("Server port");
	portLabel->setBuddy(portEdit);

	QPushButton* addButton = new QPushButton("Add Server");
	QPushButton* refreshAllButton = new QPushButton("Refresh All");
	refreshButton = new QPushButton("Refresh Server");
	editButton = new QPushButton("Edit Server");
	removeButton = new QPushButton("Remove Server");
	selectButton = new QPushButton("Select");

	/* Table List */
	table = new TableModel(this);

	QSortFilterProxyModel* proxyModel = new QSortFilterProxyModel(this);
	proxyModel->setSourceModel(table);
	proxyModel->setDynamicSortFilter(true);

	tableView = new QTableView;
	tableView->setModel(proxyModel);
	tableView->setSortingEnabled(true);
	tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
	tableView->horizontalHeader()->setStretchLastSection(true);
	tableView->verticalHeader()->hide();
	tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
	tableView->setSelectionMode(QAbstractItemView::SingleSelection);

	proxyModel->sort(0, Qt::AscendingOrder);

	QLabel* connectLabel = new QLabel(tr("&Connect Timeout:"));
	connectEdit = new QLineEdit;
	connectEdit->setValidator(new QIntValidator(10, 5000, portEdit));
	connectEdit->setMaxLength(4);
	connectEdit->setStatusTip(tr("Connection timeout"));
#ifdef WIN32
	connectEdit->setMinimumWidth(30);
	connectEdit->setMaximumWidth(40);
#else
	connectEdit->setMinimumWidth(45);
	connectEdit->setMaximumWidth(55);
#endif
	connectLabel->setBuddy(portEdit);

	QLabel* writeLabel = new QLabel(tr("&Write Timeout:"));
	writeEdit = new QLineEdit;
	writeEdit->setValidator(new QIntValidator(10, 5000, portEdit));
	writeEdit->setMaxLength(4);
	writeEdit->setStatusTip(tr("Write timeout"));
#ifdef WIN32
	writeEdit->setMinimumWidth(30);
	writeEdit->setMaximumWidth(40);
#else
	writeEdit->setMinimumWidth(45);
	writeEdit->setMaximumWidth(55);
#endif
	writeLabel->setBuddy(portEdit);

	QLabel* readLabel = new QLabel(tr("&Read Timeout:"));
	readEdit = new QLineEdit;
	readEdit->setValidator(new QIntValidator(10, 5000, portEdit));
	readEdit->setMaxLength(4);
	readEdit->setStatusTip(tr("Write timeout"));
#ifdef WIN32
	readEdit->setMinimumWidth(30);
	readEdit->setMaximumWidth(40);
#else
	readEdit->setMinimumWidth(45);
	readEdit->setMaximumWidth(55);
#endif
	readLabel->setBuddy(portEdit);

	connect(addButton, SIGNAL(clicked()),
		this, SLOT(addServer()));

	connect(refreshAllButton, SIGNAL(clicked()),
		this, SLOT(refreshAll()));

	connect(refreshButton, SIGNAL(clicked()),
		this, SLOT(refreshServer()));

	connect(editButton, SIGNAL(clicked()),
		this, SLOT(editServer()));

	connect(removeButton, SIGNAL(clicked()),
		this, SLOT(removeServer()));

	connect(selectButton, SIGNAL(clicked()),
		this, SLOT(selectServer()));

	connect(tableView->selectionModel(), SIGNAL(selectionChanged(const QItemSelection&, const QItemSelection&)),
		this, SLOT(changedSelection(const QItemSelection&)));

	QGridLayout* layout = new QGridLayout;
	layout->setMenuBar(menuBar);
	layout->addWidget(ipLabel, 0, 0, 1, 1);
	layout->addWidget(ipEdit, 1, 0, 1, 1);
	layout->addWidget(portLabel, 2, 0, 1, 1);
	layout->addWidget(portEdit, 3, 0, 1, 1);
	layout->addWidget(addButton, 4, 0, 1, 1);
	layout->addWidget(refreshAllButton, 5, 0, 1, 1);
	layout->addWidget(refreshButton, 6, 0, 1, 1);
	layout->addWidget(editButton, 7, 0, 1, 1);
	layout->addWidget(removeButton, 8, 0, 1, 1);
	layout->addWidget(tableView, 0, 1, 7, 6);
	layout->addWidget(connectLabel, 7, 1, 1, 1);
	layout->addWidget(connectEdit, 7, 2, 1, 1);
	layout->addWidget(writeLabel, 7, 3, 1, 1);
	layout->addWidget(writeEdit, 7, 4, 1, 1);
	layout->addWidget(readLabel, 7, 5, 1, 1);
	layout->addWidget(readEdit, 7, 6, 1, 1);
	layout->addWidget(selectButton, 8, 1, 1, 6);
	setLayout(layout);

	refreshButton->setEnabled(false);
	editButton->setEnabled(false);
	removeButton->setEnabled(false);
	selectButton->setEnabled(false);

	readSettings();
}

QString IPList::transformUptime(unsigned int uptime)
{
	unsigned int hours = uptime / 3600;
	unsigned int minutes = (uptime % 3600) / 60;
	return tr("%1h & ").arg(hours) + tr("%1m").arg(minutes);
}

QString IPList::transformPlayers(unsigned int players, unsigned int playersMax)
{
	return tr("%1 / ").arg(players) + tr("%1").arg(playersMax);
}

connectionError_t IPList::getServerData(QString& host, unsigned short port, QString& uptime, QString& players)
{
	QTcpSocket* clientSocket = new QTcpSocket(this);

	clientSocket->connectToHost(host, port);
	if (!clientSocket->waitForConnected(connectEdit->text().toUShort())) {
		clientSocket->close();
		return FAILED_TO_CONNECT;
	}

	//TODO: Use the other serverinfo status protocol (0x03 0x00 0xFF 0x01 0x--)
	QByteArray packet;
	packet.resize(8);

	//packet headers
	packet[0] = packet.size() - 2;
	packet[1] = 0x00;

	packet[2] = 0xFF; // Status protocol
	packet[3] = 0xFF; // XML server info

	char info[5] = "info";
	for(int i = 4; i < 8; i++)
		packet[i] = info[i - 4];

	clientSocket->write(packet);
	if (!clientSocket->waitForBytesWritten(writeEdit->text().toUShort())) {
		clientSocket->close();
		return FAILED_TO_WRITE;
	}

	if (!clientSocket->waitForReadyRead(readEdit->text().toUShort())) {
		clientSocket->close();
		return FAILED_TO_READ;
	}

	QByteArray XMLData = clientSocket->readAll();
	clientSocket->close();

	StatusReader handler;
	QXmlInputSource source;
	source.setData(XMLData);

	QXmlSimpleReader reader;
	reader.setContentHandler(&handler);
	reader.parse(source);

	uptime = transformUptime(handler.getUptime().toInt());
	players = transformPlayers(handler.getPlayers().toInt(), handler.getPlayersMax().toInt());

	return CONNECTION_SUCCESS;
}

void IPList::addServer(const QString& _ip, const QString& _port, QString players, QString uptime, bool load)
{
	QString ip;
	QString port;
	if (!_ip.isEmpty()) {
		ip = _ip;
		port = _port;
	} else if (!ipEdit->text().isEmpty() && !portEdit->text().isEmpty()) {
		ip = ipEdit->text();
		port = portEdit->text();
	} else {
		return;
	}

	IPQList list = table->getList();
	IPQPair pair(ip, port.toInt());
	if (list.contains(pair)) {
		QMessageBox::information(this, "Duplicate Server", tr("The server \"%1:%2\" already exists.").arg(ip, port));
		return;
	}

	if (!load)
		parent->addServer(ip, port);

	table->insertRows(0, 1, QModelIndex());
	tableView->setRowHeight(0, 15);

	table->setData(table->index(0, 0, QModelIndex()), ip, Qt::EditRole);
	table->setData(table->index(0, 1, QModelIndex()), port, Qt::EditRole);

	switch (getServerData(ip, port.toInt(), uptime, players)) {
		case FAILED_TO_WRITE:
		case FAILED_TO_CONNECT:
			uptime = "Offline";
			players = "0 / 0";

		default:
			break;
	}

	table->setData(table->index(0, 2, QModelIndex()), players, Qt::EditRole);
	table->setData(table->index(0, 3, QModelIndex()), uptime, Qt::EditRole);
	entriesCount++;
}

void IPList::editServer()
{
	QItemSelectionModel* selectionModel = tableView->selectionModel();
	QSortFilterProxyModel* proxy = (QSortFilterProxyModel*)selectionModel->model();
	QModelIndexList indexes = selectionModel->selectedRows();

	QString newIP = ipEdit->text();
	QString newPort = portEdit->text();

	int row = proxy->mapToSource(selectionModel->selectedRows()[0]).row();
	QString currentIP = table->data(table->index(row, 0, QModelIndex()), Qt::DisplayRole).toString();
	QString currentPort = table->data(table->index(row, 1, QModelIndex()), Qt::DisplayRole).toString();

	IPQList list = table->getList();
	IPQPair pair(newIP, newPort.toInt());
	if (list.contains(pair)) {
		QMessageBox::information(this, "Duplicate Server", tr("The server \"%1:%2\" already exists.").arg(newIP, newPort));
		return;
	}

	parent->editServer(currentIP, currentPort, newIP, newPort);

	table->setData(table->index(row, 0, QModelIndex()), newIP, Qt::EditRole);
	table->setData(table->index(row, 1, QModelIndex()), newPort, Qt::EditRole);

	QString uptime = "N/A";
	QString players = "N/A";

	switch (getServerData(newIP, newPort.toUShort(), uptime, players)) {
		case FAILED_TO_WRITE:
		case FAILED_TO_CONNECT:
			uptime = "Offline";
			players = "0 / 0";

		default:
			break;
	}

	table->setData(table->index(row, 2, QModelIndex()), players, Qt::EditRole);
	table->setData(table->index(row, 3, QModelIndex()), uptime, Qt::EditRole);
}

void IPList::removeServer()
{
	if (table->getList().size() == 1) {
		return;
	}

	QItemSelectionModel* selectionModel = tableView->selectionModel();
	QSortFilterProxyModel* proxy = (QSortFilterProxyModel*)selectionModel->model();
	int row = proxy->mapToSource(selectionModel->selectedRows()[0]).row();
	QString ip = table->data(table->index(row, 0, QModelIndex()), Qt::DisplayRole).toString();
	QString port = table->data(table->index(row, 1, QModelIndex()), Qt::DisplayRole).toString();
	table->removeRows(row, 1, QModelIndex());
	parent->removeServer(ip, port);
}

void IPList::selectServer()
{
	QItemSelectionModel* selectionModel = tableView->selectionModel();
	QSortFilterProxyModel* proxy = (QSortFilterProxyModel*)selectionModel->model();

	int row = proxy->mapToSource(selectionModel->selectedRows()[0]).row();
	parent->selectServer(table->data(table->index(row, 0, QModelIndex()), Qt::DisplayRole).toString(),
		table->data(table->index(row, 1, QModelIndex()), Qt::DisplayRole).toString());

	close();
}

void IPList::refreshServer()
{
	QItemSelectionModel* selectionModel = tableView->selectionModel();
	QSortFilterProxyModel* proxy = (QSortFilterProxyModel*)selectionModel->model();
	QModelIndexList indexes = selectionModel->selectedRows();

	int row = proxy->mapToSource(selectionModel->selectedRows()[0]).row();
	QString ip = table->data(table->index(row, 0, QModelIndex()), Qt::DisplayRole).toString();
	QString port = table->data(table->index(row, 1, QModelIndex()), Qt::DisplayRole).toString();
	QString uptime = "N/A";
	QString players = "N/A";

	switch (getServerData(ip, port.toInt(), uptime, players)) {
		case FAILED_TO_READ:
			return;

		case FAILED_TO_WRITE:
		case FAILED_TO_CONNECT:
			uptime = "Offline";
			players = "0 / 0";

		default:
			break;
	}

	table->setData(table->index(row, 2, QModelIndex()), players, Qt::EditRole);
	table->setData(table->index(row, 3, QModelIndex()), uptime, Qt::EditRole);
}

void IPList::refreshAll()
{
	int ipListSize = table->getList().size();
	for (int j = 0; j < ipListSize; ++j) {
		QString ip = table->data(table->index(j, 0, QModelIndex()), Qt::DisplayRole).toString();

		QString uptime = "N/A", players = "N/A";
		switch (getServerData(ip, table->data(table->index(j, 1, QModelIndex()), Qt::DisplayRole).toInt(), uptime, players)) {
			case FAILED_TO_READ:
				continue;

			case FAILED_TO_WRITE:
			case FAILED_TO_CONNECT:
				uptime = "Offline";
				players = "0 / 0";

			default:
				break;
		}

		table->setData(table->index(j, 2, QModelIndex()), players, Qt::EditRole);
		table->setData(table->index(j, 3, QModelIndex()), uptime, Qt::EditRole);
	}
}

void IPList::readSettings()
{
	QSettings settings;

	tableView->setColumnWidth(0, settings.value("ipwidth", 150).toInt());
	tableView->setColumnWidth(1, settings.value("portwidth", 52).toInt());
	tableView->setColumnWidth(2, settings.value("playerswidth", 69).toInt());
	tableView->setColumnWidth(3, settings.value("uptimewidth", 67).toInt());

	connectEdit->setText(settings.value("connecttimeout", "250").toString());
	writeEdit->setText(settings.value("writetimeout", "250").toString());
	readEdit->setText(settings.value("readtimeout", "250").toString());

	int size = settings.beginReadArray("iplist"), i;
	for (i = 0; i < size; i++) {
		settings.setArrayIndex(i);
		addServer(settings.value("ip").toString(), settings.value("port").toString(), settings.value("players").toString(), settings.value("uptime").toString(), true);
	}
	settings.endArray();

	if (i == 0) {
		addServer("softcores.otland.net", "7171", "N/A", "N/A", true);
		addServer("icechaw.otland.net", "7171", "N/A", "N/A", true);
		addServer("twinforce.otland.net", "7171", "N/A", "N/A", true);
	}
}

void IPList::writeSettings()
{
	QSettings settings;
	settings.setValue("ipwidth", tableView->columnWidth(0));
	settings.setValue("portwidth", tableView->columnWidth(1));
	settings.setValue("playerswidth", tableView->columnWidth(2));
	settings.setValue("uptimewidth", tableView->columnWidth(3));

	settings.setValue("connecttimeout", connectEdit->text());
	settings.setValue("writetimeout", writeEdit->text());
	settings.setValue("readtimeout", readEdit->text());

	settings.remove("iplist");

	IPQList ipList = table->getList();
	ServerDataQList sList = table->getServerDataList();
	settings.beginWriteArray("iplist");
	int ipListSize = ipList.size();
	for (int i = 0; i < ipListSize; ++i) {
		settings.setArrayIndex(i);
		settings.setValue("ip", ipList.at(i).first);
		settings.setValue("port", ipList.at(i).second);
		settings.setValue("players", sList.at(i).first);
		settings.setValue("uptime", sList.at(i).second);
	}
	settings.endArray();
}

void IPList::changedSelection(const QItemSelection& selection)
{
	QItemSelectionModel* selectionModel = tableView->selectionModel();
	QSortFilterProxyModel* proxy = (QSortFilterProxyModel*)selectionModel->model();

	bool b = !selectionModel->selectedRows().isEmpty();
	refreshButton->setEnabled(b);
	removeButton->setEnabled(b);
	selectButton->setEnabled(b);
	editButton->setEnabled(b);

	int row = proxy->mapToSource(selectionModel->selectedRows()[0]).row();
	ipEdit->setText(table->data(table->index(row, 0, QModelIndex()), Qt::DisplayRole).toString());
	portEdit->setText(table->data(table->index(row, 1, QModelIndex()), Qt::DisplayRole).toString());
}

void IPList::loadList()
{
	QString fileName = QFileDialog::getOpenFileName(this, "Open List", "", "IP List (*.ipl)");
	if (fileName.isEmpty())
		return;

	QFile file(fileName);
	if (!file.open(QIODevice::ReadOnly)) {
		QMessageBox::information(this, "Unable to load list", file.errorString());
		return;
	}

	parent->setLoadedIPList(fileName);

	IPQList pairs = table->getList();

	QDataStream in(&file);
	in >> pairs;
	file.close();

	if (pairs.isEmpty()) {
		QMessageBox::information(this, "IP List is empty",
			"The file you are trying to load does not contain any entries.");
		return;
	}

	for (int i = pairs.size() - 1; i != -1; --i) {
		IPQPair p = pairs.at(i);
		QString port;
		port.setNum(p.second);
		addServer(p.first, port, 0, 0, true);
	}
}

void IPList::saveList()
{
	QString fileName = parent->getLoadedIPList();
	if (fileName.isEmpty()) {
		saveAs();
		return;
	}

	QFile file(fileName);
	if (!file.open(QIODevice::WriteOnly)) {
		QMessageBox::information(this, "Unable to write to list", file.errorString());
		return;
	}

	QDataStream out(&file);
	out << table->getList();
	file.close();
}

void IPList::saveAs()
{
	QString fileName = QFileDialog::getSaveFileName(this, "Save List", "", "IP List (*.ipl)");
	if (fileName.isEmpty())
		return;

	parent->setLoadedIPList(fileName);
	saveList();
}

void IPList::closeEvent(QCloseEvent* event)
{
	writeSettings();
	event->accept();
}
