/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#include "definitions.h"

#include <QFile>
#include <QProcess>
#include <QSettings>

#include <QMessageBox>

#include "tibiaclient.h"

#ifndef WIN32
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#endif

struct ClientData
{
	int rsaAddr;
	int ipAddr;
	short loginServers;
}
m_address[CLIENT_VERSION_LAST + 1];

ErrorMessage_t TibiaClient::replaceHost(const char* ip, unsigned short port)
{
	if (!getClient())
		return ERROR_CLIENT_NOT_FOUND;

	if (!setProcess())
		return ERROR_PROCESS_NOT_FOUND;

	const ClientVersion_t version = getClientVersion();
	if (version == CLIENT_VERSION_UNKNOWN) {
		closeProcess();
		return ERROR_UNKNOWN_CLIENT_VERSION;
	}

	if (m_address[version].rsaAddr != 0x00 && !setRSA(m_address[version].rsaAddr)) {
		closeProcess();
		return ERROR_FAILED_TO_SET_RSA;
	}

	if (!setHost(version, ip, port)) {
		closeProcess();
		return ERROR_FAILED_TO_SET_HOST;
	}

#ifdef WIN32
	setWindowTitle(QString("Tibia - %1:%2").arg(ip).arg(port).toLatin1());
	setForegroundWindow();
#endif
	closeProcess();
	return ERROR_NONE;
}

#ifdef WIN32
bool TibiaClient::getClient()
{
	m_client = FindWindowA("TibiaClient", NULL);
	if (!m_client) {
		QSettings settings;
		QString client = settings.value("lastclient", "Tibia 9.00").toString();
		QString path = settings.value(client, "C:\\Program Files (x86)\\" + client + "\\Tibia.exe").toString();
		QFile file(path);
		if (!file.open(QIODevice::ReadOnly))
			return false;

		file.close();

		QProcess* tibiaClient = new QProcess();
		tibiaClient->setWorkingDirectory(path.section("Tibia.exe", 0, 0));
		tibiaClient->start(path, QStringList());
		short attempts = 0;
		do {
			MainThread::msleep(250);
			m_client = FindWindowA("TibiaClient", "Tibia");
		} while (!m_client && ++attempts < 16);

		if (!m_client)
			return false;
	}
	return true;
}

void TibiaClient::setForegroundWindow()
{
	SetForegroundWindow(m_client);
}

void TibiaClient::setWindowTitle(const char* str)
{
	SetWindowTextA(m_client, str);
}

bool TibiaClient::setProcess()
{
	DWORD processId;

	GetWindowThreadProcessId(m_client, &processId);
	m_process = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);
	if (!m_process)
		return false;

	return true;
}

void TibiaClient::closeProcess()
{
	CloseHandle(m_process);
}
#else
bool TibiaClient::getClient()
{
	FILE* fp = popen("pgrep Tibia", "r");
	if (!fp)
		return false;

	if (fscanf(fp, "%d", &m_processId) != 1) {
		// QProcess::startDetached("~/Tibia/Tibia", "", "~/", m_processId);
		pclose(fp);
		return false;
	}

	pclose(fp);
	return true;
}

bool TibiaClient::setProcess()
{
	if (ptrace(PTRACE_ATTACH, m_processId, 0, 0) == -1) {
		perror("ptrace");
		return false;
	}

	wait(NULL);
	return true;
}

void TibiaClient::closeProcess()
{
	if (ptrace(PTRACE_DETACH, m_processId, 0, 0) == -1)
		perror("ptrace");
}
#endif

ClientVersion_t TibiaClient::getClientVersion()
{
#ifdef WIN32
	switch (readByte(readByte(0x40003C, 4) + 0x400050, 4)) {
		case 2101248: return CLIENT_VERSION_760;
		case 3510272: return CLIENT_VERSION_780;
		case 3575808: return CLIENT_VERSION_792;
		case 3678208: return CLIENT_VERSION_800;
		case 3698688: return CLIENT_VERSION_810;
		case 3756032: return CLIENT_VERSION_820;
		case 3768320: return CLIENT_VERSION_821;
		case 3780608: return CLIENT_VERSION_822;
		case 3796992: return CLIENT_VERSION_830;
		case 3817472: return CLIENT_VERSION_840;
		case 3821568: return CLIENT_VERSION_841;
		case 3842048: return CLIENT_VERSION_842;
		case 3846144: return CLIENT_VERSION_850;
		case 3850240: return CLIENT_VERSION_852;
		case 4128768: return CLIENT_VERSION_854;
		case 4157440: return CLIENT_VERSION_855;
		case 4169728:
		{
			if ((char)readByte(0x72586FFF, 1) == '5') {
				return CLIENT_VERSION_857;
			} else {
				return CLIENT_VERSION_860;
			}
		}
		case 4124672: return CLIENT_VERSION_861;
		case 4313088: return CLIENT_VERSION_862;
		case 4349952: return CLIENT_VERSION_870;
		case 4354048:
		{
			char byte = readByte(0x726D7000, 1);
			if (byte == '2') {
				return CLIENT_VERSION_872;
			} else {
				return CLIENT_VERSION_874;
			}
		}
		case 4362240: return CLIENT_VERSION_900;
		default: return CLIENT_VERSION_UNKNOWN;
	}
#else
	return CLIENT_VERSION_870;
#endif
}

int TibiaClient::readByte(const DWORD addr, const int bytes)
{
#ifdef WIN32
	int value;
	if (!ReadProcessMemory(m_process, reinterpret_cast<void*>(addr), &value, bytes, NULL))
		return -1;

	return value;
#else
	(void)bytes;
	return ptrace(PTRACE_PEEKDATA, m_processId, addr, NULL);
#endif
}

bool TibiaClient::writeByte(const DWORD addr, const int value, const int bytes/* = 1*/)
{
#ifdef WIN32
	return WriteProcessMemory(m_process, reinterpret_cast<void*>(addr), &value, bytes, 0) == TRUE;
#else
	(void)bytes;
	return ptrace(PTRACE_POKEDATA, m_processId, addr, value) != -1;
#endif
}

bool TibiaClient::writeString(const DWORD addr, const char* value)
{
	int i;

	const int len = strlen(value);
	for (i = 0; i < len; i++) {
		if (!writeByte(addr + i, (int)value[i], 1))
			return false;
	}

#ifdef WIN32
	writeByte(addr + i, 0x00, 1);
#endif
	return true;
}

bool TibiaClient::setRSA(const int rsaAddr)
{
#ifdef WIN32
	DWORD protection;

	if (!VirtualProtectEx(m_process, reinterpret_cast<void*>(rsaAddr), strlen(OTSERV_RSA_KEY), PAGE_EXECUTE_READWRITE, &protection)) {
		VirtualProtectEx(m_process, reinterpret_cast<void*>(rsaAddr), strlen(OTSERV_RSA_KEY), protection, &protection);
		return false;
	}

	if (WriteProcessMemory(m_process, reinterpret_cast<void*>(rsaAddr), OTSERV_RSA_KEY, strlen(OTSERV_RSA_KEY), NULL)) {
		VirtualProtectEx(m_process, reinterpret_cast<void*>(rsaAddr), strlen(OTSERV_RSA_KEY), protection, &protection);
		return true;
	}

	return false;
#else
	return writeString(rsaAddr, OTSERV_RSA_KEY);
#endif
}

bool TibiaClient::setHost(const ClientVersion_t version, const char* ip, const unsigned short port)
{
	int memoryAddress = m_address[version].ipAddr;
	const short loginServers = m_address[version].loginServers;

	for (int i = 0; i < loginServers; i++) {
		if (!writeString(memoryAddress, ip))
			return false;

		if (!writeByte(memoryAddress + PORT_DISTANCE, port, 4))
			return false;

		memoryAddress += IP_DISTANCE;
	}
	return true;
}

void TibiaClient::initializeAddresses()
{
	int i;

#ifdef WIN32
	m_address[CLIENT_VERSION_760].ipAddr = 0x005EFB50;

	m_address[CLIENT_VERSION_780].rsaAddr = 0x00582620;
	m_address[CLIENT_VERSION_780].ipAddr = 0x00746710;

	m_address[CLIENT_VERSION_792].rsaAddr = 0x0058D620;
	m_address[CLIENT_VERSION_792].ipAddr = 0x00755E18;

	m_address[CLIENT_VERSION_800].rsaAddr = 0x0075EAE8;
	m_address[CLIENT_VERSION_800].ipAddr = 0x00593610;

	m_address[CLIENT_VERSION_810].rsaAddr = 0x00597610;
	m_address[CLIENT_VERSION_810].ipAddr = 0x00763BB8;

	m_address[CLIENT_VERSION_820].rsaAddr = 0x005A3610;
	m_address[CLIENT_VERSION_820].ipAddr = 0x00771CF0;

	m_address[CLIENT_VERSION_821].rsaAddr = 0x005A5610;
	m_address[CLIENT_VERSION_821].ipAddr = 0x00774CF0;

	m_address[CLIENT_VERSION_822].rsaAddr = 0x005A7610;
	m_address[CLIENT_VERSION_822].ipAddr = 0x00776CF0;

	m_address[CLIENT_VERSION_830].rsaAddr = 0x005AA610;
	m_address[CLIENT_VERSION_830].ipAddr = 0x0077AD88;

	m_address[CLIENT_VERSION_840].rsaAddr = 0x005AB610;
	m_address[CLIENT_VERSION_840].ipAddr = 0x0077FC48;

	m_address[CLIENT_VERSION_841].rsaAddr = 0x005AB610;
	m_address[CLIENT_VERSION_841].ipAddr = 0x00780CD0;

	m_address[CLIENT_VERSION_842].rsaAddr = 0x005AF610;
	m_address[CLIENT_VERSION_842].ipAddr = 0x00785D30;

	m_address[CLIENT_VERSION_850].rsaAddr = 0x005B0610;
	m_address[CLIENT_VERSION_850].ipAddr = 0x00786E70;

	m_address[CLIENT_VERSION_852].rsaAddr = 0x005B1610;
	m_address[CLIENT_VERSION_852].ipAddr = 0x00787E30;

	m_address[CLIENT_VERSION_854].rsaAddr = 0x005B2610;
	m_address[CLIENT_VERSION_854].ipAddr = 0x0078A728;

	m_address[CLIENT_VERSION_855].rsaAddr = 0x005B7610;
	m_address[CLIENT_VERSION_855].ipAddr = 0x00791D20;

	m_address[CLIENT_VERSION_857].rsaAddr = 0x005B8980;
	m_address[CLIENT_VERSION_857].ipAddr = 0x007947F0;

	m_address[CLIENT_VERSION_860].rsaAddr = 0x005B8980;
	m_address[CLIENT_VERSION_860].ipAddr = 0x007947F8;

	m_address[CLIENT_VERSION_861].rsaAddr = 0x005B0980;
	m_address[CLIENT_VERSION_861].ipAddr = 0x00789458;

	m_address[CLIENT_VERSION_862].rsaAddr = 0x005B2980;
	m_address[CLIENT_VERSION_862].ipAddr = 0x007B7620;

	m_address[CLIENT_VERSION_870].rsaAddr = 0x005B8980;
	m_address[CLIENT_VERSION_870].ipAddr = 0x007C0C28;

	m_address[CLIENT_VERSION_872].rsaAddr = 0x005B9980;
	m_address[CLIENT_VERSION_872].ipAddr = 0x007C1C28;

	m_address[CLIENT_VERSION_874].rsaAddr = 0x005B9980;
	m_address[CLIENT_VERSION_874].ipAddr = 0x007C1C38;

	m_address[CLIENT_VERSION_900].rsaAddr = 0x005BA990;
	m_address[CLIENT_VERSION_900].ipAddr = 0x007C3C58;
#else
	m_address[CLIENT_VERSION_760].ipAddr = 0x00000000;

	m_address[CLIENT_VERSION_792].rsaAddr = 0x084A6EC0;
	m_address[CLIENT_VERSION_792].ipAddr = 0x0867CDE0;

	m_address[CLIENT_VERSION_800].rsaAddr = 0x084BCCC0;
	m_address[CLIENT_VERSION_800].ipAddr = 0x08694B20;

	m_address[CLIENT_VERSION_810].rsaAddr = 0x08483440;
	m_address[CLIENT_VERSION_810].ipAddr = 0x0866EF00;

	m_address[CLIENT_VERSION_820].rsaAddr = 0x084A91C0;
	m_address[CLIENT_VERSION_820].ipAddr = 0x0869A900;

	m_address[CLIENT_VERSION_821].rsaAddr = 0x084B2C00;
	m_address[CLIENT_VERSION_821].ipAddr = 0x086A4540;

	m_address[CLIENT_VERSION_822].rsaAddr = 0x084B5240;
	m_address[CLIENT_VERSION_822].ipAddr = 0x086A7D60;

	m_address[CLIENT_VERSION_830].rsaAddr = 0x084BF3A0;
	m_address[CLIENT_VERSION_830].ipAddr = 0x086B2D80;

	m_address[CLIENT_VERSION_840].rsaAddr = 0x084C1040;
	m_address[CLIENT_VERSION_840].ipAddr = 0x086B8C00;

	m_address[CLIENT_VERSION_841].rsaAddr = 0x08380580;
	m_address[CLIENT_VERSION_841].ipAddr = 0x08579C40;

	m_address[CLIENT_VERSION_842].rsaAddr = 0x083753A0;
	m_address[CLIENT_VERSION_842].ipAddr = 0x08569D00;

	m_address[CLIENT_VERSION_850].rsaAddr = 0x08376A40;
	m_address[CLIENT_VERSION_850].ipAddr = 0x0856BD00;

	m_address[CLIENT_VERSION_852].rsaAddr = 0x08378F40;
	m_address[CLIENT_VERSION_852].ipAddr = 0x0856EFE0;

	m_address[CLIENT_VERSION_854].rsaAddr = 0x0837B720;
	m_address[CLIENT_VERSION_854].ipAddr = 0x08572CE0;

	m_address[CLIENT_VERSION_855].rsaAddr = 0x08386A00;
	m_address[CLIENT_VERSION_855].ipAddr = 0x0857FD40;

	m_address[CLIENT_VERSION_857].rsaAddr = 0x08388EE0;
	m_address[CLIENT_VERSION_857].ipAddr = 0x085818C0;

	m_address[CLIENT_VERSION_860].rsaAddr = 0x00000000;
	m_address[CLIENT_VERSION_860].ipAddr = 0x00000000;

	m_address[CLIENT_VERSION_861].rsaAddr = 0x083781C0;
	m_address[CLIENT_VERSION_861].ipAddr = 0x0856E8A0;

	m_address[CLIENT_VERSION_862].rsaAddr = 0x0837A8E0;
	m_address[CLIENT_VERSION_862].ipAddr = 0x0859B860;

	m_address[CLIENT_VERSION_870].rsaAddr = 0x08388480;
	m_address[CLIENT_VERSION_870].ipAddr = 0x085ACDE0;

	m_address[CLIENT_VERSION_872].rsaAddr = 0x00000000;
	m_address[CLIENT_VERSION_872].ipAddr = 0x00000000;

	m_address[CLIENT_VERSION_874].rsaAddr = 0x00000000;
	m_address[CLIENT_VERSION_874].ipAddr = 0x00000000;

	m_address[CLIENT_VERSION_900].rsaAddr = 0x00000000;
	m_address[CLIENT_VERSION_900].ipAddr = 0x00000000;
#endif
	m_address[CLIENT_VERSION_760].rsaAddr = 0x00000000;

	for (i = CLIENT_VERSION_FIRST; i <= CLIENT_VERSION_792; i++)
		m_address[i].loginServers = 5;

	for (i = CLIENT_VERSION_800; i <= CLIENT_VERSION_LAST; i++)
		m_address[i].loginServers = 10;
}
