/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#ifndef __TABLEMODEL_H__
#define __TABLEMODEL_H__

#include <QAbstractTableModel>
#include <QPair>
#include <QList>

typedef QPair<QString, int> IPQPair;
typedef QList< IPQPair > IPQList;

typedef QPair<QString, QString> ServerDataQPair;
typedef QList< ServerDataQPair > ServerDataQList;

class TableModel : public QAbstractTableModel
{
	Q_OBJECT
	public:
		TableModel(QObject* parent = 0);
		TableModel(IPQList listofPairs, QObject* parent = 0);

		int rowCount(const QModelIndex& parent) const;
		int columnCount(const QModelIndex& parent) const;

		QVariant data(const QModelIndex& index, int role) const;
		QVariant headerData(int section, Qt::Orientation orientation, int role) const;

		Qt::ItemFlags flags(const QModelIndex& index) const;

		bool setData(const QModelIndex& index, const QVariant& value, int role = Qt::EditRole);

		bool insertRows(int position, int rows, const QModelIndex& index = QModelIndex());
		bool removeRows(int position, int rows, const QModelIndex& index = QModelIndex());

		IPQList getList();
		ServerDataQList getServerDataList();

	private:
		IPQList listOfPairs;
		ServerDataQList listOfServerData;
};

#endif
