/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#include "definitions.h"

#include "tablemodel.h"

TableModel::TableModel(QObject* parent)
	: QAbstractTableModel(parent)
{
	//
}

TableModel::TableModel(IPQList pairs, QObject* parent)
	: QAbstractTableModel(parent)
{
	listOfPairs = pairs;
}

int TableModel::rowCount(const QModelIndex& parent) const
{
	Q_UNUSED(parent);
	return listOfPairs.size();
}

int TableModel::columnCount(const QModelIndex& parent) const
{
	Q_UNUSED(parent);
	return 4;
}

QVariant TableModel::data(const QModelIndex& index, int role) const
{
	if (!index.isValid())
		return QVariant();

	if (index.row() >= listOfPairs.size() || index.row() < 0)
		return QVariant();

	if (role == Qt::DisplayRole) {
		if (index.column() == 0) {
			IPQPair pair = listOfPairs.at(index.row());
			return pair.first;
		} else if (index.column() == 1) {
			IPQPair pair = listOfPairs.at(index.row());
			return pair.second;
		} else if (index.column() == 2) {
			ServerDataQPair pair = listOfServerData.at(index.row());
			return pair.first;
		} else if (index.column() == 3) {
			ServerDataQPair pair = listOfServerData.at(index.row());
			return pair.second;
		}
	}
	return QVariant();
}

QVariant TableModel::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (role != Qt::DisplayRole)
		return QVariant();

	if (orientation == Qt::Horizontal) {
		switch(section) {
			case 0: return "IP";
			case 1: return "Port";
			case 2: return "Players";
			case 3: return "Uptime";
			default: return QVariant();
		}
	}
	return QVariant();
}

bool TableModel::insertRows(int position, int rows, const QModelIndex& index)
{
	Q_UNUSED(index);

	beginInsertRows(QModelIndex(), position, position + rows - 1);
	for (int row = 0; row < rows; row++) {
		IPQPair pair(" ", 0);
		listOfPairs.insert(position, pair);
		ServerDataQPair sPair("-", "Offline");
		listOfServerData.insert(position, sPair);
	}

	endInsertRows();
	return true;
}

bool TableModel::removeRows(int position, int rows, const QModelIndex& index)
{
	Q_UNUSED(index);

	beginRemoveRows(QModelIndex(), position, position + rows - 1);
	for (int row = 0; row < rows; ++row) {
		listOfPairs.removeAt(position);
		listOfServerData.removeAt(position);
	}

	endRemoveRows();
	return true;
}

bool TableModel::setData(const QModelIndex& index, const QVariant& value, int role)
{
	if (index.isValid() && role == Qt::EditRole) {
		int row = index.row();
		if (index.column() == 0) {
			IPQPair p = listOfPairs.value(row);
			p.first = value.toString();
			listOfPairs.replace(row, p);
		} else if(index.column() == 1) {
			IPQPair p = listOfPairs.value(row);
			p.second = value.toInt();
			listOfPairs.replace(row, p);
		} else if(index.column() == 2) {
			ServerDataQPair p = listOfServerData.value(row);
			p.first = value.toString();
			listOfServerData.replace(row, p);
		} else if(index.column() == 3) {
			ServerDataQPair p = listOfServerData.value(row);
			p.second = value.toString();
			listOfServerData.replace(row, p);
		} else {
			return false;
		}

		emit(dataChanged(index, index));
		return true;
	}
	return false;
}

Qt::ItemFlags TableModel::flags(const QModelIndex& index) const
{
	if (!index.isValid())
		return Qt::ItemIsEnabled;

	return QAbstractTableModel::flags(index) | Qt::ItemIsEditable;
}

IPQList TableModel::getList()
{
	return listOfPairs;
}

ServerDataQList TableModel::getServerDataList()
{
	return listOfServerData;
}
