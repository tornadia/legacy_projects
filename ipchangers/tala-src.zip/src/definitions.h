/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#ifndef __DEFINITIONS_H__
#define __DEFINITIONS_H__

#include <QThread>

class MainThread : public QThread
{
	public:
		static void sleep(unsigned long secs) {
			QThread::sleep(secs);
		}

		static void msleep(unsigned long msecs) {
			QThread::msleep(msecs);
		}

		static void usleep(unsigned long usecs) {
			QThread::usleep(usecs);
		}
};

#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#endif

#define APPNAME "Talaturen's IP Changer"
#define VERSION "3.9"

#define IP_DISTANCE 112
#define PORT_DISTANCE 100

#define OTSERV_RSA_KEY "109120132967399429278860960508995541528237502902798129123468757937\
266291492576446330739696001110603907230888610072655818825358503429057592827629436\
413108566029093628212635953836686562675849720620786279431090218017681061521755056\
710823876476444260558147179707119674283982419152118103759076030616683978566631413"

#define TIBIA_RSA_KEY_OLD "1247104594268279430043764498979855821678017079606970371640449048629\
485693808504213969045976869538770223946042394281854982841690685818022776120810279\
667243363194485378114417190764843409228549292735173086613707271053828991189994038\
08045846444647284499123164879035103627004668521005328367415259939915284902061793"

#define TIBIA_RSA_KEY_NEW "13212774320587228406229509908229338495277632649616550796787636184334\
395343554449668205332383339435179772895415509701210392836078695982113221447329157\
571213880049503316991481406963774031827815029073368403252417478274013435762969906\
2987023311132821016569775488792221429527047321331896351555606801473202394175817"

#endif // __DEFINITIONS_H__
