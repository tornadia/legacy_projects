/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#include "definitions.h"

#include <QtGui>
#include "aboutwindow.h"

AboutWindow::AboutWindow(QWidget* parent)
	: QDialog(parent)
{
	setWindowTitle("About");

	// Developers
	QWidget* developers = new QWidget;
	QLabel* devInfo = new QLabel(QString(APPNAME) + " is developed by:");
	QTextEdit* devText = new QTextEdit("<strong>Talaturen</strong> &lt;mark.samman@gmail.com&gt;<br />Main Developer<br /><br /><strong>Kornholijo</strong><br />Assistance with memory editing<br /><br /><strong>Elf</strong><br />Installation Manager");
	devText->setReadOnly(true);
	QGridLayout* devLayout = new QGridLayout;
	devLayout->addWidget(devInfo);
	devLayout->addWidget(devText);
	developers->setLayout(devLayout);

	// License
	QWidget* license = new QWidget;
	QLabel* licenseInfo = new QLabel(QString(APPNAME) + " is licensed under GNU GPLv2:");
	QTextEdit* licenseText = new QTextEdit(QString(APPNAME) + " - An application to replace the host in tibiaclient.<br />Copyright (C) 2008 - 2011 Mark Samman &lt;mark.samman@gmail.com&gt;<br /><br />This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.<br /><br />This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.<br /><br />You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.");
	licenseText->setReadOnly(true);
	QGridLayout* licenseLayout = new QGridLayout;
	licenseLayout->addWidget(licenseInfo);
	licenseLayout->addWidget(licenseText);
	license->setLayout(licenseLayout);

	// Tabs
	QTabWidget* tabs = new QTabWidget;
	tabs->addTab(developers, "Developers");
	tabs->addTab(license, "License");
	tabs->show();

	//
	QLabel* text = new QLabel(QString(APPNAME) + " " + QString(VERSION) + "\n- An application to replace the host in tibiaclient.\n");
	QGridLayout* layout = new QGridLayout;
	layout->addWidget(text);
	layout->addWidget(tabs);
	setLayout(layout);
}
