/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#include "definitions.h"

#include <QtGui>

#include "userinterface.h"
#include "tibiaclient.h"

#ifdef WIN32
#include <windows.h>
#include <iostream>
#endif

int main(int argc, char* argv[])
{
	if (argc == 2) {
		std::string argument = argv[1];
		argument = argument.substr(argument.find_first_of('/') + 2);
		int ipEnd = argument.find_first_of('/');
		std::string ip = argument.substr(0, ipEnd);
		int port = atoi(argument.substr(ipEnd + 1, argument.find_last_of('/') - ipEnd - 1).c_str());

		TibiaClient::getInstance()->initializeAddresses();
		if (TibiaClient::getInstance()->replaceHost(ip.c_str(), port) == ERROR_NONE)
			return 0;
	}

#ifdef WIN32
	if (FindWindowA("QWidget", "Talaturen's IP Changer")) {
		SetForegroundWindow(FindWindowA("QWidget", "Talaturen's IP Changer"));
		return 0;
	}

	QSettings pathSettings("HKEY_CURRENT_USER\\Software\\Talaturen's IP Changer", QSettings::NativeFormat);
	QSettings protocolHandlerSettings("HKEY_CLASSES_ROOT\\otserv\\shell\\open\\command", QSettings::NativeFormat);
	protocolHandlerSettings.setValue(".", "\"" + pathSettings.value(".").toString() + "\" \"%1\"");
#endif

	QApplication application(argc, argv);
	application.setApplicationName(APPNAME);
	application.setApplicationVersion(VERSION);
	application.setOrganizationDomain("http://otland.net");
	application.setOrganizationName("OtLand");

	if (!QSystemTrayIcon::isSystemTrayAvailable()) {
		QMessageBox::critical(0, APPNAME, "Failed to detect any system tray.");
		return 1;
	}

	QApplication::setQuitOnLastWindowClosed(false);

	UserInterface ui;
	ui.show();
	return application.exec();
}
