/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#include "definitions.h"

#include <QtGui>

#include "userinterface.h"
#include "tibiaclient.h"
#include "iplist.h"
#include "aboutwindow.h"

UserInterface::UserInterface()
{
	/* Fixed window size */
#ifdef WIN32
	setFixedSize(275, 144);
#else
	setFixedSize(295, 144);
#endif
	statusBar()->setSizeGripEnabled(false);

	// Tray icon
	QMenu* trayIconMenu = new QMenu(this);

	QAction* changeIPAction = new QAction(tr("&Change IP"), this);
	connect(changeIPAction, SIGNAL(triggered()), this, SLOT(changeIP()));

	QAction* restoreAction = new QAction(tr("&Restore"), this);
	connect(restoreAction, SIGNAL(triggered()), this, SLOT(showNormal()));

	QAction* quitAction = new QAction(tr("&Exit"), this);
	connect(quitAction, SIGNAL(triggered()), this, SLOT(exitFromTray()));

	trayIconMenu->addAction(changeIPAction);
	trayIconMenu->addAction(restoreAction);
	trayIconMenu->addSeparator();
	trayIconMenu->addAction(quitAction);

	trayIcon = new QSystemTrayIcon(this);
	trayIcon->setContextMenu(trayIconMenu);

	connect(trayIcon, SIGNAL(activated(QSystemTrayIcon::ActivationReason)),
		this, SLOT(trayAction(QSystemTrayIcon::ActivationReason)));

	trayIcon->setIcon(QIcon(":/img/IPChanger.png"));
	trayIcon->show();

	// Menu
	QMenu* fileMenu = new QMenu(tr("&File"), this);
	QMenu* toolsMenu = new QMenu(tr("&Tools"), this);
	QMenu* helpMenu = new QMenu(tr("&Help"), this);

	QAction* exitAction = new QAction(tr("E&xit"), this);
	QAction* ipListAction = new QAction(tr("IP &List"), this);
	QAction* aboutAction = new QAction(tr("&About"), this);

	exitAction->setShortcut(tr("Ctrl+Q"));
	ipListAction->setShortcut(tr("Ctrl+L"));
	aboutAction->setShortcut(tr("Ctrl+H"));

	exitAction->setStatusTip(tr("Exit the application"));
	ipListAction->setStatusTip(tr("Launch IP List"));
	aboutAction->setStatusTip(tr("About ") + (QString)APPNAME);

	fileMenu->addAction(exitAction);
	toolsMenu->addAction(ipListAction);
	helpMenu->addSeparator();
	helpMenu->addAction(aboutAction);

	connect(exitAction, SIGNAL(triggered()), this, SLOT(exitFromTray()));
	connect(ipListAction, SIGNAL(triggered()), this, SLOT(ipListWindow()));
	connect(aboutAction, SIGNAL(triggered()), this, SLOT(aboutWindow()));

	menuBar()->addMenu(fileMenu);
	menuBar()->addMenu(toolsMenu);
	menuBar()->addMenu(helpMenu);

	/** VERSION 1 INTERFACE **/
	QWidget* v1interface = new QWidget;

	QLabel* ipLabel = new QLabel(tr("&IP:"));
	ipEdit = new QLineEdit;
	ipEdit->setMinimumWidth(120);
	ipEdit->setMaxLength(30);
	ipEdit->setStatusTip(tr("Server IP-Address"));
	ipLabel->setBuddy(ipEdit);

	QLabel* portLabel = new QLabel(tr("&Port:"));
	portEdit = new QLineEdit;
	portEdit->setValidator(new QIntValidator(0, 65535, portEdit));
	portEdit->setMaxLength(5);
	portEdit->setStatusTip(tr("Server port"));
#ifdef WIN32
	portEdit->setMinimumWidth(40);
	portEdit->setMaximumWidth(50);
#else
	portEdit->setMinimumWidth(55);
	portEdit->setMaximumWidth(65);
#endif
	portLabel->setBuddy(portEdit);

	QPushButton* v1ipButton = new QPushButton(tr("&Change IP"));
	v1ipButton->setStatusTip(tr("Change IP"));

	connect(v1ipButton, SIGNAL(clicked()),
		this, SLOT(changeIP()));

	QGridLayout* v1Layout = new QGridLayout;
	v1Layout->addWidget(ipLabel, 0, 0, 1, 1);
	v1Layout->addWidget(ipEdit, 0, 1, 1, 1);
	v1Layout->addWidget(portLabel, 0, 2, 1, 1);
	v1Layout->addWidget(portEdit, 0, 3, 1, 1);
	v1Layout->addWidget(v1ipButton, 2, 0, 1, 4);
	v1interface->setLayout(v1Layout);
	/*************************/

	/** VERSION 2 INTERFACE **/
	QWidget* v2interface = new QWidget;

	ipBox = new QComboBox;
	ipBox->setMinimumWidth(160);
	ipBox->setStatusTip(tr("Server IP-Address"));
	ipBox->setEditable(true);

	QPushButton* ipListButton = new QPushButton(tr("&List"));
	ipListButton->setStatusTip(tr("IP List"));
	ipListButton->setMaximumWidth(40);

	connect(ipListButton, SIGNAL(clicked()),
		this, SLOT(ipListWindow()));

	QPushButton* v2ipButton = new QPushButton(tr("&Change IP"));
	v2ipButton->setStatusTip(tr("Change IP"));

	connect(v2ipButton, SIGNAL(clicked()),
		this, SLOT(changeIP()));

	QGridLayout* v2Layout = new QGridLayout;
	v2Layout->addWidget(ipBox, 0, 0, 1, 1);
	v2Layout->addWidget(ipListButton, 0, 1, 1, 1);
	v2Layout->addWidget(v2ipButton, 1, 0, 1, 2);
	v2interface->setLayout(v2Layout);
	/*************************/

	// Configuration widget
	QWidget* config = new QWidget;

	QLabel* styleLabel = new QLabel(tr("Style:"));
	styleComboBox = new QComboBox;
	styleComboBox->addItems(QStyleFactory::keys());
	styleComboBox->setStatusTip(tr("User-interface Style"));
	styleLabel->setBuddy(styleComboBox);

	QLabel* styleSheetLabel = new QLabel(tr("Stylesheet:"));
	styleSheetEdit = new QLineEdit;
	styleSheetEdit->setStatusTip(tr("User-interface Stylesheet"));
	styleSheetLabel->setBuddy(styleSheetEdit);
	QPushButton* styleSheetButton = new QPushButton(tr("Set"));

	connect(styleComboBox, SIGNAL(activated(const QString&)),
		this, SLOT(changeStyle(const QString&)));

	connect(styleSheetButton, SIGNAL(clicked()),
		this, SLOT(changeStyleSheet()));

	QGridLayout* configLayout = new QGridLayout;
	configLayout->addWidget(styleLabel, 0, 0, 1, 1);
	configLayout->addWidget(styleComboBox, 0, 1, 1, 3);
	configLayout->addWidget(styleSheetLabel, 1, 0, 1, 1);
	configLayout->addWidget(styleSheetEdit, 1, 1, 1, 1);
	configLayout->addWidget(styleSheetButton, 1, 2, 1, 1);
	config->setLayout(configLayout);

	/* Tibia Client Tab */
	QWidget* tibiaClient = new QWidget;
	clients = new QComboBox;
	clients->addItem("Tibia 7.60");
	clients->addItem("Tibia 7.80");
	clients->addItem("Tibia 7.92");
	clients->addItem("Tibia 8.00");
	clients->addItem("Tibia 8.10");
	clients->addItem("Tibia 8.20");
	clients->addItem("Tibia 8.21");
	clients->addItem("Tibia 8.22");
	clients->addItem("Tibia 8.30");
	clients->addItem("Tibia 8.40");
	clients->addItem("Tibia 8.41");
	clients->addItem("Tibia 8.42");
	clients->addItem("Tibia 8.50");
	clients->addItem("Tibia 8.52");
	clients->addItem("Tibia 8.54");
	clients->addItem("Tibia 8.55");
	clients->addItem("Tibia 8.57");
	#ifdef WIN32
	clients->addItem("Tibia 8.60");
	#endif
	clients->addItem("Tibia 8.61");
	clients->addItem("Tibia 8.62");
	clients->addItem("Tibia 8.70");
	#ifdef WIN32
	clients->addItem("Tibia 8.71");
	clients->addItem("Tibia 8.72");
	clients->addItem("Tibia 8.73");
	clients->addItem("Tibia 8.74");
	clients->addItem("Tibia 9.00");
	#endif

	clients->setStatusTip(tr("Client Version"));

	connect(clients, SIGNAL(activated(const QString&)),
		this, SLOT(changeClient(const QString&)));

	pathEdit = new QLineEdit;
	pathEdit->setStatusTip(tr("Path to Tibia client"));

	connect(pathEdit, SIGNAL(textEdited(const QString&)),
		this, SLOT(modifyPath(const QString&)));

	QLabel* clientsLabel = new QLabel("Version:");
	clientsLabel->setBuddy(clients);
	QLabel* pathLabel = new QLabel("Path:");
	pathLabel->setBuddy(pathEdit);

	QGridLayout* tibiaClientLayout = new QGridLayout;
	tibiaClientLayout->addWidget(clientsLabel, 0, 0, 1, 1);
	tibiaClientLayout->addWidget(pathLabel, 1, 0, 1, 1);
	tibiaClientLayout->addWidget(clients, 0, 1, 1, 3);
	tibiaClientLayout->addWidget(pathEdit, 1, 1, 1, 3);
	tibiaClient->setLayout(tibiaClientLayout);

	// Tabs
	tabs = new QTabWidget;
	tabs->addTab(v1interface, tr("v1"));
	tabs->addTab(v2interface, tr("v2"));
	tabs->addTab(config, tr("Configuration"));
	tabs->addTab(tibiaClient, tr("Tibia Client"));
	setCentralWidget(tabs);
	tabs->show();

	ipBox->setFocus();

	setWindowTitle(APPNAME);
	statusBar()->showMessage(tr("Ready"));

	readSettings();

	TibiaClient::getInstance()->initializeAddresses();

	loadedIPList = "";
}

void UserInterface::trayAction(QSystemTrayIcon::ActivationReason reason)
{
	switch (reason) {
		case QSystemTrayIcon::DoubleClick:
			if(isVisible())
				hide();
			else {
				showNormal();
#ifdef WIN32
				SetForegroundWindow(FindWindowA("QWidget", "Talaturen's IP Changer"));
#endif
			}
			break;

		default:
			break;
	}
}

void UserInterface::parseClientData()
{
	/*
	QList<QString> list;
	QString data = http->readAll().data();
	for (int pos = data.indexOf(';'); pos != -1; pos = data.indexOf(';')) {
		list.push_back(data.left(pos));
		data.remove(0, pos + 1);
	}

	for (int i = 0; i < list.size(); i++) {
		data = list.at(i);
		QStringList lst = data.split(',');
		//QString client = data.left(
		QMessageBox::information(this, "Data", list.at(i));
	}
	*/
}

void UserInterface::fetchClientData()
{
	/*
	http = new QHttp("ipchanger.otland.net", 80);
#ifdef WIN32
	http->get("/data_windows");
#else
	http->get("/data_linux");
#endif
	connect(http, SIGNAL(done(bool)), this, SLOT(parseClientData()));
	*/
}

void UserInterface::modifyPath(const QString& data)
{
	QSettings settings;
	settings.setValue(lastClient, data);
}

void UserInterface::changeClient(const QString& clientName)
{
	QSettings settings;
	if (lastClient != clientName)
		settings.setValue(lastClient, pathEdit->text());

#ifdef WIN32
	pathEdit->setText(settings.value(clientName, "C:/Program Files (x86)/" + clientName + "/Tibia.exe").toString());
#else
	pathEdit->setText(settings.value(clientName, "~/" + clientName + "/Tibia").toString());
#endif
	lastClient = clientName;
	settings.setValue("lastclient", lastClient);
}

void UserInterface::changeStyle(const QString& styleName)
{
	QApplication::setStyle(QStyleFactory::create(styleName));
	QApplication::setPalette(QApplication::style()->standardPalette());
	currentStyle = styleName;

	changeStyleSheet(currentStyleSheet);
}

void UserInterface::changeIP()
{
	QString ip, port;
	if (tabs->currentIndex() == 0) {
		ip = ipEdit->text();
		port = portEdit->text();
	} else {
		ip = ipBox->currentText().section(':', 0, 0);
		port = ipBox->currentText().section(':', 1, 1);
	}

	switch (TibiaClient::getInstance()->replaceHost(ip.toLatin1(), port.toUShort())) {
		case ERROR_CLIENT_NOT_FOUND:
			QMessageBox::warning(this, tr("Error"), tr("Game client not found, make sure that it is running, or that the path\r\nfor the selected client matches before trying to replace its host."), QMessageBox::Ok, QMessageBox::NoButton);
			break;

		case ERROR_PROCESS_NOT_FOUND:
			QMessageBox::warning(this, tr("Error"), tr("Process not found."), QMessageBox::Ok, QMessageBox::NoButton);
			break;

		case ERROR_FAILED_TO_SET_RSA:
			QMessageBox::critical(this, tr("Error"), tr("Failed to set RSA key."), QMessageBox::Ok, QMessageBox::NoButton);
			break;

		case ERROR_FAILED_TO_SET_HOST:
			QMessageBox::critical(this, tr("Error"), tr("Failed to set host."), QMessageBox::Ok, QMessageBox::NoButton);
			break;

		case ERROR_UNKNOWN_CLIENT_VERSION:
			QMessageBox::warning(this, tr("Error"), tr("Unsupported client version."), QMessageBox::Ok, QMessageBox::NoButton);
			break;

		case ERROR_NONE:
			statusBar()->showMessage(tr("Client host has been changed."));
			break;
	}
}

void UserInterface::ipListWindow()
{
	IPList ipList(this);
	ipList.exec();
}

void UserInterface::aboutWindow()
{
	AboutWindow aboutWindow(this);
	aboutWindow.exec();
}

void UserInterface::readSettings()
{
	QSettings settings;

	QString style = settings.value("style", "Cleanlooks").toString();
	styleComboBox->setCurrentIndex(styleComboBox->findText(style, Qt::MatchExactly | Qt::MatchCaseSensitive));
	changeStyle(style);

	#ifdef WIN32
	lastClient = settings.value("lastclient", "Tibia 8.72").toString();
	#else
	lastClient = settings.value("lastclient", "Tibia 8.70").toString();
	#endif
	clients->setCurrentIndex(clients->findText(lastClient, Qt::MatchExactly | Qt::MatchCaseSensitive));
	changeClient(lastClient);

	QString styleSheet = settings.value("stylesheet", "").toString();
	styleSheetEdit->setText(styleSheet);
	changeStyleSheet(styleSheet);

	QPoint pos = settings.value("pos", QPoint(100, 80)).toPoint();
	move(pos);

	tabs->setCurrentIndex(settings.value("lastindex", 1).toInt());

	int size = settings.beginReadArray("iplist"), i;
	for (i = 0; i < size; i++) {
		settings.setArrayIndex(i);
		ipBox->addItem(settings.value("ip").toString() + ":" + settings.value("port").toString());
	}
	settings.endArray();

	if (i == 0) {
		ipBox->addItem("softcores.otland.net:7171");
		ipBox->addItem("icechaw.otland.net:7171");
	}

	QString v2lastip = settings.value("v2lastip", "softcores.otland.net").toString();
	selectServer(v2lastip.section(':', 0, 0), v2lastip.section(':', 1, 1));

	ipEdit->setText(settings.value("lastip", "softcores.otland.net").toString());
	portEdit->setText(settings.value("lastport", "7171").toString());
}

void UserInterface::writeSettings()
{
	QSettings settings;
	settings.setValue("style", currentStyle);
	settings.setValue("stylesheet", currentStyleSheet);
	settings.setValue("pos", pos());
	settings.setValue("v2lastip", ipBox->currentText());
	settings.setValue("lastip", ipEdit->text());
	settings.setValue("lastport", portEdit->text());
	settings.setValue("lastindex", tabs->currentIndex());
	settings.setValue(lastClient, pathEdit->text());
	settings.setValue("lastclient", lastClient);
}

void UserInterface::changeStyleSheet()
{
	QFile file(styleSheetEdit->text() + ".qss");
	file.open(QFile::ReadOnly);
	QString styleSheet = QLatin1String(file.readAll());
	setStyleSheet(styleSheet);
	currentStyleSheet = styleSheetEdit->text();
}

void UserInterface::changeStyleSheet(const QString& fileName)
{
	QFile file(fileName + ".qss");
	file.open(QFile::ReadOnly);
	QString styleSheet = QLatin1String(file.readAll());
	setStyleSheet(styleSheet);
	currentStyleSheet = fileName;
}

void UserInterface::exitFromTray()
{
	trayIcon->setVisible(false);
	close();
}

void UserInterface::closeEvent(QCloseEvent* event)
{
	writeSettings();
	if (trayIcon->isVisible()) {
		hide();
		event->ignore();
	} else {
		event->accept();
		qApp->exit();
	}
}

void UserInterface::changeEvent(QEvent* event)
{
	if (isMinimized() && trayIcon->isVisible()) {
		QTimer::singleShot(0, this, SLOT(hide()));
		event->ignore();
		return;
	}
	event->accept();
}

void UserInterface::selectServer(QString ip, QString port)
{
	ipEdit->setText(ip);
	portEdit->setText(port);

	for (int i = 0; i < ipBox->count(); i++) {
		if (ipBox->itemText(i) == QString(ip + ":" + port)) {
			ipBox->setCurrentIndex(i);
			break;
		}
	}
}

void UserInterface::addServer(QString ip, QString port)
{
	ipBox->addItem(ip + ":" + port);
}

void UserInterface::editServer(QString oldIP, QString oldPort, QString ip, QString port)
{
	for (int i = 0; i < ipBox->count(); i++) {
		if (ipBox->itemText(i) == QString(oldIP + ":" + oldPort)) {
			ipBox->setItemText(i, QString(ip + ":" + port));
			break;
		}
	}
}

void UserInterface::removeServer(QString ip, QString port)
{
	for (int i = 0; i < ipBox->count(); i++) {
		if (ipBox->itemText(i) == QString(ip + ":" + port)) {
			ipBox->removeItem(i);
			break;
		}
	}
}
