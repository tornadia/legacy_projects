/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#ifndef __IPLIST_H__
#define __IPLIST_H__

#include <QDialog>
#include <QItemSelection>
#include <QTableView>
#include "tablemodel.h"
#include "userinterface.h"

enum connectionError_t
{
	CONNECTION_SUCCESS = 0,
	FAILED_TO_CONNECT = 1,
	FAILED_TO_WRITE = 2,
	FAILED_TO_READ = 3
};

class IPList : public QDialog
{
	Q_OBJECT
	public:
		IPList(QWidget* _parent = 0);

		QString transformUptime(unsigned int uptime);
		QString transformPlayers(unsigned int players, unsigned int playersMax);
		connectionError_t getServerData(QString& host, unsigned short port, QString& uptime, QString& players);

	public slots:
		void addServer(const QString& _ip = "", const QString& _port = "7171", QString players = "N/A", QString uptime = "N/A", bool load = false);
		void refreshAll();
		void refreshServer();
		void editServer();
		void removeServer();
		void selectServer();
		void changedSelection(const QItemSelection& selection);

		void loadList();
		void saveList();
		void saveAs();

	protected:
		void readSettings();
		void writeSettings();

		void closeEvent(QCloseEvent* event);

		UserInterface* parent;

	private:
		QLineEdit* ipEdit;
		QLineEdit* portEdit;
		QLineEdit* connectEdit;
		QLineEdit* writeEdit;
		QLineEdit* readEdit;
		unsigned int entriesCount;

		QPushButton* refreshButton;
		QPushButton* selectButton;
		QPushButton* removeButton;
		QPushButton* editButton;

		QTableView* tableView;
		TableModel* table;
};

#endif
