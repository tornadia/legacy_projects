/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#ifndef __USERINTERFACE_H__
#define __USERINTERFACE_H__

#include <QComboBox>
#include <QMainWindow>
#include <QSystemTrayIcon>

#include <QtNetwork>

class UserInterface : public QMainWindow
{
	Q_OBJECT
	public:
		UserInterface();

		void selectServer(QString ip, QString port);
		void addServer(QString ip, QString port);
		void editServer(QString oldIP, QString oldPort, QString ip, QString port);
		void removeServer(QString ip, QString port);

		QString getLoadedIPList() const { return loadedIPList; }
		void setLoadedIPList(QString str) { loadedIPList = str; }

	public slots:
		void exitFromTray();
		void trayAction(QSystemTrayIcon::ActivationReason reason);

		void changeStyle(const QString& styleName);
		void changeStyleSheet();

		void parseClientData();
		void fetchClientData();
		void changeClient(const QString& styleName);
		void modifyPath(const QString& data);

		void changeIP();

		void aboutWindow();
		void ipListWindow();

	private:
		void readSettings();
		void writeSettings();

		void changeStyleSheet(const QString& fileName);

		void changeEvent(QEvent* event);
		void closeEvent(QCloseEvent* event);

		QString loadedIPList;

		QString currentStyle;
		QString currentStyleSheet;

		QComboBox* styleComboBox;

		QComboBox* ipBox;
		QLineEdit* ipEdit;
		QLineEdit* portEdit;
		QTabWidget* tabs;

		QComboBox* clients;
		QLineEdit* pathEdit;
		QString lastClient;

		QLineEdit* styleSheetEdit;

		QSystemTrayIcon* trayIcon;

		QHttp* http;
};

#endif
