/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#ifndef __TIBIACLIENT_H__
#define __TIBIACLIENT_H__

#ifdef WIN32
#include <windows.h>
#else
typedef int DWORD;
#endif

enum ErrorMessage_t
{
	ERROR_NONE = 0,
	ERROR_FAILED_TO_SET_RSA = 1,
	ERROR_FAILED_TO_SET_HOST = 2,
	ERROR_CLIENT_NOT_FOUND = 3,
	ERROR_PROCESS_NOT_FOUND = 4,
	ERROR_UNKNOWN_CLIENT_VERSION = 5
};

enum ClientVersion_t
{
	CLIENT_VERSION_UNKNOWN = -1,

	CLIENT_VERSION_760 = 0,
	CLIENT_VERSION_780 = 1,
	CLIENT_VERSION_792 = 2,
	CLIENT_VERSION_800 = 3,
	CLIENT_VERSION_810 = 4,
	CLIENT_VERSION_820 = 5,
	CLIENT_VERSION_821 = 6,
	CLIENT_VERSION_822 = 7,
	CLIENT_VERSION_830 = 8,
	CLIENT_VERSION_840 = 9,
	CLIENT_VERSION_841 = 10,
	CLIENT_VERSION_842 = 11,
	CLIENT_VERSION_850 = 12,
	CLIENT_VERSION_852 = 13,
	CLIENT_VERSION_854 = 14,
	CLIENT_VERSION_855 = 15,
	CLIENT_VERSION_857 = 16,
	CLIENT_VERSION_860 = 17,
	CLIENT_VERSION_861 = 18,
	CLIENT_VERSION_862 = 19,
	CLIENT_VERSION_870 = 20,
	CLIENT_VERSION_872 = 21,
	CLIENT_VERSION_874 = 22,
	CLIENT_VERSION_900 = 23,

	CLIENT_VERSION_FIRST = CLIENT_VERSION_760,
	CLIENT_VERSION_LAST = CLIENT_VERSION_900
};

class TibiaClient
{
	public:
		TibiaClient() {}
		~TibiaClient() {}

		static TibiaClient* getInstance()
		{
			static TibiaClient instance;
			return &instance;
		}

		void initializeAddresses();

		ErrorMessage_t replaceHost(const char* ip, unsigned short port);

		bool getClient();
		bool setProcess();
#ifdef WIN32
		void setForegroundWindow();
		void setWindowTitle(const char* str);
#endif
		void closeProcess();
		ClientVersion_t getClientVersion();

	private:
#ifdef WIN32
		HWND m_client;
		HANDLE m_process;
#else
		int m_processId;
#endif

		int readByte(const DWORD addr, const int bytes);
		bool writeByte(const DWORD addr, const int value, const int bytes = 1);
		bool writeString(const DWORD addr, const char* value);

		bool setRSA(const int rsaAddr);
		bool setHost(const ClientVersion_t version, const char* ip, const unsigned short port);
};

#endif
