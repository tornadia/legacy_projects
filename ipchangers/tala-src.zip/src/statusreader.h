/////////////////////////////////////////////////////////////////////////////////
// Talaturen's IP Changer - An application to replace the host in tibiaclient.
/////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008 - 2011 Mark Samman <mark.samman@gmail.com>
/////////////////////////////////////////////////////////////////////////////////
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
/////////////////////////////////////////////////////////////////////////////////

#ifndef __STATUSREADER_H__
#define __STATUSREADER_H__

#include <QXmlSimpleReader>

class StatusReader : public QXmlDefaultHandler
{
	public:
		QString getUptime() const { return uptime; }
		QString getPlayers() const { return players; }
		QString getPlayersMax() const { return playersMax; }

		bool startDocument()
		{
			return true;
		}

		bool endElement()
		{
			return true;
		}

		bool startElement(const QString&, const QString&, const QString&, const QXmlAttributes& attrs)
		{
			for (int i = 0; i < attrs.count(); i++) {
				if(attrs.localName(i) == "uptime")
					uptime = attrs.value(i);
				else if(attrs.localName(i) == "online")
					players = attrs.value(i);
				else if(attrs.localName(i) == "max")
					playersMax = attrs.value(i);
			}
			return true;
		}

	private:
		QString uptime;
		QString players;
		QString playersMax;
};

#endif
