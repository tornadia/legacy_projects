#ifndef MAIN_H
#define MAIN_H

#include <wx/wx.h>

class MyApp : public wxApp
{
  public:
    virtual bool OnInit();
};

#endif //MAIN_H
