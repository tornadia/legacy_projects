NPC npc = new NPC();
npc.Name = "Willie";
npc.CharType = 1;
npc.OutfitUpper = 103;
npc.OutfitMiddle = 150;
npc.OutfitLower = 53;
npc.CurrentPosition = npc.Home = new Position(32061,32192,7);
npc.Radius = 2;
npc.BaseSpeed = 80;
npc.HandleMessage = delegate() {
if (npc.IsIdle() && npc.GetMessage("hello$")) {
npc.AddChat("Hiho %N.");
npc.SetTalkingTo();
} else if (npc.IsIdle() && npc.GetMessage("hi$")) {
npc.AddChat("Hiho %N.");
npc.SetTalkingTo();
} else if (npc.IsIdle()) {
npc.SetIdle();

} else if (npc.IsBusy() && npc.GetMessage("hello$")) {
npc.AddChat("Nah, I am talking. Wait here.");
} else if (npc.IsBusy() && npc.GetMessage("hi$")) {
npc.AddChat("Nah, I am talking. Wait here.");
} else if (npc.IsBusy()) {
} else if (npc.GetMessage("bye")) {
npc.AddChat("Yeah, bye.");
npc.SetIdle();
} else if (npc.GetMessage("farewell")) {
npc.AddChat("Yeah, farewell.");
npc.SetIdle();
} else if (npc.GetMessage("how") && npc.GetMessage("are") && npc.GetMessage("you")) {
npc.AddChat("Fine enough.");
} else if (npc.GetMessage("job")) {
npc.AddChat("I am a farmer and a cook.");
} else if (npc.GetMessage("cook")) {
npc.AddChat("I try out old and new recipes. You can sell me all food you have.");
} else if (npc.GetMessage("recipe")) {
npc.AddChat("I would love to try a banana-pie. But I lack the bananas. If you get me one, I will reward you.");
} else if (npc.GetMessage("name")) {
npc.AddChat("Willie.");
} else if (npc.GetMessage("time")) {
npc.AddChat("Am I a clock or what?");
} else if (npc.GetMessage("help")) {
npc.AddChat("Help yourself, I have not stolen my time.");
} else if (npc.GetMessage("monster")) {
npc.AddChat("Are you afraid of monsters ... you baby?");
} else if (npc.GetMessage("dungeon")) {
npc.AddChat("I have no time for your dungeon nonsense.");
} else if (npc.GetMessage("sewer")) {
npc.AddChat("What about them? Do you live there?");
} else if (npc.GetMessage("god")) {
npc.AddChat("I am a farmer, not a preacher.");
} else if (npc.GetMessage("king")) {
npc.AddChat("I'm glad that we don't see many officials here.");
} else if (npc.GetMessage("obi")) {
npc.AddChat("This little $&#@& has only #@$*# in his mind. One day I will put a #@$@ in his *@&&#@!");
} else if (npc.GetMessage("seymour")) {
npc.AddChat("This joke of a man thinks he is sooo important.");
} else if (npc.GetMessage("dallheim")) {
npc.AddChat("Uhm, fine guy I think." );
} else if (npc.GetMessage("cipfried")) {
npc.AddChat("Our little monkey.");
} else if (npc.GetMessage("amber")) {
npc.AddChat("Quite a babe." );
} else if (npc.GetMessage("weapon")) {
npc.AddChat("I'm not in the weapon business, but if you don't stop to harass me, I will put my hayfork in your &$&#$ and *$!&&*# it.");
} else if (npc.GetMessage("magic")) {
npc.AddChat("I am magician in the kitchen.");
} else if (npc.GetMessage("spell")) {
npc.AddChat("I know how to spell and i know how to spit, you little @!#&&. Wanna see?.");
} else if (npc.GetMessage("tibia")) {
npc.AddChat("If I were you, I would stay here.");
} else if (npc.GetMessage("bread")) {
npc.ItemType = 134;
npc.Amount = 1;
npc.Price = 3;
npc.AddChat("Do you want to buy a bread for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("cheese")) {
npc.ItemType = 136;
npc.Amount = 1;
npc.Price = 5;
npc.AddChat("Do you want to buy a cheese for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("meat")) {
npc.ItemType = 642;
npc.Amount = 1;
npc.Price = 5;
npc.AddChat("Do you want to buy meat for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("ham")) {
npc.ItemType = 3458;
npc.Amount = 1;
npc.Price = 8;
npc.AddChat("Do you want to buy a ham for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("offer")) {
npc.AddChat("I can offer you bread, cheese, ham, or meat.");
} else if (npc.GetMessage("food")) {
npc.AddChat("Are you looking for food? I have bread, cheese, ham, and meat.");
} else if (npc.Topic == 1 && npc.GetMessage("yes") && ((Player)npc.TalkingTo()).GetItemCount(1356) > npc.Price) {
npc.AddChat("Here it is.");
((Player)npc.TalkingTo()).AppendRemoveItemCount(1356, npc.Price);
Item item = Item.CreateItem(npc.ItemType);
((Player)npc.TalkingTo()).AddCarryingItem(item);
} else if (npc.Topic == 1 && npc.GetMessage("yes")) {
npc.AddChat("I am sorry, but you do not have enough gold.");
} else if (npc.Topic == 1) {
npc.AddChat("Maybe later.");
} else if (npc.GetMessage("sell") && npc.GetMessage("bread")) {
npc.ItemType = 134;
npc.Amount = 1;
npc.Price = 1;
npc.AddChat("So, you want to sell a bread? Hmm, I give you %P gold, ok?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("cheese")) {
npc.ItemType = 136;
npc.Amount = 1;
npc.Price = 2;
npc.AddChat("So, you want to sell a cheese? Hmm, I give you %P gold, ok?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("meat")) {
npc.ItemType = 642;
npc.Amount = 1;
npc.Price = 2;
npc.AddChat("So, you want to sell meat? Hmm, I give you %P gold, ok?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("ham")) {
npc.ItemType = 3458;
npc.Amount = 1;
npc.Price = 4;
npc.AddChat("So, you want to sell a ham? Hmm, I give you %P gold, ok?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("salmon")) {
npc.ItemType = 2178;
npc.Amount = 1;
npc.Price = 2;
npc.AddChat("So, you want to sell a salmon? Hmm, I give you %P gold, ok?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("fish")) {
npc.AddChat("Go away with this stinking &*#@@!");
} else if (npc.GetMessage("sell") && npc.GetMessage("cherry")) {
npc.ItemType = 1667;
npc.Amount = 1;
npc.Price = 1;
npc.AddChat("So, you want to sell a cherry? Hmm, I give you %P gold, ok?");
npc.Topic = 2;
} else if (npc.GetMessage("sell")) {
npc.AddChat("I sell food of many kinds.");
} else if (npc.GetMessage("buy")) {
npc.AddChat("I buy food of any kind. Since I am a great cook I need much of it.");
} else if (npc.Topic == 2 && npc.GetMessage("yes") && ((Player)npc.TalkingTo()).GetItemCount(npc.ItemType) >= npc.Amount) {
npc.AddChat("Here you are.");
((Player)npc.TalkingTo()).AppendRemoveItemCount(npc.ItemType, npc.Amount);
Item item = Item.CreateItem(1356);
item.Count = (byte)npc.Price;
((Player)npc.TalkingTo()).AddCarryingItem(item);
} else if (npc.Topic == 2 && npc.GetMessage("yes")) {
npc.AddChat("You don't have one.");
} else if (npc.Topic == 2 && npc.GetMessage("no")) {
npc.AddChat("Then not.");
} else if (npc.GetMessage("banana")) {
npc.ItemType = 899;
npc.Amount = 1;
npc.AddChat("Have you found a banana for me?");
npc.Topic = 3;
} else if (npc.Topic == 3 && npc.GetMessage("yes") && ((Player)npc.TalkingTo()).GetItemCount(npc.ItemType) >= npc.Amount) {
npc.AddChat("A banana! Great. Take this shield, so the &#@&* monsters don't beat the &@*&@ out of you.");
((Player)npc.TalkingTo()).AppendRemoveItemCount(npc.ItemType, npc.Amount);
Item item = Item.CreateItem(4445);
((Player)npc.TalkingTo()).AddCarryingItem(item);
} else if (npc.Topic == 3 && npc.GetMessage("yes")) {
npc.AddChat("Hm, you don't have it.");
} else if (npc.Topic == 3 && npc.GetMessage("yes") && npc.Amount > 1) {
npc.AddChat("Sorry, you do not have so many.");
} else if (npc.Topic == 3 && npc.GetMessage("no")) {
npc.AddChat("Too bad.");
} else if (npc.Topic == 3) {
npc.AddChat("Too bad.");
} };
npc.Vanish =  "YOU RUDE $!@##&";
return npc;
