NPC npc = new NPC();
npc.Name = "Obi";
npc.CharType = 1;
npc.OutfitUpper = 134;
npc.OutfitMiddle = 38;
npc.OutfitLower = 53;
npc.CurrentPosition = npc.Home = new Position(32109,32204,7);
npc.Radius = 1;
npc.BaseSpeed = 50;
npc.HandleMessage = delegate() {
if (npc.IsIdle() && npc.GetMessage("hello$")) {
npc.AddChat("Hello, hello, %N! Please come in, look, and buy!");
npc.SetTalkingTo();
} else if (npc.IsIdle() && npc.GetMessage("hi$")) {
npc.AddChat("Hello, hello, %N! Please come in, look, and buy!");
npc.SetTalkingTo();
} else if (npc.IsIdle()) {
npc.SetIdle();

} else if (npc.IsBusy() && npc.GetMessage("hello$")) {
npc.AddChat("Please stand in line %N. I'll be with you in a moment.");
} else if (npc.IsBusy() && npc.GetMessage("hi$")) {
npc.AddChat("Please stand in line %N. I'll be with you in a moment.");
} else if (npc.IsBusy()) {
} else if (npc.GetMessage("bye")) {
npc.AddChat("Bye, bye.");
npc.SetIdle();
} else if (npc.GetMessage("farewell")) {
npc.AddChat("Bye, bye.");
npc.SetIdle();
} else if (npc.GetMessage("how") && npc.GetMessage("are") && npc.GetMessage("you")) {
npc.AddChat("I am fine, I am fine. I'm so glad to have you here as my customer.");
} else if (npc.GetMessage("job")) {
npc.AddChat("I am a merchant, just a humble merchant. What can I do for you?");
} else if (npc.GetMessage("name")) {
npc.AddChat("My name is Obi, just Obi, the honest merchant. Do you want to buy something?");
} else if (npc.GetMessage("time")) {
npc.AddChat("It is about %T. Yes, %T. I am so sorry, I have no watches to sell. Do you want to buy something else?");
} else if (npc.GetMessage("help")) {
npc.AddChat("I sell stuff to prices that low, that all other merchants would mock at my stupidity.");
} else if (npc.GetMessage("monster")) {
npc.AddChat("If you want to challenge the monsters, you need some weapons and armor I sell. You need them definitely!");
} else if (npc.GetMessage("dungeon")) {
npc.AddChat("If you want to explore the dungeons, you have to equip yourself with the vital stuff I am selling. It's vital in the deepest sense of the word.");
} else if (npc.GetMessage("sewer")) {
npc.AddChat("Oh, our sewer system is very primitive; so primitive it's overrun by rats. But the stuff I sell is safe from them. Do you want to buy some of it?");
} else if (npc.GetMessage("king")) {
npc.AddChat("The king encouraged salesmen to travel here, but only I dared to take the risk, and a risk it was!");
} else if (npc.GetMessage("seymour")) {
npc.AddChat("He is the head of the local academy. I encouraged him to sponsor you guy, but no one listens to Obi, no one listens to me, as usually.");
} else if (npc.GetMessage("hyacinth")) {
npc.AddChat("I don't like him, I dislike him deeply. He is so greedy that he doesn't want to share his profit from life fluids.");
} else if (npc.GetMessage("dallheim")) {
npc.AddChat("What a hero, what a hero." );
} else if (npc.GetMessage("amber")) {
npc.AddChat("She is beautiful, very, very beautiful. I hope I can impress her in some way.");
} else if (npc.GetMessage("willie")) {
npc.AddChat("This guy does not understand that he should entrust me with the foodbusiness, too. He really should do that and have more time for his farm." );
} else if (npc.GetMessage("bug")) {
npc.AddChat("Bugs plague this isle, but my wares are bugfree, totally bugfree.");
} else if (npc.GetMessage("stuff")) {
npc.AddChat("I sell equipment of all kinds, all kind available on this isle. Just ask me about my wares if you are interested.");
} else if (npc.GetMessage("tibia")) {
npc.AddChat("One day I will return to the continent as a rich, a very rich man!");
} else if (npc.GetMessage("sam")) {
npc.AddChat("My good old cousin Sam. Oh, how I miss him, how I miss him.");
} else if (npc.GetMessage("thais")) {
npc.AddChat("Oh, Thais, I'll be back, I'll be back one day.");
} else if (npc.GetMessage("sell") && npc.GetMessage("club")) {
npc.AddChat("I don't buy this garbage!");
} else if (npc.GetMessage("sell") && npc.GetMessage("dagger")) {
npc.ItemType = 858;
npc.Amount = 1;
npc.Price = 2;
npc.AddChat("Do you want to sell this garbage? I give you %P gold, ok?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("spear")) {
npc.ItemType = 3418;
npc.Amount = 1;
npc.Price = 3;
npc.AddChat("Do you want to sell this garbage? I give you %P gold, ok?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("hand") && npc.GetMessage("axe")) {
npc.ItemType = 1114;
npc.Amount = 1;
npc.Price = 4;
npc.AddChat("Do you want to sell a hand axe for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("rapier")) {
npc.ItemType = 2138;
npc.Amount = 1;
npc.Price = 5;
npc.AddChat("Do you want to sell a rapier for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("axe")) {
npc.ItemType = 2650;
npc.Amount = 1;
npc.Price = 7;
npc.AddChat("Do you want to sell an axe for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("hatchet")) {
npc.ItemType = 3162;
npc.Amount = 1;
npc.Price = 25;
npc.AddChat("Do you want to sell a hatchet for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("sabre")) {
npc.ItemType = 2394;
npc.Amount = 1;
npc.Price = 12;
npc.AddChat("Do you want to sell a sabre for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("sword")) {
npc.ItemType = 90;
npc.Amount = 1;
npc.Price = 25;
npc.AddChat("Do you want to sell a sword for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("mace")) {
npc.ItemType = 5722;
npc.Amount = 1;
npc.Price = 30;
npc.AddChat("Do you want to sell a mace for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("short") && npc.GetMessage("sword")) {
npc.ItemType = 7770;
npc.Amount = 1;
npc.Price = 10;
npc.AddChat("Do you want to sell a short sword for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("doublet")) {
npc.ItemType = 7260;
npc.Amount = 1;
npc.Price = 3;
npc.AddChat("Do you want to sell a doublet for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("leather") && npc.GetMessage("armor")) {
npc.ItemType = 2652;
npc.Amount = 1;
npc.Price = 5;
npc.AddChat("Do you want to sell a leather armor for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("chain") && npc.GetMessage("armor")) {
npc.ItemType = 1884;
npc.Amount = 1;
npc.Price = 40;
npc.AddChat("Do you want to sell a chain armor for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("brass") && npc.GetMessage("armor")) {
npc.ItemType = 2140;
npc.Amount = 1;
npc.Price = 150;
npc.AddChat("Do you want to sell a brass armor for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("leather") && npc.GetMessage("helmet")) {
npc.ItemType = 1116;
npc.Amount = 1;
npc.Price = 3;
npc.AddChat("Do you want to sell a leather helmet for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("chain") && npc.GetMessage("helmet")) {
npc.ItemType = 348;
npc.Amount = 1;
npc.Price = 12;
npc.AddChat("Do you want to sell a chain helmet for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("studded") && npc.GetMessage("helmet")) {
npc.ItemType = 6492;
npc.Amount = 1;
npc.Price = 20;
npc.AddChat("Do you want to sell a studded helmet for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("wooden") && npc.GetMessage("shield")) {
npc.ItemType = 861;
npc.Amount = 1;
npc.Price = 3;
npc.AddChat("Do you want to sell a wooden shield for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("studded") && npc.GetMessage("shield")) {
npc.ItemType = 4445;
npc.Amount = 1;
npc.Price = 16;
npc.AddChat("Do you want to sell a studded shield for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("brass") && npc.GetMessage("shield")) {
npc.ItemType = 605;
npc.Amount = 1;
npc.Price = 25;
npc.AddChat("Do you want to sell a brass shield for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("plate") && npc.GetMessage("shield")) {
npc.ItemType = 349;
npc.Amount = 1;
npc.Price = 40;
npc.AddChat("Do you want to sell a plate shield for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("copper") && npc.GetMessage("shield")) {
npc.ItemType = 5469;
npc.Amount = 1;
npc.Price = 50;
npc.AddChat("Do you want to sell a copper shield for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("leather") && npc.GetMessage("boots")) {
npc.ItemType = 888;
npc.Amount = 1;
npc.Price = 2;
npc.AddChat("Do you want to sell a pair of leather boots for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("sell") && npc.GetMessage("rope")) {
npc.ItemType = 74;
npc.Amount = 1;
npc.Price = 8;
npc.AddChat("Do you want to sell a rope for %P gold?");
npc.Topic = 2;
} else if (npc.GetMessage("spear")) {
npc.ItemType = 3418;
npc.Amount = 1;
npc.Price = 10;
npc.AddChat("Do you want to buy a spear for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("rapier")) {
npc.ItemType = 2138;
npc.Amount = 1;
npc.Price = 15;
npc.AddChat("Do you want to buy a rapier for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("sabre")) {
npc.ItemType = 2394;
npc.Amount = 1;
npc.Price = 25;
npc.AddChat("Do you want to buy a sabre for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("dagger")) {
npc.ItemType = 858;
npc.Amount = 1;
npc.Price = 5;
npc.AddChat("Do you want to buy a dagger for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("sickle")) {
npc.ItemType = 7514;
npc.Amount = 1;
npc.Price = 8;
npc.AddChat("Do you want to buy a sickle for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("hand") && npc.GetMessage("axe")) {
npc.ItemType = 1114;
npc.Amount = 1;
npc.Price = 8;
npc.AddChat("Do you want to buy a hand axe for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("axe")) {
npc.ItemType = 2650;
npc.Amount = 1;
npc.Price = 20;
npc.AddChat("Do you want to buy an axe for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("short") && npc.GetMessage("sword")) {
npc.ItemType = 7770;
npc.Amount = 1;
npc.Price = 30;
npc.AddChat("Do you want to buy a short sword for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("jacket")) {
npc.ItemType = 122;
npc.Amount = 1;
npc.Price = 10;
npc.AddChat("Do you want to buy a jacket for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("coat")) {
npc.ItemType = 378;
npc.Amount = 1;
npc.Price = 8;
npc.AddChat("Do you want to buy a coat for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("doublet")) {
npc.ItemType = 7260;
npc.Amount = 1;
npc.Price = 16;
npc.AddChat("Do you want to buy a doublet for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("leather") && npc.GetMessage("armor")) {
npc.ItemType = 2652;
npc.Amount = 1;
npc.Price = 25;
npc.AddChat("Do you want to buy a leather armor for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("leather") && npc.GetMessage("legs")) {
npc.ItemType = 633;
npc.Amount = 1;
npc.Price = 10;
npc.AddChat("Do you want to buy leather legs for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("leather") && npc.GetMessage("helmet")) {
npc.ItemType = 1116;
npc.Amount = 1;
npc.Price = 12;
npc.AddChat("Do you want to buy a leather helmet for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("studded") && npc.GetMessage("helmet")) {
npc.ItemType = 6492;
npc.Amount = 1;
npc.Price = 63;
npc.AddChat("Do you want to buy a studded helmet for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("chain") && npc.GetMessage("helmet")) {
npc.ItemType = 348;
npc.Amount = 1;
npc.Price = 52;
npc.AddChat("Do you want to buy a chain helmet for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("wooden") && npc.GetMessage("shield")) {
npc.ItemType = 861;
npc.Amount = 1;
npc.Price = 15;
npc.AddChat("Do you want to buy a wooden shield for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("studded") && npc.GetMessage("shield")) {
npc.ItemType = 4445;
npc.Amount = 1;
npc.Price = 50;
npc.AddChat("Do you want to buy a studded shield for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("torch")) {
npc.ItemType = 3393;
npc.Amount = 1;
npc.Price = 2;
npc.AddChat("Do you want to buy a torch for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("bag")) {
npc.ItemType = 317;
npc.Amount = 1;
npc.Price = 4;
npc.AddChat("Do you want to buy a bag for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("scroll")) {
npc.ItemType = 316;
npc.Amount = 1;
npc.Price = 5;
npc.AddChat("Do you want to buy a scroll for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("shovel")) {
npc.ItemType = 869;
npc.Amount = 1;
npc.Price = 10;
npc.AddChat("Do you want to buy a shovel for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("pick")) {
npc.AddChat("I am sorry, we are out of pick axes. I heard that old greedy Al Dee has some but he will charge a fortune.");
} else if (npc.GetMessage("backpack")) {
npc.ItemType = 573;
npc.Amount = 1;
npc.Price = 10;
npc.AddChat("Do you want to buy a backpack for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("scythe")) {
npc.ItemType = 612;
npc.Amount = 1;
npc.Price = 12;
npc.AddChat("Do you want to buy a scythe for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("rope")) {
npc.ItemType = 74;
npc.Amount = 1;
npc.Price = 50;
npc.AddChat("Do you want to buy a rope for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("rod")) {
npc.ItemType = 109;
npc.Amount = 1;
npc.Price = 150;
npc.AddChat("Do you want to buy a fishing rod for %P gold?");
npc.Topic = 1;
} else if (npc.GetMessage("wares")) {
npc.AddChat("I sell weapons, shields, armor, helmets, and equipment. For what do you want to ask?");
} else if (npc.GetMessage("offer")) {
npc.AddChat("I sell weapons, shields, armor, helmets, and equipment. For what do you want to ask?");
} else if (npc.GetMessage("weapon")) {
npc.AddChat("I sell spears, rapiers, sabres, daggers, hand axes, axes, and short swords. Just tell me what you want to buy.");
} else if (npc.GetMessage("armor")) {
npc.AddChat("I sell jackets, coats, doublets, leather armor, and leather legs. Just tell me what you want to buy.");
} else if (npc.GetMessage("helmet")) {
npc.AddChat("I sell leather helmets, studded helmets, and chain helmets. Just tell me what you want to buy.");
} else if (npc.GetMessage("shield")) {
npc.AddChat("I sell wooden shields and studded shields. Just tell me what you want to buy.");
} else if (npc.GetMessage("do") && npc.GetMessage("you") && npc.GetMessage("sell")) {
npc.AddChat("What do you need? I sell weapons, armor, helmets, shields, and equipment.");
} else if (npc.GetMessage("do") && npc.GetMessage("you") && npc.GetMessage("have")) {
npc.AddChat("What do you need? I sell weapons, armor, helmets, shields, and equipment.");
} else if (npc.GetMessage("sell")) {
npc.AddChat("I sell much, much indeed. Just read the blackboards for my awesome wares or just ask me.");
} else if (npc.Topic == 1 && npc.GetMessage("yes") && ((Player)npc.TalkingTo()).GetItemCount(1356) > npc.Price) {
npc.AddChat("Thank you. Here it is.");
((Player)npc.TalkingTo()).AppendRemoveItemCount(1356, npc.Price);
Item item = Item.CreateItem(npc.ItemType);
((Player)npc.TalkingTo()).AddCarryingItem(item);
} else if (npc.Topic == 1 && npc.GetMessage("yes")) {
npc.AddChat("Sorry, you do not have enough gold.");
} else if (npc.Topic == 1) {
npc.AddChat("Maybe you will buy it another time.");
} else if (npc.Topic == 2 && npc.GetMessage("yes") && ((Player)npc.TalkingTo()).GetItemCount(npc.ItemType) > npc.Amount) {
npc.AddChat("Ok. Here is your money.");
((Player)npc.TalkingTo()).AppendRemoveItemCount(npc.ItemType, npc.Amount);
Item item = Item.CreateItem(1356);
item.Count = (byte)npc.Price;
((Player)npc.TalkingTo()).AddCarryingItem(item);
} else if (npc.Topic == 2 && npc.GetMessage("yes")) {
npc.AddChat("Sorry, you do not have one.");
} else if (npc.Topic == 2 && npc.GetMessage("yes") && npc.Amount > 1) {
npc.AddChat("Sorry, you do not have that many.");
} else if (npc.Topic == 2) {
npc.AddChat("Maybe next time.");
} };
npc.Vanish =  "Bye, bye.";
return npc;
