NPC npc = new NPC();
npc.Name = "Amber";
npc.CharType = 1;
npc.CurrentPosition = npc.Home = new Position(32103,32182,8);
npc.Radius = 4;
npc.BaseSpeed = 70;
npc.HandleMessage = delegate() {
if (npc.IsIdle() && npc.GetMessage("hello$")) {
npc.AddChat("Oh hello, nice to see you %N.");
npc.SetTalkingTo();
} else if (npc.IsIdle() && npc.GetMessage("hi$")) {
npc.AddChat("Oh hello, nice to see you %N.");
npc.SetTalkingTo();
} else if (npc.IsIdle()) {
npc.SetIdle();

} else if (npc.IsBusy() && npc.GetMessage("hello$")) {
npc.AddChat("Sorry, I'm already talking to someone.");
} else if (npc.IsBusy() && npc.GetMessage("hi$")) {
npc.AddChat("Sorry, I'm already talking to someone.");
} else if (npc.IsBusy()) {
} else if (npc.GetMessage("bye")) {
npc.AddChat("See you later.");
npc.SetIdle();
} else if (npc.GetMessage("farewell")) {
npc.AddChat("See you later.");
npc.SetIdle();
} else if (npc.GetMessage("how") && npc.GetMessage("are") && npc.GetMessage("you")) {
npc.AddChat("I am recovering from a sea journey.");
} else if (npc.GetMessage("job")) {
npc.AddChat("I explore and seek adventure.");
} else if (npc.GetMessage("explore")) {
npc.AddChat("I have been almost everywhere in Tibia.");
} else if (npc.GetMessage("adventure")) {
npc.AddChat("I fought fierce monsters, climbed the highest mountains, and crossed the sea on a raft.");
} else if (npc.GetMessage("sea")) {
npc.AddChat("My trip over the sea was horrible. The weather was bad, the waves high and my raft quite simple.");
} else if (npc.GetMessage("time")) {
npc.AddChat("Sorry, I lost my watch in a storm.");
} else if (npc.GetMessage("help")) {
npc.AddChat("I can't help you much beyond information.");
} else if (npc.GetMessage("information")) {
npc.AddChat("Just ask and I'll try to answer.");
} else if (npc.GetMessage("dungeon")) {
npc.AddChat("I have not had the time to explore the dungeons of this isle, but I have seen two big caves in the east, and there is a ruined tower in the northwest.");
} else if (npc.GetMessage("sewer")) {
npc.AddChat("I like sewers. I made my very first battle experience in the Thais sewers. The small sewersystem of Rookgaard has some nasty rats to fight.");
} else if (npc.GetMessage("assistant")) {
npc.AddChat("I have a job of great responsibility. Mostly I keep annoying persons away from my boss.");
} else if (npc.GetMessage("monster")) {
npc.AddChat("Oh, I fought orcs, cyclopses, minotaurs, and even green dragons.");
} else if (npc.GetMessage("cyclops")) {
npc.AddChat("Horrible monsters they are.");
} else if (npc.GetMessage("minotaur")) {
npc.AddChat("Horrible monsters they are.");
} else if (npc.GetMessage("dragon")) {
npc.AddChat("Horrible monsters they are.");
} else if (npc.GetMessage("raft")) {
npc.AddChat("I left my raft at the south eastern shore. I forgot my private notebook on it. If you could return it to me I would be very grateful.");
} else if (npc.GetMessage("quest")) {
npc.AddChat("I left my raft at the south eastern shore. I forgot my private notebook on it. If you could return it to me I would be very grateful.");
} else if (npc.GetMessage("mission")) {
npc.AddChat("I left my raft at the south eastern shore. I forgot my private notebook on it. If you could return it to me I would be very grateful.");
} else if (npc.GetMessage("seymour")) {
npc.AddChat("I think this poor guy was a bad choice as the head of the academy.");
} else if (npc.GetMessage("academy")) {
npc.AddChat("A fine institution, but it needs definitely more funds from the king.");
} else if (npc.GetMessage("king")) {
npc.AddChat("King Tibianus is the ruler of Thais.");
} else if (npc.GetMessage("thais")) {
npc.AddChat("A fine city, but the king has some problems enforcing the law.");
} else if (npc.GetMessage("cipfried")) {
npc.AddChat("A gentle person. You should visit him, if you have problems.");
} else if (npc.GetMessage("dallheim")) {
npc.AddChat("An extraordinary warrior. He's the first and last line of defense of Rookgaard." );
} else if (npc.GetMessage("hyacinth")) {
npc.AddChat("Hyacinth is a great healer. He lives somewhere hidden on this isle.");
} else if (npc.GetMessage("willie")) {
npc.AddChat("He's funny in his own, gruffy way." );
} else if (npc.GetMessage("obi")) {
npc.AddChat("He's a funny little man.");
} else if (npc.GetMessage("weapon")) {
npc.AddChat("The best weapons on this isle are just toothpicks, compared with the weapons warriors of the mainland wield.");
} else if (npc.GetMessage("magic")) {
npc.AddChat("You can learn spells only in the guildhalls of the mainland.");
} else if (npc.GetMessage("tibia")) {
npc.AddChat("I try to explore each spot of Tibia, and one day I will succeed.");
} else if (npc.GetMessage("castle")) {
npc.AddChat("If you travel to Thais, you really should visit the marvelous castle.");
} else if (npc.GetMessage("book")) {
npc.ItemType = 1852;
npc.Amount = 1;
npc.AddChat("Do you bring me my notebook?");
npc.Topic = 1;
} else if (npc.GetMessage("notebook")) {
npc.ItemType = 1852;
npc.Amount = 1;
npc.AddChat("Do you bring me my notebook?");
npc.Topic = 1;
} else if (npc.Topic == 1 && npc.GetMessage("yes") && ((Player)npc.TalkingTo()).GetItemCount(npc.ItemType) >= npc.Amount) {
npc.AddChat("Excellent. Here, take this short sword, that might serve you well.");
((Player)npc.TalkingTo()).AppendRemoveItemCount(npc.ItemType, npc.Amount);
Item item = Item.CreateItem(3294);
((Player)npc.TalkingTo()).AddCarryingItem(item);
} else if (npc.Topic == 1 && npc.GetMessage("yes")) {
npc.AddChat("Hm, you don't have it.");
} else if (npc.Topic == 1) {
npc.AddChat("Too bad.");
} else if (npc.GetMessage("orcish")) {
npc.AddChat("I speak some orcish words, not much though, just 'yes' and 'no' and such basic.");
npc.Topic = 2;
} else if (npc.GetMessage("language")) {
npc.AddChat("I speak some orcish words, not much though, just 'yes' and 'no' and such basic.");
npc.Topic = 2;
} else if (npc.GetMessage("prisoner")) {
npc.AddChat("I speak some orcish words, not much though, just 'yes' and 'no' and such basic.");
npc.Topic = 2;
} else if (npc.GetMessage("orc")) {
npc.AddChat("Not the nicest guys you can encounter. I had some clashes with them and was prisoner of the orcs for some months." );
} else if (npc.Topic == 2 && npc.GetMessage("yes")) {
npc.AddChat("It's 'mok' in orcish. I help you more about that if you have some food.");
} else if (npc.Topic == 2 && npc.GetMessage("no")) {
npc.AddChat("In orcish that's 'burp'. I help you more about that if you have some food.");
} else if (npc.GetMessage("food")) {
npc.AddChat("My favorite dish is salmon. Oh please, bring me some of it.");
} else if (npc.GetMessage("salmon")) {
npc.ItemType = 2178;
npc.Amount = 1;
npc.AddChat("Yeah! If you give me some salmon I will tell you more about the orcish language.");
npc.Topic = 3;
} else if (npc.Topic == 3 && npc.GetMessage("yes") && ((Player)npc.TalkingTo()).GetItemCount(npc.ItemType) >= npc.Amount) {
npc.AddChat("Thank you. Orcs call arrows 'pixo'.");
((Player)npc.TalkingTo()).AppendRemoveItemCount(npc.ItemType, npc.Amount);
} else if (npc.Topic == 3 && npc.GetMessage("yes")) {
npc.AddChat("You don't have one!");
} else if (npc.Topic == 3) {
npc.AddChat("Ok, then I don't tell you more about the orcish language.");
} };
npc.Vanish =  "See you later.";
return npc;
