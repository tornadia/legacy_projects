            NPC npc = new NPC();
            npc.Name = "Cipfried";
            npc.CharType = 1;
	    npc.OutfitUpper = 34;
            npc.OutfitMiddle = 51;
            npc.OutfitLower = 103;
            npc.CurrentPosition = npc.Home = new Position(32097, 32217, 7);
            npc.Radius = 1;
            npc.BaseSpeed = 100;
            npc.HandleMessage = delegate() {
                if (npc.IsIdle() && npc.GetMessage("hello$")) {
                    npc.AddChat("Hello, %N! Feel free to ask me for help.");
                    npc.SetTalkingTo();
                } else if (npc.IsIdle() && npc.GetMessage("hi$")) {
                    npc.AddChat("Hello, %N! Feel free to ask me for help.");
                    npc.SetTalkingTo();
                } else if (npc.IsIdle()) {
                    npc.SetIdle();

                } else if (npc.IsBusy() && npc.GetMessage("hello$")) {
                    npc.AddChat("Please wait, %N. I already talk to someone!");
                } else if (npc.IsBusy() && npc.GetMessage("hi$")) {
                    npc.AddChat("Please wait, %N. I already talk to someone!");
                } else if (npc.IsBusy() && npc.GetMessage("heal$") && npc.TalkingTo().Burning != null) {
                    npc.AddChat("You are burning, %N. I will help you.");
                    npc.TalkingTo().BurningCheck = null;
                    npc.World.AddMagicEffect(MagicEffect.BLUE_SPARKLES, npc.TalkingTo().CurrentPosition);
                } else if (npc.IsBusy() && npc.GetMessage("heal$") && npc.TalkingTo().Poisoned != null) {
                    npc.AddChat("You are poisoned, %N. I will help you.");
                    npc.TalkingTo().PoisonedCheck = null;
                    npc.World.AddMagicEffect(MagicEffect.BLUE_SPARKLES, npc.TalkingTo().CurrentPosition);
                } else if (npc.IsBusy() && npc.GetMessage("heal$") && npc.TalkingTo().CurrentHP < 65) {
                    npc.AddChat("You are looking really bad, %N. Let me heal your wounds.");
                    npc.TalkingTo().CurrentHP = 65;
                    npc.World.AddMagicEffect(MagicEffect.BLUE_SPARKLES, npc.TalkingTo().CurrentPosition);
                } else if (npc.IsBusy() && npc.GetMessage("heal$")) {
                    npc.AddChat("You aren't looking really bad, %N. Sorry, I can't help you.");
                } else if (npc.IsBusy()) {
                } else if (npc.GetMessage("bye")) {
                    npc.AddChat("Farewell, %N!");
                    npc.SetIdle();
                } else if (npc.GetMessage("farewell")) {
                    npc.AddChat("Farewell, %N!");
                    npc.SetIdle();
                } else if (npc.GetMessage("job")) {
                    npc.AddChat("I am just a humble monk. Ask me if you need help or healing.");
                } else if (npc.GetMessage("name")) {
                    npc.AddChat("My name is Cipfried.");
                } else if (npc.GetMessage("monk")) {
                    npc.AddChat("I sacrifice my life to serve the good gods of Tibia.");
                } else if (npc.GetMessage("tibia")) {
                    npc.AddChat("That's where we are. The world of Tibia.");
                } else if (npc.GetMessage("rookgaard")) {
                    npc.AddChat("The gods have chosen this isle as the point of arrival for the newborn souls.");
                } else if (npc.GetMessage("god")) {
                    npc.AddChat("They created Tibia and all life on it. Visit our library and learn about them.");
                } else if (npc.GetMessage("life")) {
                    npc.AddChat("The gods decorated Tibia with various forms of life. Plants, the citizens, and even the monsters.");
                } else if (npc.GetMessage("plant")) {
                    npc.AddChat("Just walk around. You will see grass, trees, and bushes.");
                } else if (npc.GetMessage("citizen")) {
                    npc.AddChat("Only few people live here. Walk around and talk to them.");
                } else if (npc.GetMessage("obi")) {
                    npc.AddChat("He is a local shop owner.");
                } else if (npc.GetMessage("al") && npc.GetMessage("dee")) {
                    npc.AddChat("He is a local shop owner.");
                } else if (npc.GetMessage("seymour")) {
                    npc.AddChat("Seymour is a loyal follower of the king and responsibe for the academy.");
                } else if (npc.GetMessage("academy")) {
                    npc.AddChat("You should visit Seymour in the academy and ask him about a mission.");
                } else if (npc.GetMessage("willie")) {
                    npc.AddChat("He is a fine farmer. The farm is located to the left of the temple.");
                } else if (npc.GetMessage("monster")) {
                    npc.AddChat("They are a constant threat. Learn to fight by hunting rabbits, deers and sheeps. Then try to fight rats, bugs and perhaps spiders.");
                } else if (npc.GetMessage("help")) {
                    npc.AddChat("First you should try to get some gold and buy better equipment.");
                } else if (npc.GetMessage("hint")) {
                    npc.AddChat("First you should try to get some gold and buy better equipment.");
                } else if (npc.GetMessage("quest")) {
                    npc.AddChat("First you should try to get some gold and buy better equipment.");
                } else if (npc.GetMessage("task")) {
                    npc.AddChat("First you should try to get some gold and buy better equipment.");
                } else if (npc.GetMessage("what") && npc.GetMessage("do")) {
                    npc.AddChat("First you should try to get some gold and buy better equipment.");
                } else if (npc.GetMessage("gold")) {
                    npc.AddChat("You have to slay monsters and take their gold. Or sell food at Willie's farm.");
                } else if (npc.GetMessage("money")) {
                    npc.AddChat("If you need money, you have to slay monsters and take their gold. Look for spiders and rats.");
                } else if (npc.GetMessage("rat")) {
                    npc.AddChat("In the north of this temple you find a sewer grate. Use it to enter the sewers if you feel prepared. Don't forget a torch; you'll need it.");
                } else if (npc.GetMessage("sewer")) {
                    npc.AddChat("In the north of this temple you find a sewer grate. Use it to enter the sewers if you feel prepared. Don't forget a torch; you'll need it.");
                } else if (npc.GetMessage("equipment")) {
                    npc.AddChat("First you need some armor and perhaps a better weapon or a shield. A real adventurer needs a rope, a shovel, and a fishing pole, too.");
                } else if (npc.GetMessage("fight")) {
                    npc.AddChat("Take a weapon in your hand, activate your combat mode, and select a target. After a fight you should eat something to heal your wounds.");
                } else if (npc.GetMessage("slay")) {
                    npc.AddChat("Take a weapon in your hand, activate your combat mode, and select a target. After a fight you should eat something to heal your wounds.");
                } else if (npc.GetMessage("eat")) {
                    npc.AddChat("If you want to heal your wounds you should eat something. Willie sells excellent meals. But if you are very weak, come to me and ask me to heal you.");
                } else if (npc.GetMessage("food")) {
                    npc.AddChat("If you want to heal your wounds you should eat something. Willie sells excellent meals. But if you are very weak, come to me and ask me to heal you.");
                } else if (npc.GetMessage("heal$") && npc.TalkingTo().Burning != null) {
                    npc.AddChat("You are burning. I will help you.");
                    npc.TalkingTo().BurningCheck = null;
                    npc.World.AddMagicEffect(MagicEffect.BLUE_SPARKLES, npc.TalkingTo().CurrentPosition);
                } else if (npc.GetMessage("heal$") && npc.TalkingTo().Poisoned != null) {
                    npc.AddChat("You are poisoned. I will help you.");
                    npc.TalkingTo().PoisonedCheck = null;
                    npc.World.AddMagicEffect(MagicEffect.BLUE_SPARKLES, npc.TalkingTo().CurrentPosition);
                } else if (npc.GetMessage("heal$") && npc.TalkingTo().CurrentHP < 65) {
                    npc.AddChat("You are looking really bad. Let me heal your wounds.");
                    npc.TalkingTo().CurrentHP = 65;
                    npc.World.AddMagicEffect(MagicEffect.BLUE_SPARKLES, npc.TalkingTo().CurrentPosition);
                } else if (npc.GetMessage("heal$")) {
                    npc.AddChat("You aren't looking really bad. Sorry, I can't help you.");
                } else if (npc.GetMessage("time")) {
                    npc.AddChat("Now, it is %T, my child.");
                }
            };
            npc.Vanish = "Well, bye then.";
            return npc;