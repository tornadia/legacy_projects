AccountManager.ManagerName = "1";
AccountManager.ManagerPassword = null;
AccountManager manager = new AccountManager();

AccountManager.ChatDelegate[] chatDelegates = new AccountManager.ChatDelegate[10];

chatDelegates[0] = delegate(string msg) {
	manager.Index++;
	Tracer.Println("msg: " + msg);
};

manager.SetChatDelegates(chatDelegates);

return new AccountManager();