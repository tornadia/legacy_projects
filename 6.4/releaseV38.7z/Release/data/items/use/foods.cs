            Dictionary<ushort, UseItemDelegate> del =
                   (Dictionary<ushort, UseItemDelegate>)arg;

            ushort[] foodIDs = {642, 1922, 2178, 3458, 387, 643, 899, 1411
                               , 1667, 2435, 2691, 1668, 2180, 133, 134, 136};
            ushort[] foodAmts = {180, 144, 120, 360, 72, 156, 96, 216, 12, 108,
                                      350, 60, 108, 24, 120, 108 };

            for (int i = 0; i < foodIDs.Length; i++) {
                ushort foodAmt = foodAmts[i];
                ushort ID = foodIDs[i];
                del.Add(ID, delegate(Item item, Player user, GameWorld world) {
                    bool full = user.AppendEatFood(foodAmt);
			  if (!full) {
                       item.Count--;
                       if (item.Count == 0) {
                           world.AppendRemoveItem(item);
                       } else {
                           world.AppendUpdateItem(item);
                       }
			  }
                });
            }

            return null;
