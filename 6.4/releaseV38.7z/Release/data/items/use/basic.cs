           Dictionary<ushort, UseItemDelegate> del =
                (Dictionary<ushort, UseItemDelegate>)arg;


	    //Closed door.
            del.Add(4118, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 4374;
                world.AppendUpdateItem(item);
            });
		
  	    //Opened door
	    del.Add(4374, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 4118;
                world.AppendUpdateItem(item);

            });

	     //Sewer grate
            del.Add(8716, delegate(Item item, Player user, GameWorld world) {
                Position pos = item.CurrentPosition.Clone();
                pos.z++;
                world.HandleMove(user, pos, user.CurrentDirection);

            });

	    //Ladder
            del.Add(543, delegate(Item item, Player user, GameWorld world) {
                Position pos = item.CurrentPosition.Clone();
		pos.y++;
                pos.z--;
                world.HandleMove(user, pos, user.CurrentDirection);
            });

                    //Light a big torch
	    del.Add(3393, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 3649;
                world.AppendUpdateItem(item);

            });

                    //Unlight a big torch
	    del.Add(3649, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 3393;
                world.AppendUpdateItem(item);

            });

                    //Light a mid torch
	    del.Add(3905, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 4161;
                world.AppendUpdateItem(item);

            });

                    //Unlight a mid torch
	    del.Add(4161, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 3905;
                world.AppendUpdateItem(item);

            });

                    //Light a small torch
	    del.Add(4417, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 4673;
                world.AppendUpdateItem(item);

            });

                    //Unlight a small torch
	    del.Add(4673, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 4417;
                world.AppendUpdateItem(item);

            });

                    //Light a lamp
	    del.Add(1857, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 2113;
                world.AppendUpdateItem(item);

            });

                    //Unlight a lamp
	    del.Add(2113, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 1857;
                world.AppendUpdateItem(item);

            });

                    //Light a wall lamp(facing down)
	    del.Add(577, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 833;
                world.AppendUpdateItem(item);

            });

                    //Unlight a wall lamp(facing down)
	    del.Add(833, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 577;
                world.AppendUpdateItem(item);

            });

                    //Light a wall lamp(facing right)
	    del.Add(65, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 321;
                world.AppendUpdateItem(item);

            });

                    //Unlight a wall lamp(facing right)
	    del.Add(321, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 65;
                world.AppendUpdateItem(item);

            });

                    //Light a street lamp
	    del.Add(36, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 292;
                world.AppendUpdateItem(item);

            });

                    //Unlight a street lamp
	    del.Add(292, delegate(Item item, Player user, GameWorld world) {
                item.ItemID = 36;
                world.AppendUpdateItem(item);

            });



            return null;