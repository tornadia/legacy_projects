            Dictionary<ushort, WalkDelegate> del =
                (Dictionary<ushort, WalkDelegate>)arg;

            del.Add(31, delegate(Item item, Creature walker, GameWorld world, WalkType type) {
                if (type == WalkType.WALK_ON) {
                    Position pos = item.CurrentPosition.Clone();
                    pos.z--;
			  pos.y--;
                    world.HandleMove(walker, pos, Direction.NORTH, false);
                    return false;
                }
                return true;
            });

            del.Add(1823, delegate(Item item, Creature walker, GameWorld world, WalkType type) {
                if (type == WalkType.WALK_ON) {
                    Position pos = item.CurrentPosition.Clone();
                    pos.z--;
			  pos.x--;
                    world.HandleMove(walker, pos, Direction.NORTH, false);
                    return false;
                }
                return true;
            });

		del.Add(7948, delegate(Item item, Creature walker, GameWorld world, WalkType type) {
                if (type == WalkType.WALK_ON) {
                    Position pos = item.CurrentPosition.Clone();
                    pos.z++;
                    world.HandleMove(walker, pos, Direction.NORTH, false);
                    return false;
                }
                return true;
            });

		del.Add(8715, delegate(Item item, Creature walker, GameWorld world, WalkType type) {
                if (type == WalkType.WALK_ON) {
                    Position pos = item.CurrentPosition.Clone();
                    pos.z++;
                    world.HandleMove(walker, pos, Direction.NORTH, false);
                    return false;
                }
                return true;
            });

		del.Add(9228, delegate(Item item, Creature walker, GameWorld world, WalkType type) {
                if (type == WalkType.WALK_ON) {
                    Position pos = item.CurrentPosition.Clone();
                    pos.z++;
			  pos.y++;
                    world.HandleMove(walker, pos, Direction.SOUTH, false);
                    return false;
                }
                return true;
            });

		del.Add(8460, delegate(Item item, Creature walker, GameWorld world, WalkType type) {
                if (type == WalkType.WALK_ON) {
                    Position pos = item.CurrentPosition.Clone();
                    pos.z++;
			  pos.y++;
                    world.HandleMove(walker, pos, Direction.SOUTH, false);
                    return false;
                }
                return true;
            });

		del.Add(8204, delegate(Item item, Creature walker, GameWorld world, WalkType type) {
                if (type == WalkType.WALK_ON) {
                    Position pos = item.CurrentPosition.Clone();
                    pos.z++;
                    world.HandleMove(walker, pos, Direction.SOUTH, false);
                    return false;
                }
                return true;
            });

            return null;