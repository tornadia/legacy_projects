            Dictionary<ushort, WalkDelegate> del =
                (Dictionary<ushort, WalkDelegate>)arg;
		
		del.Add(7692, delegate(Item item, Creature walker, GameWorld world, WalkType type) {
                if (type == WalkType.WALK_ON) {
			item.ItemID = 7436;
                  world.AppendUpdateItem(item);
                }
                return true;
            });

		del.Add(7436, delegate(Item item, Creature walker, GameWorld world, WalkType type) {
                if (type == WalkType.WALK_OFF) {
			item.ItemID = 7692;
                  world.AppendUpdateItem(item);
                }
                return true;
            });

		return null;