            Dictionary<ushort, UseItemWithDelegate> del =
                (Dictionary<ushort, UseItemWithDelegate>)arg;

            del.Add(109, delegate(Item item, Player user, GameWorld world, Position posWith, byte stackpos) {
                         Thing thing = world.GetMovingSystem().GetThing(user, posWith, stackpos);
                         if (thing is Item) {
                             Item itemWith = (Item)thing;
                             if (itemWith.ItemID == 526) {
                                 world.AddMagicEffect(MagicEffect.LOOSE_ENERGY, posWith);
                                 byte fishingSkill = user.GetSkill(Constants.SKILL_FISHING);
                                 double formula = fishingSkill / 200.0 + .85 * (new Random().Next(0, 100) / 100.0);
                                 if (formula > 0.70) {
                                     user.AddCarryingItem(Item.CreateItem(1922));
                                 }
                                 user.AddFishingTry();
                             }
                         }
            });
            return null;
