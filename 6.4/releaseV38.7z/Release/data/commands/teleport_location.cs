            CommandInfo info = (CommandInfo)arg;
            info.Name = "!tl";
            info.AccessLevel = Constants.ACCESS_GAMEMASTER;
            info.CommandMethod = delegate(object[] args) {
                GameWorld world = (GameWorld)args[0];
                Map gameMap = (Map)args[1];
                string[] parameters = (string[])args[2];
                Creature creature = (Creature)args[3];
                string location = "";
                for (int i = 1; i < parameters.Length; i++) {
                    location += parameters[i];
                }
                location = location.ToLower();
                string[] names = {"Carlin", "Thais", "Venore", "Rookgaard",
                                   "Darashia", "Edron", "Ab\'Dendriel"};
                Position[] posLocations = {new Position(32360, 31782, 7),
                                   new Position(32369, 32241, 7),
                                   new Position(32957, 32076, 7),
                                   new Position(32097, 32219, 7),
                                   new Position(33214, 32455, 1),
                                   new Position(33217, 31814, 8),
				   new Position(32732, 31635, 7)
                               };
                Position pos = null;
                for (int i = 0; i < names.Length; i++) {
                    if (names[i].ToLower() == location.ToLower()) {
                        pos = world.GetGameMap().GetFreePosition(posLocations[i], creature);
                        if (pos == null) {
                            pos = posLocations[i];
                        }
                        break;
                    }
                }
                if (pos != null) {
                    world.HandleMove(creature, pos, creature.CurrentDirection);
                }
            };
            return null;