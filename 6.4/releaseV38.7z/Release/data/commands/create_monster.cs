            CommandInfo info = (CommandInfo)arg;
            info.Name = "!s";
            info.AccessLevel = Constants.ACCESS_ADMIN;
            info.CommandMethod = delegate(object[] args) {
                GameWorld world = (GameWorld)args[0];
                Map gameMap = (Map)args[1];
                string[] parameters = (string[])args[2];
                Creature creature = (Creature)args[3];
                 string monsterName = "";
		 for (int i = 1; i < parameters.Length; i++) {
		    if (monsterName == "") {
			monsterName = parameters[i];
		    } else {
		      monsterName = monsterName + " " + parameters[i];
		    }
		 }
                 Monster monster = Monster.CreateMonster(monsterName);
                 if (monster == null) {
                     return;
                 }
                 Position clone = creature.CurrentPosition.Clone();
                 clone.x++;
                 monster.CurrentPosition = clone;
                 world.SendAddMonster(monster, clone);
            };
            return null;