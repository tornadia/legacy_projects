            CommandInfo info = (CommandInfo)arg;
            info.Name = "!t";
            info.AccessLevel = Constants.ACCESS_GAMEMASTER;
            info.CommandMethod = delegate(object[] args) {
                GameWorld world = (GameWorld)args[0];
                Map gameMap = (Map)args[1];
                string[] parameters = (string[])args[2];
                Creature creature = (Creature)args[3];
                string playerName = "";
                for (int i = 1; i < parameters.Length; i++) {
                    playerName += parameters[i];
                }
                Player player = world.GetPlayer(playerName);
                if (player == null) {
                     creature.AddAnonymousChat(ChatAnonymous.WHITE, "A player with this name is not online.");
                    return;
                }

                Position pos = world.GetGameMap().GetFreePosition(player.CurrentPosition, creature);
                if (pos == null) {
                    pos = player.CurrentPosition.Clone();
                }

                world.AddMagicEffect(MagicEffect.BLUEBALL, creature.CurrentPosition);
                world.AppendHandleMove(creature, pos, creature.CurrentDirection, true);
                world.AddMagicEffect(MagicEffect.BLUEBALL, pos);

            };
            return null;
