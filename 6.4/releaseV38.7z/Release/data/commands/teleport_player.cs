            CommandInfo info = (CommandInfo)arg;
            info.Name = "!c";
            info.AccessLevel = Constants.ACCESS_GAMEMASTER;
            info.CommandMethod = delegate(object[] args) {
                GameWorld world = (GameWorld)args[0];
                Map gameMap = (Map)args[1];
                string[] parameters = (string[])args[2];
                Creature creature = (Creature)args[3];
                string playerName = "";
                for (int i = 1; i < parameters.Length; i++) {
                    playerName += parameters[i];
                }
                Player player = world.GetPlayer(playerName);
                if (player == null) {
			creature.AddAnonymousChat(ChatAnonymous.WHITE, "A player with this name is not online.");
                    return;
                }

                Position pos = world.GetGameMap().GetFreePosition(creature.CurrentPosition, player);
                if (pos == null) {
                    pos = creature.CurrentPosition.Clone();
                }

                world.AddMagicEffect(MagicEffect.BLUEBALL, player.CurrentPosition);
                world.AppendHandleMove(player, pos, player.CurrentDirection, true);
                world.AddMagicEffect(MagicEffect.BLUEBALL, pos);

            };
            return null;
