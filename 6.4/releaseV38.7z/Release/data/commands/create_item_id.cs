            CommandInfo info = (CommandInfo)arg;
            info.Name = "!i";
            info.AccessLevel = Constants.ACCESS_ADMIN;
            info.CommandMethod = delegate(object[] args) {
                GameWorld world = (GameWorld)args[0];
                Map gameMap = (Map)args[1];
                string[] parameters = (string[])args[2];
                Creature creature = (Creature)args[3];
                if (parameters.Length == 1) {
                    return;
                } else if (parameters.Length >= 2) {
                    ushort id = ushort.Parse(parameters[1]);
                    Item item = Item.CreateItem(id);
                    if (item != null) {
                        world.SendAddItem(item, creature.CurrentPosition.Clone());
                    }
                }
            };
            return null;