  CommandInfo info = (CommandInfo)arg;
            info.Name = "!n";
            info.AccessLevel = Constants.ACCESS_ADMIN;
            info.CommandMethod = delegate(object[] args) {
                GameWorld world = (GameWorld)args[0];
                Map gameMap = (Map)args[1];
                string[] parameters = (string[])args[2];
                Creature creature = (Creature)args[3];
                string itemName = "";
                for (int i = 1; i < parameters.Length; i++) {
                    if (itemName == "") {
                        itemName = parameters[i];
                    } else {
                        itemName = itemName + " " + parameters[i];
                    }
                }

                Item item = Item.CreateItem(itemName);
                if (item == null) {
                    return;
                }
                world.SendAddItem(item, creature.CurrentPosition.Clone());
            };
            return null;
