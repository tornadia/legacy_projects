            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "adura vita";
            spellInfo.Type = SpellType.RUNE;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Player player = (Player)args[1];
                Position pos = (Position)args[2];
                Spell spell = (Spell)args[3];
                spell.Name = spellInfo.Name;
		    spell.RequiresTarget = true;
                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = pos.Clone();
                spell.MaxDmg = (int)((player.Level * 2 + player.MagicLevel * 3) * 2) * -1;
	          spell.MinDmg = (int)(((double)(player.Level) * 2 + player.MagicLevel * 3) * 2.8) * -1;
                spell.RequiredMLevel = 4;
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.VocationsFor = new Vocation[]
                {Vocation.DRUID, Vocation.KNIGHT,
                 Vocation.PALADIN, Vocation.SORCERER};
                };
            return null;