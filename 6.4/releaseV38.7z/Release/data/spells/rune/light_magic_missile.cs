 SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "adori";
            spellInfo.Type = SpellType.RUNE;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Player player = (Player)args[1];
                Position pos = (Position)args[2];
                Spell spell = (Spell)args[3];
                spell.Name = spellInfo.Name;

                spell.RequiresTarget = true;
                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = pos.Clone();
                int baseVal = (player.Level * 2) + (player.MagicLevel * 3);
                spell.MinDmg = (int)(baseVal * .1);
                spell.MaxDmg = (int)(baseVal * .2);
                spell.RequiredMLevel = 0;
                spell.SpellEffect = MagicEffect.ENERGY_DAMAGE;
                spell.DistanceEffect = DistanceType.EFFECT_FIREBALL;
                spell.Immunity = ImmunityType.IMMUNE_ELECTRIC;

                spell.VocationsFor = new Vocation[]
                {Vocation.DRUID, Vocation.KNIGHT,
                 Vocation.PALADIN, Vocation.SORCERER};
            };
            return null;
