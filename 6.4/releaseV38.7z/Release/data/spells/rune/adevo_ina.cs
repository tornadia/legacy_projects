            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "adevo ina";
            spellInfo.Type = SpellType.RUNE;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Player player = (Player)args[1];
                Position pos = (Position)args[2];
                Spell spell = (Spell)args[3];
                spell.Name = spellInfo.Name;

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 4;
                spell.SpellEffect = MagicEffect.GREEN_SPARKLES;

                spell.VocationsFor = new Vocation[]
                {Vocation.DRUID, Vocation.KNIGHT,
                 Vocation.PALADIN, Vocation.SORCERER};

                spell.IsSpellValid = delegate(GameWorld world, string argument) {
                    Thing thing = world.GetMovingSystem().GetThing(player, spell.UseWithPos, spell.UseWithStackpos);
                    return thing != null && thing.GetEquipableItem() != null;
                };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    Map map = world.GetGameMap();
                    Thing thing = world.GetMovingSystem().GetThing(player, spell.UseWithPos, spell.UseWithStackpos);
                    Item item = thing.GetEquipableItem();
                    player.Polymorph = item.ItemID;
                    CreatureCheck check = new PolyMorphCheck();
                    check.World = world;
                    check.CurrentCreature = player;
                    player.PolymorphCheck = check;
                    world.AddEventInCS(20000, check.PerformCheck);
                    world.AppendUpdateOutfit(player);
                };
            };
            return null;