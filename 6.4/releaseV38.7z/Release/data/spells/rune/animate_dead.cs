            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "adana mort";
            spellInfo.Type = SpellType.RUNE;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Player player = (Player)args[1];
                Position pos = (Position)args[2];
                Spell spell = (Spell)args[3];
                spell.Name = spellInfo.Name;
                spell.SpellCenter = pos.Clone();
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.SpellArea = new bool[,] { { true } };
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.IsSpellValid = delegate(GameWorld world, string msg) {
                    Tile tile = world.GetGameMap().GetTile(pos);
                    if (tile != null) {
                        foreach (Thing thing in tile.GetThings()) {
                            Item item = (Item)thing;
                            //TODO: Look up corpses
                            return true;
                        }
                    }
                    return false;
                };
                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    foreach (Thing thing in hitBySpell) {
                        if (thing is Item) {
                            Item item = (Item)thing;
                            //TODO: look up corpses
                            world.AppendRemoveItem(item);
                            Monster monster = Monster.CreateMonster("skeleton");
                            monster.SetMaster(player);
                            world.AppendAddMonster(monster, hitPosition);
                            return;
                        }
                    }
                };

                spell.VocationsFor = new Vocation[] {Vocation.DRUID, Vocation.KNIGHT,
                 Vocation.PALADIN, Vocation.SORCERER};
            };
            return null;
