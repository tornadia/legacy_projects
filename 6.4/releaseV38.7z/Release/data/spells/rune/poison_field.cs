SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "adevo grav pox";
            spellInfo.Type = SpellType.RUNE;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Player player = (Player)args[1];
                Position pos = (Position)args[2];
                Spell spell = (Spell)args[3];
                spell.Name = spellInfo.Name;

                spell.Immunity = ImmunityType.IMMUNE_POISON;
                spell.SpellCenter = pos.Clone();

                spell.SpellEffect = MagicEffect.POISEN_RINGS;
                spell.DistanceEffect = DistanceType.EFFECT_ENERGY;
                spell.SpellArea = new bool[,] { { true } };
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 0;
                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    foreach (Thing thing in hitBySpell) {
                        if (thing is Creature) {
                            Creature creatureHit = (Creature)thing;
                            creatureHit.AppendPoisoned(new int[] {5,5,5,5,5,4,4,4,4,4,3,3,3,3,
                                3,3,3,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}, 500);
                        }
                    }
                    world.AppendAddItem(Item.CreateItem(2341), hitPosition);
                };

                spell.VocationsFor = new Vocation[] {Vocation.DRUID, Vocation.KNIGHT,
                 Vocation.PALADIN, Vocation.SORCERER};
            };
            return null;
