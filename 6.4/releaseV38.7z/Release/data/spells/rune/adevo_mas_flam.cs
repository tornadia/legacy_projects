 SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "adevo mas flam";
            spellInfo.Type = SpellType.RUNE;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Player player = (Player)args[1];
                Position pos = (Position)args[2];
                Spell spell = (Spell)args[3];
                spell.Name = spellInfo.Name;

                spell.Immunity = ImmunityType.IMMUNE_FIRE;
                spell.SpellCenter = pos.Clone();
                spell.SpellEffect = MagicEffect.FIRE_AREA;
                spell.SpellArea = new bool[,] {{true, true, true},
                                                {true, true, true},
                                                {true, true, true}};
                spell.MaxDmg = 20;
                spell.MinDmg = 20;
                spell.SpellEffect = MagicEffect.BURNED;
                spell.DistanceEffect = DistanceType.EFFECT_FIREBALL;
                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    foreach (Thing thing in hitBySpell) {
                        if (thing is Creature) {
                            Creature creatureHit = (Creature)thing;
                            creatureHit.AppendBurning(new int[] { 10, 10, 10, 10, 10 }, 900);
                        }
                    }
                    world.AppendAddItem(Item.CreateItem(37), hitPosition);
                };

                spell.VocationsFor = new Vocation[] {Vocation.DRUID, Vocation.KNIGHT,
                 Vocation.PALADIN, Vocation.SORCERER};
            };
            return null;
