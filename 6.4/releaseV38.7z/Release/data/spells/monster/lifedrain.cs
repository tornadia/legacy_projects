            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "lifedrain";
            spellInfo.Type = SpellType.MONSTER;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Creature creature = (Creature)args[1];
                int min = (int)args[2];
                int max = (int)args[3];
                Position center = (Position)args[4];
                Spell spell = (Spell)args[5];
                spell.Name = spellInfo.Name;
                spell.MinDmg = min;
                spell.MaxDmg = max;
                spell.SpellCenter = creature.GetCreatureAttacking().CurrentPosition;
                spell.SpellEffect = MagicEffect.GREEN_SPARKLES;
                spell.SpellArea = new bool[,] { { true } };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    Spell heal = Spell.CreateCreatureSpell("selfheal", null, creature, max * -1, min * -1, creature.CurrentPosition);
                    world.GetSpellSystem().CastSpell("", creature, heal, world);
                };
            };
            return null;