 SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "poisonfield";
            spellInfo.Type = SpellType.MONSTER;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Creature creature = (Creature)args[1];
                int min = (int)args[2];
                int max = (int)args[3];
                Position center = (Position)args[4];
                Spell spell = (Spell)args[5];
                spell.Name = spellInfo.Name;
                spell.Immunity = ImmunityType.IMMUNE_POISON;
                spell.SpellCenter = creature.GetCreatureAttacking().CurrentPosition;
                spell.SpellArea = new bool[,] {{true}};

                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.SpellEffect = MagicEffect.POISEN_RINGS;
                spell.DistanceEffect = DistanceType.EFFECT_ENERGY;
                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    foreach (Thing thing in hitBySpell) {
                        if (thing is Creature) {
                            Creature creatureHit = (Creature)thing;
                            creatureHit.AppendPoisoned(new int[] {5,5,5,5,5,4,4,4,4,4,3,3,3,3,
                                3,3,3,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}, 500);
                        }
                    } 
                    world.AppendAddItem(Item.CreateItem(2341), hitPosition);
                };
            };
            return null;