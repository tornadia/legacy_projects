            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "selfheal";
            spellInfo.Type = SpellType.MONSTER;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Creature creature = (Creature)args[1];
                int min = (int)args[2];
                int max = (int)args[3];
                Position center = (Position)args[4];
                Spell spell = (Spell)args[5];
                spell.Name = spellInfo.Name;
                spell.MinDmg = min;
                spell.MaxDmg = max;
                spell.SpellCenter = center;
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.SpellArea = new bool[,] { { true } };
            };
            return null;