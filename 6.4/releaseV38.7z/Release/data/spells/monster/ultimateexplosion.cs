 SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "ultimateexplosion";
            spellInfo.Type = SpellType.MONSTER;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Creature creature = (Creature)args[1];
                int min = (int)args[2];
                int max = (int)args[3];
                Position center = (Position)args[4];
                Spell spell = (Spell)args[5];
                spell.Name = spellInfo.Name;
                spell.MinDmg = min;
                spell.MaxDmg = max;
                spell.Immunity = ImmunityType.IMMUNE_PHYSICAL;
                spell.SpellCenter = creature.GetCreatureAttacking().CurrentPosition;
                spell.SpellEffect = MagicEffect.EXPLOSION_AREA;
                spell.DistanceEffect = DistanceType.EFFECT_FIREBALL;
                spell.SpellArea = new bool[,] 
                {
                {false, false, false, false, false, true,  false, false, false, false, false},
                {false, false, false, true,  true,  true,  true,  true,  false, false, false},
                {false, false, true,  true,  true,  true,  true,  true,  true,  false, false},
                {false, true,  true,  true,  true,  true,  true,  true,  true,  true,  false},
                {false, true,  true,  true,  true,  true,  true,  true,  true,  true,  false},
                {true,  true,  true,  true,  true,  false, true,  true,  true,  true,  true },
                {false, true,  true,  true,  true,  true,  true,  true,  true,  true,  false},
                {false, true,  true,  true,  true,  true,  true,  true,  true,  true,  false},
                {false, false, true,  true,  true,  true,  true,  true,  true,  false, false},
                {false, false, false, true,  true,  true,  true,  true,  false, false, false},
                {false, false, false, false, false, true,  false, false, false, false, false}};
            };
            return null;