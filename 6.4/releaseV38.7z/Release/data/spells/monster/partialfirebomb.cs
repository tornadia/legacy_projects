	   SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "partialfirebomb";
            spellInfo.Type = SpellType.MONSTER;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Creature creature = (Creature)args[1];
                int min = (int)args[2];
                int max = (int)args[3];
                Position center = (Position)args[4];
                Spell spell = (Spell)args[5];
                spell.Name = spellInfo.Name;
                spell.MinDmg = min;
                spell.MaxDmg = max;
                spell.Immunity = ImmunityType.IMMUNE_FIRE;
                spell.SpellCenter = creature.GetCreatureAttacking().CurrentPosition;
                spell.SpellEffect = MagicEffect.FIRE_AREA;
                spell.SpellArea = new bool[,]
                {
                {false, true, false},
                {true, true, true},
                {false, true, false}
                };
                spell.MaxDmg = 20;
                spell.MinDmg = 20;
                spell.SpellEffect = MagicEffect.BURNED;
                spell.DistanceEffect = DistanceType.EFFECT_FIREBALL;
                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    foreach (Thing thing in hitBySpell) {
                        if (thing is Creature) {
                            Creature creatureHit = (Creature)thing;
                            creatureHit.AppendBurning(new int[] { 10, 10, 10, 10, 10 }, 900);
                        }
                    }
                    world.AppendAddItem(Item.CreateItem(37), hitPosition);
                };
            };
            return null;