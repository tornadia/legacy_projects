SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "energybeam";
            spellInfo.Type = SpellType.MONSTER;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Creature creature = (Creature)args[1];
                int min = (int)args[2];
                int max = (int)args[3];
                Position center = (Position)args[4];
                Spell spell = (Spell)args[5];
                string argument = (string)args[6];
                spell.Name = spellInfo.Name;

                spell.SpellCenter = creature.CurrentPosition.Clone();
                spell.MinDmg = min;
                spell.MaxDmg = max;
                spell.SpellEffect = MagicEffect.ENERGY_DAMAGE;
                spell.Immunity = ImmunityType.IMMUNE_ELECTRIC;
                switch (creature.CurrentDirection) {
                    case Direction.NORTH:
                        spell.SpellArea = new bool[,] 
                {
                {true},
                {true},
                {true},
                {true},
                {true},
                {false},
                {false},
                {false},
                {false},
                {false},
                {false}
                };
                        break;
                    case Direction.SOUTH:
                        spell.SpellArea = new bool[,] 
                {
                {false},
                {false},
                {false},
                {false},
                {false},
                {false},
                {true},
                {true},
                {true},
                {true},
                {true}
                };
                        break;
                    case Direction.EAST:
                        spell.SpellArea = new bool[,] 
                {
                {false, false,  false, false, false,  false , true, true,  true, true, true},
                };
                        break;
                    case Direction.WEST:
                        spell.SpellArea = new bool[,] 
                {
                {true, true,  true, true, true,  false , false, false,  false, false, false},
                };
                        break;
                }
            };
            return null;