SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "electricfield";
            spellInfo.Type = SpellType.MONSTER;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Creature creature = (Creature)args[1];
                int min = (int)args[2];
                int max = (int)args[3];
                Position center = (Position)args[4];
                Spell spell = (Spell)args[5];
                spell.Name = spellInfo.Name;
                spell.Immunity = ImmunityType.IMMUNE_ELECTRIC;
                spell.SpellCenter = creature.GetCreatureAttacking().CurrentPosition;
                spell.SpellArea = new bool[,] { { true } };

                spell.MaxDmg = 30;
                spell.MinDmg = 30;
                spell.SpellEffect = MagicEffect.ENERGY_DAMAGE;
                spell.DistanceEffect = DistanceType.EFFECT_ENERGY;
                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    foreach (Thing thing in hitBySpell) {
                        if (thing is Creature) {
                            Creature creatureHit = (Creature)thing;
                            creatureHit.AppendElectricuted(new int[] {25}, 500);
                        }
                    }
                    world.AppendAddItem(Item.CreateItem(1061), hitPosition);
                };
            };
            return null;