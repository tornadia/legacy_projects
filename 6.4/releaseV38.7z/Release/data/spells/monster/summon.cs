            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "summon";
            spellInfo.Type = SpellType.MONSTER;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string name = (string)args[0];
                Creature creature = (Creature)args[1];
                int min = (int)args[2];
                int max = (int)args[3];
                Position center = (Position)args[4];
                Spell spell = (Spell)args[5];
                string argument = (string)args[6];
                spell.Name = spellInfo.Name;

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = creature.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.SpellEffect = MagicEffect.GREEN_SPARKLES;
                spell.IsSpellValid = delegate(GameWorld world, string sArg) {
		    //Console.WriteLine("summoncount: " + creature.GetSummons().Count);
		    //Console.WriteLine("maxSummons: " + creature.MaxSummons);
                    return creature.GetSummons().Count < creature.MaxSummons &&
                        world.GetGameMap().GetFreePosition(creature.CurrentPosition, null) != null;
                };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    Monster monster = Monster.CreateMonster(argument);
                    monster.SetMaster(creature);
                    Position pos = world.GetGameMap().GetFreePosition(creature.CurrentPosition, monster);
                    world.AppendAddMonster(monster, pos);
                };
            };
            return null;