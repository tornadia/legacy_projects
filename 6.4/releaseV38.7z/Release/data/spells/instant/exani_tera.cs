            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exani tera";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 1;
                spell.ManaCost = 20;
                spell.SpellEffect = MagicEffect.BLUEBALL;
                spell.VocationsFor = new Vocation[]
                {Vocation.DRUID, Vocation.KNIGHT,
                 Vocation.PALADIN, Vocation.SORCERER};
                spell.IsSpellValid = delegate(GameWorld world, string msg) {
                    Tile tile = world.GetGameMap().GetTile(spell.SpellCenter);
                    Item ground = (Item)tile.GetThings()[0];
                    if (ground.ItemID == 8971) {
                        return true;
                    }
                    return false;
                };

                spell.Action = delegate(GameWorld world, Position position, List<Thing> hit) {
                    Position pos = player.CurrentPosition.Clone();
                    pos.z--;
                    pos.y++;
                    world.AppendHandleMove(player, pos, player.CurrentDirection, true);
                };
            };
            return null;
