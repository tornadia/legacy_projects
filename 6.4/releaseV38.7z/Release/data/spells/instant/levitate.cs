            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exani hur";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 3;
                spell.ManaCost = 50;
                spell.SpellEffect = MagicEffect.BLUEBALL;
                spell.VocationsFor = new Vocation[]
                {Vocation.DRUID, Vocation.KNIGHT,
                 Vocation.PALADIN, Vocation.SORCERER};

                spell.IsSpellValid = delegate(GameWorld world, string msg) {
                    Position newPos = 
                        Position.GetNewPosition(player.CurrentPosition, player.CurrentDirection);
                    argument = argument.ToLower();
                    if (argument == "up") {
                        newPos.z--;
                    } else if (argument == "down") {
                        newPos.z++;
                    } else {
                        return false;
                    }

                    Tile tile = world.GetGameMap().GetTile(newPos);
                    if (tile == null) {
                        return false;
                    }
                    return !tile.ContainsType(Constants.TYPE_BLOCKS_AUTO_WALK);
                };

                spell.Action = delegate(GameWorld world, Position position, List<Thing> hit) {
                    Position newPos =
                         Position.GetNewPosition(player.CurrentPosition, player.CurrentDirection);
                    argument = argument.ToLower();
                    if (argument == "up") {
                        newPos.z--;
                    } else if (argument == "down") {
                        newPos.z++;
                    }
                    world.AppendHandleMove(player, newPos, player.CurrentDirection, false);
                };
            };
            return null;
