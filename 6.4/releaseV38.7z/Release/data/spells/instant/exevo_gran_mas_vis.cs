            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exevo gran mas vis";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.RequiredMLevel = 40;
                spell.ManaCost = 800;
                spell.MinDmg = (int) ((player.Level * 2 + player.MagicLevel * 3) * 2.3 - 30);

                spell.MaxDmg = (player.Level * 2 + player.MagicLevel * 3) * 3;
                spell.Immunity = ImmunityType.IMMUNE_PHYSICAL;
                spell.SpellArea = new bool[,] 
                {
                {false, false, false, false, false, true,  false, false, false, false, false},
                {false, false, false, true,  true,  true,  true,  true,  false, false, false},
                {false, false, true,  true,  true,  true,  true,  true,  true,  false, false},
                {false, true,  true,  true,  true,  true,  true,  true,  true,  true,  false},
                {false, true,  true,  true,  true,  true,  true,  true,  true,  true,  false},
                {true,  true,  true,  true,  true,  false, true,  true,  true,  true,  true },
                {false, true,  true,  true,  true,  true,  true,  true,  true,  true,  false},
                {false, true,  true,  true,  true,  true,  true,  true,  true,  true,  false},
                {false, false, true,  true,  true,  true,  true,  true,  true,  false, false},
                {false, false, false, true,  true,  true,  true,  true,  false, false, false},
                {false, false, false, false, false, true,  false, false, false, false, false}};
                spell.SpellEffect = MagicEffect.EXPLOSION_AREA; ;
                spell.VocationsFor = new Vocation[] {Vocation.SORCERER};
            };
            return null;