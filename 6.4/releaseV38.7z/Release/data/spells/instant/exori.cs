            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exori";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { {true, true, true },
                                                {true, false, true},
                                                {true, true, true }};
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MinDmg = (int)((player.Level * 1.5 + player.MagicLevel * 1.5) * 1.2);
 	            spell.MaxDmg = (int)((player.Level * 1.5 + player.MagicLevel * 1.5) * 2.3);
                spell.RequiredMLevel = 5;
                spell.ManaCost = (uint)(player.Level * 4);
                spell.SpellEffect = MagicEffect.HIT_AREA;
                spell.VocationsFor = new Vocation[] { Vocation.KNIGHT };
            };
            return null;