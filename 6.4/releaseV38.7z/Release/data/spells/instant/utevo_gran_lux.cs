            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "utevo gran lux";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 3;
                spell.ManaCost = 60;
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.VocationsFor = new Vocation[] {
                    Vocation.DRUID, Vocation.SORCERER, Vocation.KNIGHT, Vocation.PALADIN
                };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    player.AppendSpellLightLevel(9, 695);
                };
            };
            return null;