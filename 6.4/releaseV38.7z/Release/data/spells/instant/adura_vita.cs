            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "adura vita";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 11;
                spell.ManaCost = 100;
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.VocationsFor = new Vocation[] { Vocation.DRUID };
                spell.IsSpellValid = delegate(GameWorld world, string msg) {
                    return (player.GetItemCount(79, Constants.INV_RIGHT_HAND) > 0
                        || player.GetItemCount(79, Constants.INV_LEFT_HAND) > 0) ;
                };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    player.AppendCreateRune(79, 3407, 1);
                };
            };
            return null;