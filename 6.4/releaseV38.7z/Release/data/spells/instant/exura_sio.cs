            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exura sio";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 7;
                spell.ManaCost = 70;
                spell.SpellEffect = MagicEffect.GREEN_SPARKLES;
                spell.VocationsFor = new Vocation[] { Vocation.DRUID, Vocation.SORCERER };
                spell.IsSpellValid = delegate(GameWorld world, string sArg) {
                    return world.IsPlayerOnline(argument);
                };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    Player friend = world.GetPlayer(argument);
                    int max = (int)(((player.Level * 2 + player.MagicLevel * 3) * 3) * -1);
                    int min = (int)(((player.Level * 2 + player.MagicLevel * 3) * 3 + 40) * -1);
                    Spell healFriend = Spell.CreateCreatureSpell("selfheal", null, friend, min, max,
                        friend.CurrentPosition);
                    world.GetSpellSystem().CastSpell("", friend, healFriend, world);
                };
            };
            return null;
