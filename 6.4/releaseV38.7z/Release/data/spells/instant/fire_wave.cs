            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exevo flam hur";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

		spell.SpellCenter = player.CurrentPosition.Clone();
                spell.RequiredMLevel = 7;
                spell.ManaCost = 80;
                spell.MinDmg = (int) ((player.Level * 2 + player.MagicLevel * 3) * .25);
                spell.MaxDmg = (int)((player.Level * 2 + player.MagicLevel * 3) * .60);
                spell.Immunity = ImmunityType.IMMUNE_FIRE;
                spell.SpellEffect = MagicEffect.FIRE_AREA;
                switch (player.CurrentDirection) {
                    case Direction.NORTH:
                        spell.SpellArea = new bool[,] 
                {
                {true,  true,  true},
                {true,  true,  true},
                {true,  true,  true},
                {false, true,  false},
                {false, true,  false},
                {false, false, false},
                {false, false, false},
                {false, false, false},
                {false, false, false},
                {false, false, false},
                {false, false, false}};
                        break;
                    case Direction.SOUTH:
                        spell.SpellArea = new bool[,] 
                {
                {false, false, false},
                {false, false, false},
                {false,  false, false},
                {false, false, false},
                {false, false,  false},
                {false, false, false},
                {false, true,  false},
                {false, true,  false},
                {true,  true,  true},
                {true,  true,  true},
                {true,  true,  true}};
                        break;
                    case Direction.EAST:
                        spell.SpellArea = new bool[,] 
                {
                {false, false,  false, false, false,  false, false, false,  true, true, true},
                {false, false,  false, false, false,  false , true, true,  true, true, true},
                {false,  false,  false,  false, false,  false, false, false,  true, true, true}
                };
                        break;
                    case Direction.WEST:
                        spell.SpellArea = new bool[,] 
                {
                {true, true,  true, false, false,  false, false, false, false, false, false},
                {true, true,  true, true, true,  false , false, false, false, false, false},
                {true,  true,  true,  false, false,  false, false, false, false, false, false}
                };
                        break;
                }

                spell.VocationsFor = new Vocation[] { Vocation.SORCERER};
            };
            return null;
