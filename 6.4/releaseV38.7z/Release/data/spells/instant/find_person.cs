            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exiva";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 0;
                spell.ManaCost = 20;
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.VocationsFor = new Vocation[] { Vocation.SORCERER, Vocation.KNIGHT,
                    Vocation.DRUID, Vocation.PALADIN };
                spell.IsSpellValid = delegate(GameWorld world, string msg) {
                    if (!world.IsPlayerOnline(argument)) {
                        player.AddStatusMessage("A player with this name is not online.");
                        return false;
                    }
                    return true;
                };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    Player playerExiva = world.GetPlayer(argument);
                    Position lookPos = player.CurrentPosition;
                    Position searchPos = playerExiva.CurrentPosition;
                    int dx = lookPos.x - searchPos.x;
                    int dy = lookPos.y - searchPos.y;
                    int dz = lookPos.z - searchPos.z;
                    FindDistance distance;
                    FindDirection direction;
                    FindLevel level;
                    if (dz > 0) {
                        level = FindLevel.LEVEL_HIGHER;
                    } else if (dz < 0) {
                        level = FindLevel.LEVEL_LOWER;
                    } else {
                        level = FindLevel.LEVEL_SAME;
                    }
                    //getting distance
                    if (Math.Abs(dx) <= 4 && Math.Abs(dy) <= 4) {
                        distance = FindDistance.DISTANCE_BESIDE;
                    } else {
                        int distance2 = dx * dx + dy * dy;
                        if (distance2 <= 10000) {
                            distance = FindDistance.DISTANCE_CLOSE;
                        } else if (distance2 <= 75076) {
                            distance = FindDistance.DISTANCE_FAR;
                        } else {
                            distance = FindDistance.DISTANCE_VERYFAR;
                        }
                    }
                    //getting direction
                    float tan;
                    if (dx != 0) {
                        tan = (float)dy / (float)dx;
                    } else {
                        tan = 10.0f;
                    }
                    if (Math.Abs(tan) < 0.4142) {
                        if (dx > 0) {
                            direction = FindDirection.DIR_W;
                        } else {
                            direction = FindDirection.DIR_E;
                        }
                    } else if (Math.Abs(tan) < 2.4142) {
                        if (tan > 0) {
                            if (dy > 0) {
                                direction = FindDirection.DIR_NW;
                            } else {
                                direction = FindDirection.DIR_SE;
                            }
                        } else { //tan < 0
                            if (dx > 0) {
                                direction = FindDirection.DIR_SW;
                            } else {
                                direction = FindDirection.DIR_NE;
                            }
                        }
                    } else {
                        if (dy > 0) {
                            direction = FindDirection.DIR_N;
                        } else {
                            direction = FindDirection.DIR_S;
                        }
                    }

                    StringBuilder ss = new StringBuilder();
                    ss.Append(playerExiva.Name + " ");

                    if (distance == FindDistance.DISTANCE_BESIDE) {
                        if (level == FindLevel.LEVEL_SAME)
                            ss.Append("is standing next to you");
                        else if (level == FindLevel.LEVEL_HIGHER)
                            ss.Append("is above you");
                        else if (level == FindLevel.LEVEL_LOWER)
                            ss.Append("is below you");
                    } else {
                        switch (distance) {
                            case FindDistance.DISTANCE_CLOSE:
                                if (level == FindLevel.LEVEL_SAME) {
                                    ss.Append("is to the");
                                } else if (level == FindLevel.LEVEL_HIGHER) {
                                    ss.Append("is on a higher level to the");
                                } else if (level == FindLevel.LEVEL_LOWER) {
                                    ss.Append("is on a lower level to the");
                                }
                                break;

                            case FindDistance.DISTANCE_FAR:
                                ss.Append("is far to the");
                                break;

                            case FindDistance.DISTANCE_VERYFAR:
                                ss.Append("is very far to the");
                                break;

                            default:
                                break;
                        }

                        ss.Append(" ");
                        switch (direction) {
                            case FindDirection.DIR_N:
                                ss.Append("north");
                                break;

                            case FindDirection.DIR_S:
                                ss.Append("south");
                                break;
                            case FindDirection.DIR_E:

                                ss.Append("east");
                                break;

                            case FindDirection.DIR_W:
                                ss.Append("west");
                                break;

                            case FindDirection.DIR_NE:
                                ss.Append("north-east");
                                break;

                            case FindDirection.DIR_NW:
                                ss.Append("north-west");
                                break;

                            case FindDirection.DIR_SE:
                                ss.Append("south-east");
                                break;

                            case FindDirection.DIR_SW:
                                ss.Append("south-west");
                                break;
                        }
                    }

                    ss.Append(".");
                    player.AddAnonymousChat(ChatAnonymous.WHITE, ss.ToString());
                };
            };
            return null;
