            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "adana mort";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 7;
                spell.ManaCost = 300;
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.VocationsFor = new Vocation[] { Vocation.SORCERER, Vocation.DRUID };
                spell.IsSpellValid = delegate(GameWorld world, string msg) {
                    return (player.GetItemCount(79, Constants.INV_RIGHT_HAND) > 0
                        || player.GetItemCount(79, Constants.INV_LEFT_HAND) > 0);
                };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    player.AppendCreateRune(79, 14415, 1);
                };
            };
            return null;
