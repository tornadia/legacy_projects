            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exura gran mas res";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { {false, true, true, true, false },
								{true, true, true, true, true},
								 {true, true, true, true, true},
								{true, true, true, true, true},
								{false, true, true, true, false }
		    };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = (int)((player.Level * 2 + player.MagicLevel * 3) * 1.2) * -1;
                spell.MinDmg = (int)(((double)(player.Level) * 2 + player.MagicLevel * 3) * 1.5) * -1;
                spell.RequiredMLevel = 15;
                spell.ManaCost = 150;
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.VocationsFor = new Vocation[]
                {Vocation.DRUID};
            };
            return null;
