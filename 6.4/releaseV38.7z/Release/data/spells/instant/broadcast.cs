            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exisa mas";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 4;
                spell.ManaCost = 90;
                spell.SpellEffect = MagicEffect.GREEN_SPARKLES;
                spell.VocationsFor = new Vocation[] { Vocation.SORCERER, Vocation.KNIGHT, Vocation.DRUID, Vocation.PALADIN};

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    world.AppendBroadcast(player, argument);
                };
            };
            return null;
