            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exevo con";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 2;
                spell.ManaCost = 40;
                spell.SpellEffect = MagicEffect.GREEN_SPARKLES;
                spell.VocationsFor = new Vocation[] { Vocation.PALADIN };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    Item arrows = Item.CreateItem(350);
                    arrows.Count = 15;
                    player.AddCarryingItem(arrows);
                };
            };
            return null;