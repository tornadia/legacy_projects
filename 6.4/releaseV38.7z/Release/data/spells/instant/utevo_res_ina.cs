            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "utevo res ina";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 10;
                spell.ManaCost = 100;
                spell.SpellEffect = MagicEffect.GREEN_SPARKLES;
                spell.VocationsFor = new Vocation[] { Vocation.DRUID, Vocation.SORCERER };
                spell.IsSpellValid = delegate(GameWorld world, string sArg) {
                    return (Monster.GetCharType(argument) != 0);
                };

                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    byte chartype = Monster.GetCharType(argument);
                    player.Polymorph = chartype;
                    player.PolymorphCharType = chartype;
                    CreatureCheck check = new PolyMorphCheck();
                    check.CurrentCreature = player;
                    check.World = player.World;
                    player.PolymorphCheck = check;

                    world.AddEventInCS(20000, check.PerformCheck);
                    world.AppendUpdateOutfit(player);
                };
            };
            return null;