            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exori mort";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.RequiredMLevel = 2;
                spell.ManaCost = 20;
                spell.MinDmg = (int)(player.Level + (player.MagicLevel * 0.8));
                spell.MaxDmg = (player.Level + player.MagicLevel);
                spell.Immunity = ImmunityType.IMMUNE_PHYSICAL;
                switch (player.CurrentDirection) {
                    case Direction.NORTH:
                        spell.SpellArea = new bool[,] 
                {
                {false,  true,  false},
                {false,  false, false},
                {false,  false,  false}               
                };
                        break;
                    case Direction.WEST:
                        spell.SpellArea = new bool[,] 
                {
                {false,  false,  false},
                {true,  false, false},
                {false,  false,  false}               
                };
                        break;
                    case Direction.EAST:
                        spell.SpellArea = new bool[,] 
                {
                {false,  false,  false},
                {false,  false, true},
                {false,  false,  false}               
                };
                        break;
                    case Direction.SOUTH:
                        spell.SpellArea = new bool[,] 
                {
                {false,  false,  false},
                {false,  false, false},
                {false,  true,  false}               
                };
                        break;
                }
                spell.SpellEffect = MagicEffect.MORT_AREA; ;
                spell.VocationsFor = new Vocation[] { Vocation.SORCERER, Vocation.DRUID };
            };
            return null;