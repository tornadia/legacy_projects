            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "exura";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = (int)((player.Level * 2 + player.MagicLevel * 3) * .08) * -1;
                spell.MinDmg = (int)(((double)(player.Level) * 2 + player.MagicLevel * 3) * .33) * -1;
                spell.RequiredMLevel = 1;
                spell.ManaCost = 25;
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.VocationsFor = new Vocation[]
                {Vocation.DRUID, Vocation.KNIGHT,
                 Vocation.PALADIN, Vocation.SORCERER};
            };
            return null;