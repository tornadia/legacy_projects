            SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "utana vid";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 15;
                spell.ManaCost = 210;
                spell.SpellEffect = MagicEffect.BLUE_SPARKLES;
                spell.VocationsFor = new Vocation[] { Vocation.DRUID, Vocation.PALADIN, Vocation.SORCERER };
                spell.Action = delegate(GameWorld world, Position hitPosition, List<Thing> hitBySpell) {
                    player.Invisible = true;
                    player.InvisibleCheck = new InvisibleCheck();
                    player.InvisibleCheck.CurrentCreature = player;
                    player.InvisibleCheck.World = player.World;
                    world.AddEventInCS(20000, player.InvisibleCheck.PerformCheck);
                    world.AppendUpdateOutfit(player);

                };
            };
            return null;