   SpellInfo spellInfo = (SpellInfo)arg;
            spellInfo.Name = "utani gran hur";
            spellInfo.Type = SpellType.PLAYER_SAY;
            spellInfo.InitDelegate = delegate(Object[] args) {
                string argument = (string)args[0];
                Player player = (Player)args[1];
                Spell spell = (Spell)args[2];

                spell.SpellArea = new bool[,] { { true } };
                spell.SpellCenter = player.CurrentPosition.Clone();
                spell.MaxDmg = 0;
                spell.MinDmg = 0;
                spell.RequiredMLevel = 8;
                spell.ManaCost = 100;
                spell.SpellEffect = MagicEffect.GREEN_SPARKLES;
                spell.VocationsFor = new Vocation[]
                {Vocation.DRUID, Vocation.SORCERER};

                spell.Action = delegate(GameWorld world, Position position, List<Thing> hit) {
                    player.AppendHasted(.7, 60);
                };
            };
            return null;
