            Monster m = new Monster();
            m.Name = "Bug";
            m.CurrentRace = Race.VENOM;
            m.CharType = 45;
            m.Experience = 18;
            m.Speed = 220;
            m.CurrentHP = 29;
            m.MaxHP = 29;
            m.Corpse = 24756;
            m.Attack = 9;
            m.Skill = 23;
            m.Armor = 2;
            m.Defense = 3;
            m.SummonCost = 250;
            m.Loot = new LootInfo[] {
                new LootInfo(1356, 100000, false, 4),
                new LootInfo(1667, 50000, false, 3)
            };
            return m;