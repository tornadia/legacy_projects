Monster m = new Monster();
m.Name = "Orc Shaman";
m.CurrentRace = Race.BLOOD;
m.CharType = 6;
m.Experience = 110;
m.Speed = 180;
m.CurrentHP = 115;
m.MaxHP = 115;
m.Corpse = 14004;
m.Attack = 13;
m.Skill = 20;
m.Armor = 8;
m.Defense = 10;
m.MaxSummons = 4;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_ELECTRIC,ImmunityType.IMMUNE_POISON,
};
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("selfheal", 25, -43, -25, null),
new MonsterSpellInfo("fireatk", 8, 5, 45, null),
new MonsterSpellInfo("energyatk", 13, 20, 30, null),
new MonsterSpellInfo("summon", 25, 0, 0, "snake"),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 20),
new LootInfo(6490, 2222, false, 1),
new LootInfo(348, 2222, false, 1),
new LootInfo(3252, 5000, true, 1),
new LootInfo(3418, 4000, true, 1),
new LootInfo(7501, 1538, true, 1),
};
return m;
