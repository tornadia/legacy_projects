Monster m = new Monster();
m.Name = "Orc Berserker";
m.CurrentRace = Race.BLOOD;
m.CharType = 8;
m.Experience = 0;
m.Speed = 250;
m.CurrentHP = 210;
m.MaxHP = 210;
m.Corpse = 15028;
m.Attack = 75;
m.Skill = 50;
m.Armor = 15;
m.Defense = 12;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 15),
new LootInfo(642, 33333, false, 3),
new LootInfo(1370, 6666, false, 1),
new LootInfo(1884, 10000, true, 1),
new LootInfo(348, 10000, true, 1),
new LootInfo(1857, 5000, true, 1),
new LootInfo(602, 5000, true, 1),
};
return m;
