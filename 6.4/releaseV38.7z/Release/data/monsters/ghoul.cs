Monster m = new Monster();
m.Name = "Ghoul";
m.CurrentRace = Race.BLOOD;
m.CharType = 18;
m.Experience = 85;
m.Speed = 144;
m.CurrentHP = 100;
m.MaxHP = 100;
m.Corpse = 12214;
m.Attack = 32;
m.Skill = 30;
m.Armor = 8;
m.Defense = 17;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_POISON,
};
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("lifedrain", 13, 15, 25, null),
new MonsterSpellInfo("selfheal", 13, -15, -9, null),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 64),
new LootInfo(1356, 100000, false, 30),
new LootInfo(3393, 20000, false, 1),
new LootInfo(6748, 10000, false, 1),
new LootInfo(4188, 6666, false, 1),
new LootInfo(5722, 20000, false, 1),
new LootInfo(860, 6666, true, 1),
new LootInfo(2638, 20000, true, 2),
new LootInfo(7002, 10000, true, 1),
};
return m;
