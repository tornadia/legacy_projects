            Monster m = new Monster();
            m.Name = "Bear";
            m.CurrentRace = Race.BLOOD;
            m.CharType = 16;
            m.Experience = 23;
            m.Speed = 176;
            m.CurrentHP = 80;
            m.MaxHP = 80;
            m.Corpse = 11188;
            m.Attack = 17;
            m.Skill = 15;
            m.Armor = 6;
            m.Defense = 6;
            m.SummonCost = 300;
            m.Talk = new string[] {"grrr"};
            m.Loot = new LootInfo[] {
                new LootInfo(3458, 90000, false, 4),
            };
            return m;