	      Monster m = new Monster();
            m.Name = "Skeleton";
            m.CurrentRace = Race.UNDEAD;
            m.CharType = 33;
            m.Experience = 35;
            m.Speed = 154;
            m.CurrentHP = 50;
            m.MaxHP = 50;
            m.Corpse = 9652;
            m.Attack = 14;
            m.Skill = 18;
            m.Armor = 2;
            m.Defense = 9;
            m.SummonCost = 300;
            m.Immunities = new ImmunityType[] { ImmunityType.IMMUNE_POISON};
            m.Loot = new LootInfo[] {
                new LootInfo(1356, 90000, false, 10),
                new LootInfo(5980, 6666, false, 1),

                new LootInfo(3162, 10000, true, 1),
                new LootInfo(5722, 10000, true, 1),
                new LootInfo(605, 5000, true, 1),
                new LootInfo(4188, 5000, true, 1),
                new LootInfo(90, 3333, true, 1),
                new LootInfo(3393, 20000, true, 1)
            };
            m.LootContainer = 317;
	    return m;