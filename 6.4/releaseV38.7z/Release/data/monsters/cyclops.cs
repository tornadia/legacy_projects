Monster m = new Monster();
m.Name = "Cyclops";
m.CurrentRace = Race.BLOOD;
m.CharType = 22;
m.Experience = 150;
m.Speed = 200;
m.CurrentHP = 260;
m.MaxHP = 260;
m.Corpse = 694;
m.Attack = 35;
m.Skill = 35;
m.Armor = 15;
m.Defense = 15;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 40),
new LootInfo(8540, 4000, false, 1),
new LootInfo(2123, 6666, false, 1),
new LootInfo(642, 33333, false, 3),
new LootInfo(7770, 33333, true, 1),
new LootInfo(1117, 3000, true, 1),
new LootInfo(605, 6666, true, 1),
new LootInfo(1370, 4000, true, 1),
new LootInfo(3458, 33333, true, 3),
};
return m;
