Monster m = new Monster();
m.Name = "Monk";
m.CurrentRace = Race.BLOOD;
m.CharType = 57;
m.Experience = 200;
m.Speed = 220;
m.CurrentHP = 240;
m.MaxHP = 240;
m.Corpse = 437;
m.Attack = 0;
m.Skill = 0;
m.Armor = 20;
m.Defense = 22;
m.MaxSummons = 0;
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("selfheal", 17, -50, -30, null),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 20),
new LootInfo(316, 10000, false, 1),
new LootInfo(2652, 10000, false, 1),
new LootInfo(632, 6666, false, 1),
new LootInfo(1857, 6666, true, 1),
new LootInfo(134, 20000, true, 3),
new LootInfo(6490, 3333, true, 1),
};
return m;
