            Monster m = new Monster();
            m.Name = "Rat";
            m.CharType = 21;
            m.Experience = 5;
            m.Speed = 134;
            m.CurrentHP = 20;
            m.MaxHP = 20;
            m.Corpse = 1974;
	    m.MaxSummons = 2;
            m.Attack = 7;
            m.Skill = 15;
            m.Armor = 1;
            m.Defense = 2;
	    m.SummonCost = 200;
            m.Loot = new LootInfo[] {
                new LootInfo(1356, 80000, false, 7),
		new LootInfo(136, 20000, false, 1),
            };
            return m;