Monster m = new Monster();
m.Name = "Black Sheep";
m.CurrentRace = Race.BLOOD;
m.CharType = 13;
m.Experience = 15;
m.Speed = 200;
m.CurrentHP = 20;
m.MaxHP = 20;
m.Corpse = 28340;
m.Attack = 0;
m.Skill = 0;
m.Armor = 1;
m.Defense = 2;
m.MaxSummons = 0;
m.Loot = new LootInfo[] {
new LootInfo(642, 100000, false, 5),
};
return m;
