Monster m = new Monster();
m.Name = "Beholder";
m.CurrentRace = Race.BLOOD;
m.CharType = 17;
m.Experience = 170;
m.Speed = 150;
m.CurrentHP = 260;
m.MaxHP = 260;
m.Corpse = 26292;
m.Attack = 12;
m.Skill = 35;
m.Armor = 15;
m.Defense = 10;
m.MaxSummons = 6;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_POISON,
};
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("lifedrain", 6, 35, 45, null),
new MonsterSpellInfo("poisonatk", 7, 5, 45, null),
new MonsterSpellInfo("fireatk", 7, 25, 45, null),
new MonsterSpellInfo("suddendeath", 7, 30, 50, null),
new MonsterSpellInfo("summon", 12, 0, 0, "skeleton"),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 52),
new LootInfo(3661, 4000, false, 1),
new LootInfo(93, 3333, false, 1),
new LootInfo(861, 3000, true, 1),
new LootInfo(4698, 5000, true, 1),
new LootInfo(1356, 100000, true, 12),
new LootInfo(2397, 1000, true, 1),
new LootInfo(5466, 6666, true, 1),
};
return m;
