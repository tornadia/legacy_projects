Monster m = new Monster();
m.Name = "Demon";
m.CurrentRace = Race.BLOOD;
m.CharType = 35;
m.Experience = 6000;
m.Speed = 310;
m.CurrentHP = 8200;
m.MaxHP = 8200;
m.Corpse = 28852;
m.Attack = 100;
m.Skill = 105;
m.Armor = 50;
m.Defense = 50;
m.MaxSummons = 1;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_FIRE,
};
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("energybeam", 10, 300, 420, null),
new MonsterSpellInfo("greatfireball", 34, 110, 200, null),
new MonsterSpellInfo("selfheal", 15, -150, -90, null),
new MonsterSpellInfo("firefield", 15, 0, 0, null),
new MonsterSpellInfo("summon", 7, 0, 0, "fire elemental"),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 100),
new LootInfo(1356, 100000, false, 25),
new LootInfo(4442, 2300, false, 1),
new LootInfo(1373, 1200, false, 1),
new LootInfo(14426, 2100, false, 1),
new LootInfo(3932, 1200, false, 1),
new LootInfo(3917, 3000, false, 1),
new LootInfo(5210, 600, true, 1),
new LootInfo(4685, 1100, true, 1),
new LootInfo(2212, 20000, true, 6),
new LootInfo(1411, 10000, true, 3),
new LootInfo(1356, 100000, true, 100),
new LootInfo(2124, 4000, true, 4),
new LootInfo(1372, 1200, true, 1),
new LootInfo(1612, 11000, true, 3),
new LootInfo(2637, 800, true, 1),
new LootInfo(2906, 20000, true, 1),
new LootInfo(3420, 1400, true, 1),
new LootInfo(2909, 2400, true, 1),
new LootInfo(10842, 1500, true, 1),
};
m.Talk = new string[] {
"MUHAHAHAHA!", "I SMELL FEEEEEAAAR!", "CHAMEK ATH UTHUL ARAK!", "Your resistance is futile!", "Your soul will be mine!", };
return m;
