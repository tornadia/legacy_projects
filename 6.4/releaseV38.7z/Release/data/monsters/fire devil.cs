Monster m = new Monster();
m.Name = "Fire Devil";
m.CurrentRace = Race.BLOOD;
m.CharType = 40;
m.Experience = 110;
m.Speed = 190;
m.CurrentHP = 200;
m.MaxHP = 200;
m.Corpse = 20660;
m.Attack = 0;
m.Skill = 0;
m.Armor = 13;
m.Defense = 15;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_FIRE,
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 20),
new LootInfo(642, 33333, false, 3),
new LootInfo(3393, 20000, false, 1),
new LootInfo(11098, 10000, false, 1),
new LootInfo(2906, 5000, false, 1),
new LootInfo(1629, 2857, true, 1),
new LootInfo(79, 6666, true, 1),
new LootInfo(1868, 1666, true, 2),
new LootInfo(7757, 833, true, 1),
};
return m;
