Monster m = new Monster();
m.Name = "Orc Warrior";
m.CurrentRace = Race.BLOOD;
m.CharType = 7;
m.Experience = 50;
m.Speed = 190;
m.CurrentHP = 125;
m.MaxHP = 125;
m.Corpse = 4020;
m.Attack = 0;
m.Skill = 0;
m.Armor = 8;
m.Defense = 14;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 12),
new LootInfo(642, 40000, false, 2),
new LootInfo(861, 10000, false, 1),
new LootInfo(5469, 4000, false, 1),
new LootInfo(2394, 6666, true, 1),
new LootInfo(1884, 5000, true, 1),
new LootInfo(11354, 5000, true, 1),
new LootInfo(574, 20000, true, 1),
};
return m;
