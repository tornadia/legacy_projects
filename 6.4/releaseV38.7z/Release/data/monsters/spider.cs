            Monster m = new Monster();
            m.Name = "Spider";
            m.CharType = 30;
            m.Experience = 12;
            m.Speed = 152;
            m.CurrentHP = 20;
            m.MaxHP = 20;
            m.Corpse = 436;
            m.Attack = 7;
            m.Skill = 9;
            m.Armor = 2;
            m.Defense = 2;
            m.Loot = new LootInfo[] {
                new LootInfo(1356, 90000, false, 5),
            };
            return m;