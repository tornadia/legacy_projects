Monster m = new Monster();
m.Name = "Pig";
m.CurrentRace = Race.BLOOD;
m.CharType = 60;
m.Experience = 0;
m.Speed = 114;
m.CurrentHP = 150;
m.MaxHP = 150;
m.Corpse = 33716;
m.Attack = 0;
m.Skill = 10;
m.Armor = 2;
m.Defense = 2;
m.MaxSummons = 0;
m.Loot = new LootInfo[] {
new LootInfo(3458, 100000, false, 4),
};
return m;
