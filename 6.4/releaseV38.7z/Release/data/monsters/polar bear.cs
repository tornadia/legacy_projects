Monster m = new Monster();
m.Name = "Polar Bear";
m.CurrentRace = Race.BLOOD;
m.CharType = 42;
m.Experience = 28;
m.Speed = 156;
m.CurrentHP = 85;
m.MaxHP = 85;
m.Corpse = 22452;
m.Attack = 18;
m.Skill = 19;
m.Armor = 7;
m.Defense = 10;
m.MaxSummons = 0;
m.Loot = new LootInfo[] {
new LootInfo(3458, 90000, false, 4),
new LootInfo(642, 80000, false, 3),
};
return m;
