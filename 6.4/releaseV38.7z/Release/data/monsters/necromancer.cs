Monster m = new Monster();
m.Name = "Necromancer";
m.CurrentRace = Race.BLOOD;
m.CharType = 9;
m.Experience = 580;
m.Speed = 200;
m.CurrentHP = 580;
m.MaxHP = 580;
m.Corpse = 437;
m.Attack = 40;
m.Skill = 30;
m.Armor = 20;
m.Defense = 20;
m.MaxSummons = 4;
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("poisonatk", 17, 35, 125, null),
new MonsterSpellInfo("selfheal", 25, -68, -42, null),
new MonsterSpellInfo("suddendeath", 10, 10, 120, null),
new MonsterSpellInfo("summon", 17, 0, 0, "ghoul"),
new MonsterSpellInfo("summon", 15, 0, 0, "ghost"),
new MonsterSpellInfo("summon", 13, 0, 0, "mummy"),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(6477, 110, false, 1),
new LootInfo(1356, 100000, false, 40),
new LootInfo(1957, 20000, false, 2),
new LootInfo(5453, 1333, false, 1),
new LootInfo(7770, 15000, false, 1),
new LootInfo(9306, 10000, true, 1),
new LootInfo(6748, 10000, true, 1),
new LootInfo(2468, 1500, true, 1),
new LootInfo(2638, 20000, true, 3),
new LootInfo(1954, 20000, true, 1),
new LootInfo(12122, 5000, true, 1),
};
return m;
