Monster m = new Monster();
m.Name = "Orc Spearman";
m.CurrentRace = Race.BLOOD;
m.CharType = 50;
m.Experience = 38;
m.Speed = 176;
m.CurrentHP = 105;
m.MaxHP = 105;
m.Corpse = 29876;
m.Attack = 17;
m.Skill = 19;
m.Armor = 6;
m.Defense = 12;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 80000, false, 10),
new LootInfo(642, 80000, false, 2),
new LootInfo(2908, 10000, false, 1),
new LootInfo(334, 10000, false, 1),
new LootInfo(11354, 10000, true, 1),
new LootInfo(3418, 6666, true, 1),
};
return m;
