Monster m = new Monster();
m.Name = "Vampire";
m.CurrentRace = Race.UNDEAD;
m.CharType = 68;
m.Experience = 305;
m.Speed = 255;
m.CurrentHP = 475;
m.MaxHP = 475;
m.Corpse = 39092;
m.Attack = 68;
m.Skill = 62;
m.Armor = 17;
m.Defense = 23;
m.MaxSummons = 0;
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("lifedrain", 19, 25, 125, null),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 9),
new LootInfo(2893, 200, false, 1),
new LootInfo(1611, 200, false, 1),
new LootInfo(1356, 2500, true, 4),
new LootInfo(2638, 10000, true, 3),
new LootInfo(9306, 15000, true, 1),
new LootInfo(1954, 18000, true, 1),
new LootInfo(6493, 500, true, 1),
new LootInfo(5210, 600, true, 1),
new LootInfo(332, 1538, true, 3),
new LootInfo(5724, 1428, true, 1),
};
return m;
