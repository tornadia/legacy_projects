            Monster m = new Monster();
            m.Name = "Poison Spider";
            m.CurrentRace = Race.VENOM;
            m.CharType = 36;
            m.Experience = 22;
            m.Speed = 160;
            m.CurrentHP = 26;
            m.MaxHP = 26;
            m.Corpse = 10932;
            m.Attack = 12;
            m.Skill = 25;
            m.Armor = 2;
            m.Defense = 6;
            m.SummonCost = 270;
            m.Loot = new LootInfo[] {
                new LootInfo(1356, 100000, false, 10)
            };
            return m;