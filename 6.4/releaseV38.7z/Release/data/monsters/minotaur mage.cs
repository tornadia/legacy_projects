Monster m = new Monster();
m.Name = "Minotaur Mage";
m.CurrentRace = Race.BLOOD;
m.CharType = 23;
m.Experience = 150;
m.Speed = 170;
m.CurrentHP = 155;
m.MaxHP = 155;
m.Corpse = 15540;
m.Attack = 15;
m.Skill = 18;
m.Armor = 18;
m.Defense = 20;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_ELECTRIC,
};
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("energyfield", 9, 0, 0, null),
new MonsterSpellInfo("fireatk", 7, 35, 95, null),
new MonsterSpellInfo("energyatk", 14, 15, 45, null),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 20),
new LootInfo(3393, 10000, false, 1),
new LootInfo(1116, 8000, false, 1),
new LootInfo(7245, 1333, true, 1),
new LootInfo(7258, 10000, true, 1),
new LootInfo(3252, 10000, true, 1),
new LootInfo(591, 2857, true, 1),
new LootInfo(2140, 4000, true, 1),
new LootInfo(377, 4000, true, 1),
};
return m;
