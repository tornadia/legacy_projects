Monster m = new Monster();
m.Name = "Elf Scout";
m.CurrentRace = Race.BLOOD;
m.CharType = 64;
m.Experience = 75;
m.Speed = 225;
m.CurrentHP = 160;
m.MaxHP = 160;
m.Corpse = 36276;
m.Attack = 18;
m.Skill = 25;
m.Armor = 7;
m.Defense = 18;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 10),
new LootInfo(350, 50000, false, 10),
new LootInfo(7004, 10000, false, 1),
new LootInfo(603, 10000, false, 1),
new LootInfo(1356, 80000, true, 5),
new LootInfo(632, 5500, true, 1),
new LootInfo(5466, 4000, true, 1),
new LootInfo(930, 5000, true, 1),
};
m.Talk = new string[] {
"Tha'shi Ab'Dendriel!", "Feel the sting of my arrows!", "Thy blood will quench the soil's thirst!", "Evicor guide my arrow.", "Your existence will end here!", };
return m;
