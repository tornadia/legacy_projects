Monster m = new Monster();
m.Name = "Wasp";
m.CurrentRace = Race.VENOM;
m.CharType = 44;
m.Experience = 25;
m.Speed = 460;
m.CurrentHP = 35;
m.MaxHP = 35;
m.Corpse = 23988;
m.Attack = 12;
m.Skill = 18;
m.Armor = 4;
m.Defense = 8;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_POISON,
};
return m;
