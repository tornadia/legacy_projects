Monster m = new Monster();
m.Name = "Hero";
m.CurrentRace = Race.BLOOD;
m.CharType = 73;
m.Experience = 1200;
m.Speed = 268;
m.CurrentHP = 1400;
m.MaxHP = 1400;
m.Corpse = 437;
m.Attack = 75;
m.Skill = 80;
m.Armor = 30;
m.Defense = 20;
m.MaxSummons = 0;
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("selfheal", 10, -350, -200, null),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(8796, 1200, false, 1),
new LootInfo(1356, 100000, false, 100),
new LootInfo(74, 20000, false, 1),
new LootInfo(316, 10000, false, 1),
new LootInfo(603, 10000, false, 1),
new LootInfo(123, 12000, false, 1),
new LootInfo(587, 6666, false, 1),
new LootInfo(642, 20000, false, 3),
new LootInfo(7772, 600, true, 1),
new LootInfo(4186, 700, true, 1),
new LootInfo(2653, 900, true, 1),
new LootInfo(8028, 800, true, 1),
new LootInfo(834, 10000, true, 1),
new LootInfo(350, 20000, true, 13),
new LootInfo(634, 10000, true, 1),
new LootInfo(3930, 1333, true, 1),
new LootInfo(1186, 20000, true, 1),
};
return m;
