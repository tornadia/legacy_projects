Monster m = new Monster();
m.Name = "Priestess";
m.CurrentRace = Race.BLOOD;
m.CharType = 58;
m.Experience = 420;
m.Speed = 220;
m.CurrentHP = 390;
m.MaxHP = 390;
m.Corpse = 437;
m.Attack = 20;
m.Skill = 25;
m.Armor = 10;
m.Defense = 19;
m.MaxSummons = 2;
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("selfheal", 13, -56, -34, null),
new MonsterSpellInfo("suddendeath", 22, 55, 125, null),
new MonsterSpellInfo("summon", 8, 0, 0, "ghoul"),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 10),
new LootInfo(572, 7000, false, 1),
new LootInfo(322, 3333, false, 1),
new LootInfo(5213, 1818, false, 1),
new LootInfo(12122, 1500, true, 1),
new LootInfo(858, 23000, true, 1),
new LootInfo(1099, 600, true, 1),
new LootInfo(1445, 14000, true, 1),
new LootInfo(1701, 6000, true, 1),
new LootInfo(11354, 10000, true, 1),
new LootInfo(76, 5000, true, 2),
new LootInfo(5282, 5000, true, 1),
new LootInfo(8013, 2500, true, 1),
new LootInfo(3403, 3333, true, 1),
new LootInfo(2124, 4000, true, 2),
new LootInfo(588, 1666, true, 2),
};
return m;
