            Monster m = new Monster();
            m.Name = "Minotaur";
            m.CurrentRace = Race.BLOOD;
            m.CharType = 25;
            m.Experience = 50;
            m.Speed = 170;
            m.CurrentHP = 100;
            m.MaxHP = 100;
            m.Corpse = 6324;
            m.Attack = 15;
            m.Skill = 25;
            m.Armor = 11;
            m.Defense = 11;
            m.SummonCost = 330;
            m.Talk = new string[] { "kaplar" };

            m.Loot = new LootInfo[] {
                new LootInfo(1356, 100000, false, 28),
                new LootInfo(1884, 10000, false, 1),
                new LootInfo(2650, 10000, false, 1),
                new LootInfo(869, 10000, false, 1),

                new LootInfo(348, 10000, true, 3),
                new LootInfo(1356, 20000, true, 5),
                new LootInfo(860, 10000, true, 3),
                new LootInfo(349, 10000, true, 3),
                new LootInfo(5722, 10000, true, 3),
                new LootInfo(2893, 2500, true, 3),
            };
	    m.LootContainer = 317;
            return m;