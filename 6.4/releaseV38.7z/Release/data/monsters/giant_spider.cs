Monster m = new Monster();
m.Name = "Giant Spider";
m.CurrentRace = Race.VENOM;
m.CharType = 38;
m.Experience = 900;
m.Speed = 280;
m.CurrentHP = 1300;
m.MaxHP = 1300;
m.Corpse = 13236;
m.Attack = 75;
m.Skill = 80;
m.Armor = 30;
m.Defense = 30;
m.MaxSummons = 2;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_FIRE,ImmunityType.IMMUNE_POISON,
};
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("poisonfield", 30, 0, 0, null),
new MonsterSpellInfo("summon", 40, 0, 0, "poison spider"),
};
m.LootContainer = 1410;
m.Loot = new LootInfo[] {
new LootInfo(1628, 4000, false, 1),
new LootInfo(2637, 400, false, 1),
new LootInfo(604, 20000, false, 1),
new LootInfo(1356, 100000, false, 50),
new LootInfo(1356, 100000, true, 40),
new LootInfo(92, 5000, true, 1),
new LootInfo(4956, 700, true, 1),
new LootInfo(5212, 500, true, 1),
new LootInfo(5468, 10000, true, 1),
};
return m;
