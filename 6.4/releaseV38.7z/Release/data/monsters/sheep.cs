Monster m = new Monster();
m.Name = "Sheep";
m.CurrentRace = Race.BLOOD;
m.CharType = 14;
m.Experience = 0;
m.Speed = 110;
m.CurrentHP = 20;
m.MaxHP = 20;
m.Corpse = 25524;
m.Attack = 0;
m.Skill = 0;
m.Armor = 1;
m.Defense = 2;
m.MaxSummons = 0;
m.Loot = new LootInfo[] {
new LootInfo(642, 80000, false, 3),
new LootInfo(3458, 70000, false, 2),
};
return m;
