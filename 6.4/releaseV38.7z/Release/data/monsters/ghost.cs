Monster m = new Monster();
m.Name = "Ghost";
m.CurrentRace = Race.UNDEAD;
m.CharType = 48;
m.Experience = 120;
m.Speed = 160;
m.CurrentHP = 150;
m.MaxHP = 150;
m.Corpse = 10934;
m.Attack = 35;
m.Skill = 40;
m.Armor = 10;
m.Defense = 10;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_PHYSICAL,
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 15),
new LootInfo(632, 10000, false, 1),
new LootInfo(7258, 10000, false, 1),
new LootInfo(4698, 6666, true, 1),
new LootInfo(1957, 20000, true, 2),
new LootInfo(5981, 1666, true, 1),
new LootInfo(5453, 1333, true, 1),
new LootInfo(12122, 10000, true, 1),
new LootInfo(572, 5000, true, 1),
};
return m;
