Monster m = new Monster();
m.Name = "Dwarf";
m.CurrentRace = Race.BLOOD;
m.CharType = 69;
m.Experience = 45;
m.Speed = 170;
m.CurrentHP = 90;
m.MaxHP = 90;
m.Corpse = 40116;
m.Attack = 14;
m.Skill = 23;
m.Armor = 8;
m.Defense = 10;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 15),
new LootInfo(3162, 6666, false, 1),
new LootInfo(2650, 5000, false, 1),
new LootInfo(7004, 20000, false, 1),
new LootInfo(5469, 6666, false, 1),
new LootInfo(164, 20000, true, 2),
};
return m;
