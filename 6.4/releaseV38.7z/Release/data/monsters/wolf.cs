            Monster m = new Monster();
            m.Name = "Wolf";
            m.CurrentRace = Race.BLOOD;
            m.CharType = 27;
            m.Experience = 18;
            m.Speed = 195;
            m.CurrentHP = 25;
            m.MaxHP = 25;
            m.Corpse = 5300;
            m.Attack = 22;
            m.Skill = 19;
            m.Armor = 1;
            m.Defense = 4;
            m.SummonCost = 255;
            m.Loot = new LootInfo[] {
                new LootInfo(642, 90000, false, 3),
            };
            return m;