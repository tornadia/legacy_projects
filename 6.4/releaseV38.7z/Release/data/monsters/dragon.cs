Monster m = new Monster();
            m.Name = "Dragon";
            m.CurrentRace = Race.BLOOD;
            m.CharType = 34;
            m.Experience = 700;
            m.Speed = 180;
            m.CurrentHP = 1000;
            m.MaxHP = 1000;
            m.Corpse = 9908;
            m.Attack = 50;
            m.Skill = 50;
            m.Armor = 25;
            m.Defense = 25;
            m.SummonCost = 800;
            m.Immunities = new ImmunityType[] { ImmunityType.IMMUNE_FIRE};
            m.Spells = new MonsterSpellInfo[] {
                new MonsterSpellInfo("fireball", 15, 65, 115, null),
                new MonsterSpellInfo("selfheal", 13, -56, -34, null),
                new MonsterSpellInfo("firewave", 10, 110, 170, null)
            };
            m.Loot = new LootInfo[] {
                new LootInfo(1356, 100000, false, 100),
                new LootInfo(91, 6666, false, 1),
                new LootInfo(93, 1818, false, 10),
                new LootInfo(7770, 20000, false, 1),
                new LootInfo(121, 2222, false, 10),
                new LootInfo(92, 3333, false, 1),
                new LootInfo(2906, 4000, false, 1),
                new LootInfo(5466, 5000, false, 1),
                new LootInfo(862, 4000, false, 10),

                new LootInfo(5722, 90000, true, 1),
                new LootInfo(1885, 1300, true, 1),
                new LootInfo(4173, 1538, true, 1),
                new LootInfo(4188, 2000, true, 1),
                new LootInfo(8538, 1800, true, 1),
            };
            m.LootContainer = 317;
            
            return m;