Monster m = new Monster();
m.Name = "Fire Elemental";
m.CurrentRace = Race.FIRE;
m.CharType = 49;
m.Experience = 280;
m.Speed = 220;
m.CurrentHP = 280;
m.MaxHP = 280;
m.Corpse = 37;
m.Attack = 38;
m.Skill = 38;
m.Armor = 0;
m.Defense = 0;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_FIRE,
};
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("firefield", 14, 0, 0, null),
new MonsterSpellInfo("explosion", 16, 55, 155, null),
};
return m;
