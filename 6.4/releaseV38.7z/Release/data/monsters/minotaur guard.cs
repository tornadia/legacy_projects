Monster m = new Monster();
m.Name = "Minotaur Guard";
m.CurrentRace = Race.BLOOD;
m.CharType = 29;
m.Experience = 160;
m.Speed = 190;
m.CurrentHP = 185;
m.MaxHP = 185;
m.Corpse = 18100;
m.Attack = 35;
m.Skill = 50;
m.Armor = 15;
m.Defense = 25;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 20),
new LootInfo(642, 70000, false, 3),
new LootInfo(2906, 5000, false, 1),
new LootInfo(2650, 6666, true, 1),
new LootInfo(109, 5000, true, 1),
new LootInfo(377, 5000, true, 1),
new LootInfo(348, 10000, true, 1),
new LootInfo(2140, 2500, true, 1),
new LootInfo(1117, 10000, true, 1),
};
return m;
