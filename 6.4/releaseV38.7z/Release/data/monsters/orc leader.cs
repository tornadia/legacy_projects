Monster m = new Monster();
m.Name = "Orc Leader";
m.CurrentRace = Race.BLOOD;
m.CharType = 59;
m.Experience = 270;
m.Speed = 230;
m.CurrentHP = 450;
m.MaxHP = 450;
m.Corpse = 34484;
m.Attack = 48;
m.Skill = 52;
m.Armor = 20;
m.Defense = 30;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_FIRE,
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 30),
new LootInfo(8794, 50000, false, 2),
new LootInfo(11098, 10000, false, 1),
new LootInfo(349, 5000, false, 1),
new LootInfo(1922, 20000, false, 1),
new LootInfo(121, 1818, false, 1),
new LootInfo(573, 20000, true, 1),
new LootInfo(1356, 2857, true, 1),
new LootInfo(642, 33333, true, 2),
new LootInfo(858, 6666, true, 1),
new LootInfo(4700, 1000, true, 1),
new LootInfo(5466, 10000, true, 1),
new LootInfo(634, 2500, true, 1),
new LootInfo(5468, 2857, true, 1),
new LootInfo(1628, 1818, true, 1),
};
return m;
