Monster m = new Monster();
m.Name = "Goblin";
m.CurrentRace = Race.BLOOD;
m.CharType = 61;
m.Experience = 25;
m.Speed = 200;
m.CurrentHP = 50;
m.MaxHP = 50;
m.Corpse = 34996;
m.Attack = 10;
m.Skill = 15;
m.Armor = 6;
m.Defense = 8;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 10),
new LootInfo(11354, 10000, false, 1),
new LootInfo(1116, 10000, false, 1),
new LootInfo(7770, 10000, false, 1),
new LootInfo(2652, 10000, false, 1),
new LootInfo(1127, 10000, true, 1),
new LootInfo(2332, 20000, true, 4),
new LootInfo(1922, 20000, true, 2),
new LootInfo(2894, 10000, true, 1),
new LootInfo(4174, 10000, true, 1),
};
return m;
