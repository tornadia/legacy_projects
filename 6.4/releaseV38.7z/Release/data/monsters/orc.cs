            Monster m = new Monster();
            m.Name = "Orc";
            m.CharType = 5;
            m.Experience = 25;
            m.Speed = 150;
            m.CurrentHP = 70;
            m.MaxHP = 70;
            m.Corpse = 3764;
            m.Attack = 13;
            m.Skill = 22;
            m.Armor = 4;
            m.Defense = 8;
            m.Talk = new String[] {
                "Grak brrretz!",
                "Grow truk grrrrr.",
                "Prek tars, dekklep zurk."};
            m.Loot = new LootInfo[] {
                new LootInfo(1359, 100000, false, 12),
		new LootInfo(642, 33333, false, 2),
                new LootInfo(7004, 10000, false, 1),
                new LootInfo(5980, 10000, false, 1),
                new LootInfo(2394, 10000, false, 1),
                new LootInfo(4445, 10000, true, 1),
                new LootInfo(2650, 10000, true, 1),
            };
            m.LootContainer = 317;
            return m;