Monster m = new Monster();
m.Name = "Elf";
m.CurrentRace = Race.BLOOD;
m.CharType = 62;
m.Experience = 42;
m.Speed = 220;
m.CurrentHP = 100;
m.MaxHP = 100;
m.Corpse = 36276;
m.Attack = 12;
m.Skill = 20;
m.Armor = 6;
m.Defense = 12;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 15),
new LootInfo(350, 800000, false, 6),
new LootInfo(5980, 10000, false, 1),
new LootInfo(7004, 20000, false, 1),
new LootInfo(5468, 4000, false, 1),
new LootInfo(888, 25000, false, 1),
new LootInfo(62, 6666, false, 1),
new LootInfo(5466, 5000, true, 1),
new LootInfo(632, 9000, true, 1),
new LootInfo(603, 6666, true, 1),
new LootInfo(930, 5000, true, 1),
};
return m;
