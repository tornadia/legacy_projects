            Monster m = new Monster();
            m.Name = "Test";
            m.CurrentRace = Race.BLOOD;
            m.CharType = 45;
            m.Experience = 0;
            m.Speed = 500;
            m.CurrentHP = 65000;
            m.MaxHP = 65000;
            m.Corpse = 24756;
            m.Attack = 0;
            m.Skill = 0;
            m.Armor = 300;
            m.Defense = 300;
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("electricfield", 30, 0, 0, null),
};

            return m;