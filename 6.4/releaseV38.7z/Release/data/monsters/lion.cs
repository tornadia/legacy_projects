Monster m = new Monster();
m.Name = "Lion";
m.CurrentRace = Race.BLOOD;
m.CharType = 41;
m.Experience = 30;
m.Speed = 180;
m.CurrentHP = 80;
m.MaxHP = 80;
m.Corpse = 21428;
m.Attack = 20;
m.Skill = 32;
m.Armor = 6;
m.Defense = 13;
m.MaxSummons = 0;
m.Loot = new LootInfo[] {
new LootInfo(3458, 80000, false, 3),
};
return m;
