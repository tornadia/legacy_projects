Monster m = new Monster();
m.Name = "Dragon Lord";
m.CurrentRace = Race.BLOOD;
m.CharType = 39;
m.Experience = 2100;
m.Speed = 240;
m.CurrentHP = 1900;
m.MaxHP = 1900;
m.Corpse = 19380;
m.Attack = 65;
m.Skill = 80;
m.Armor = 22;
m.Defense = 35;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_FIRE,ImmunityType.IMMUNE_POISON,
};
m.Spells = new MonsterSpellInfo[] {
new MonsterSpellInfo("firebomb", 15, 0, 0, null),
new MonsterSpellInfo("selfheal", 25, -93, -57, null),
new MonsterSpellInfo("fireball", 17, 60, 180, null),
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 100),
new LootInfo(9052, 333, false, 1),
new LootInfo(862, 2500, false, 5),
new LootInfo(1118, 2222, false, 10),
new LootInfo(2468, 6666, false, 1),
new LootInfo(1356, 100000, true, 100),
new LootInfo(1612, 833, true, 2),
new LootInfo(4186, 1428, true, 1),
new LootInfo(844, 2222, true, 2),
new LootInfo(4957, 1333, true, 1),
new LootInfo(9818, 909, true, 1),
};
return m;
