Monster m = new Monster();
m.Name = "Rotworm";
m.CurrentRace = Race.BLOOD;
m.CharType = 26;
m.Experience = 40;
m.Speed = 180;
m.CurrentHP = 65;
m.MaxHP = 65;
m.Corpse = 4788;
m.Attack = 12;
m.Skill = 12;
m.Armor = 8;
m.Defense = 11;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 27),
new LootInfo(5980, 1500, false, 1),
new LootInfo(5469, 2857, false, 1),
new LootInfo(642, 20000, true, 1),
new LootInfo(5722, 3333, true, 1),
new LootInfo(3458, 20000, true, 2),
new LootInfo(90, 10000, true, 1),
new LootInfo(9306, 1000, true, 1),
};
return m;
