Monster m = new Monster();
m.Name = "Deer";
m.CurrentRace = Race.BLOOD;
m.CharType = 31;
m.Experience = 0;
m.Speed = 150;
m.CurrentHP = 25;
m.MaxHP = 25;
m.Corpse = 7604;
m.Attack = 2;
m.Skill = 10;
m.Armor = 2;
m.Defense = 2;
m.MaxSummons = 0;
m.Loot = new LootInfo[] {
new LootInfo(642, 100000, false, 4),
};
return m;
