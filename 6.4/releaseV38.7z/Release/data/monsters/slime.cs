Monster m = new Monster();
m.Name = "Slime";
m.CurrentRace = Race.VENOM;
m.CharType = 19;
m.Experience = 160;
m.Speed = 120;
m.CurrentHP = 150;
m.MaxHP = 150;
m.Corpse = 805;
m.Attack = 42;
m.Skill = 22;
m.Armor = 3;
m.Defense = 10;
m.MaxSummons = 3;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_POISON,
};
return m;
