Monster m = new Monster();
m.Name = "Stone Golem";
m.CurrentRace = Race.BLOOD;
m.CharType = 67;
m.Experience = 280;
m.Speed = 180;
m.CurrentHP = 270;
m.MaxHP = 270;
m.Corpse = 38068;
m.Attack = 38;
m.Skill = 52;
m.Armor = 10;
m.Defense = 18;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_FIRE,ImmunityType.IMMUNE_POISON,
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 20),
new LootInfo(6748, 10000, false, 1),
new LootInfo(28, 10000, true, 1),
new LootInfo(2332, 20000, true, 5),
new LootInfo(4954, 2500, true, 1),
new LootInfo(3393, 20000, true, 1),
new LootInfo(109, 5000, true, 1),
};
return m;
