Monster m = new Monster();
m.Name = "Minotaur Archer";
m.CurrentRace = Race.BLOOD;
m.CharType = 24;
m.Experience = 65;
m.Speed = 170;
m.CurrentHP = 100;
m.MaxHP = 100;
m.Corpse = 16820;
m.Attack = 15;
m.Skill = 20;
m.Armor = 7;
m.Defense = 8;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 28),
new LootInfo(94, 70000, false, 18),
new LootInfo(642, 50000, false, 3),
new LootInfo(6748, 10000, false, 1),
new LootInfo(6236, 6666, false, 1),
new LootInfo(91, 6666, true, 1),
new LootInfo(2140, 5000, true, 1),
new LootInfo(1884, 10000, true, 1),
new LootInfo(377, 4000, true, 1),
new LootInfo(348, 10000, true, 1),
};
return m;
