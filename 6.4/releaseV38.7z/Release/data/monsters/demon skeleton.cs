Monster m = new Monster();
m.Name = "Demon Skeleton";
m.CurrentRace = Race.UNDEAD;
m.CharType = 37;
m.Experience = 240;
m.Speed = 230;
m.CurrentHP = 400;
m.MaxHP = 400;
m.Corpse = 948;
m.Attack = 0;
m.Skill = 0;
m.Armor = 25;
m.Defense = 25;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 40),
new LootInfo(5978, 10000, false, 1),
new LootInfo(1629, 400, false, 1),
new LootInfo(4429, 1000, false, 1),
new LootInfo(3393, 10000, false, 1),
new LootInfo(10586, 5000, true, 1),
new LootInfo(6492, 2857, true, 1),
new LootInfo(8525, 700, true, 1),
new LootInfo(5722, 10000, true, 1),
};
return m;
