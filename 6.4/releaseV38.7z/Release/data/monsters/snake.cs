Monster m = new Monster();
m.Name = "Snake";
m.CurrentRace = Race.BLOOD;
m.CharType = 28;
m.Experience = 10;
m.Speed = 120;
m.CurrentHP = 15;
m.MaxHP = 15;
m.Corpse = 2996;
m.Attack = 5;
m.Skill = 11;
m.Armor = 0;
m.Defense = 1;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_POISON,
};
return m;
