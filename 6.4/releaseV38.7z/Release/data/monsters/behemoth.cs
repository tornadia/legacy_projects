Monster m = new Monster();
m.Name = "Behemoth";
m.CurrentRace = Race.BLOOD;
m.CharType = 55;
m.Experience = 2500;
m.Speed = 320;
m.CurrentHP = 4000;
m.MaxHP = 4000;
m.Corpse = 32692;
m.Attack = 95;
m.Skill = 95;
m.Armor = 50;
m.Defense = 50;
m.MaxSummons = 0;
m.Immunities = new ImmunityType[] {
ImmunityType.IMMUNE_ELECTRIC,ImmunityType.IMMUNE_FIRE,ImmunityType.IMMUNE_POISON,
};
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 70),
new LootInfo(3458, 10000, false, 3),
new LootInfo(3405, 800, false, 1),
new LootInfo(2906, 2000, false, 1),
new LootInfo(3150, 7000, false, 1),
new LootInfo(4442, 688, false, 1),
new LootInfo(1868, 4000, false, 2),
new LootInfo(1628, 2000, true, 1),
new LootInfo(613, 6000, true, 1),
new LootInfo(642, 40000, true, 6),
new LootInfo(8284, 3000, true, 1),
new LootInfo(1099, 300, true, 1),
new LootInfo(1356, 100000, true, 40),
new LootInfo(10330, 15000, true, 1),
new LootInfo(1656, 400, true, 1),
new LootInfo(77, 3333, true, 1),
};
return m;
