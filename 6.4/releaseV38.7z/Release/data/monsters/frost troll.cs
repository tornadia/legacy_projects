Monster m = new Monster();
m.Name = "Frost Troll";
m.CurrentRace = Race.BLOOD;
m.CharType = 53;
m.Experience = 23;
m.Speed = 190;
m.CurrentHP = 55;
m.MaxHP = 55;
m.Corpse = 31924;
m.Attack = 11;
m.Skill = 19;
m.Armor = 7;
m.Defense = 9;
m.MaxSummons = 0;
m.LootContainer = 317;
m.Loot = new LootInfo[] {
new LootInfo(1356, 100000, false, 12),
new LootInfo(1626, 33333, false, 1),
new LootInfo(861, 10000, false, 1),
new LootInfo(378, 20000, false, 1),
new LootInfo(2138, 6666, true, 1),
new LootInfo(1922, 20000, true, 2),
};
return m;
