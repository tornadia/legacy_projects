            Monster m = new Monster();
            m.Name = "Troll";
            m.CurrentRace = Race.BLOOD;
            m.CharType = 15;
            m.Experience = 20;
            m.Speed = 126;
            m.CurrentHP = 50;
            m.MaxHP = 50;
            m.Corpse = 180;
            m.Attack = 10;
            m.Skill = 15;
            m.Armor = 6;
            m.Defense = 8;
            m.SummonCost = 290;
            m.Talk = new string[] {"Hmm, dogs", "Grrr", 
                "Groar", "Gruntz!", "Hmm, bugs."};
            m.Loot = new LootInfo[] {
                new LootInfo(1356, 100000, false, 10),
                new LootInfo(3418, 33333, false, 1),
                new LootInfo(888, 10000, false, 1),
                new LootInfo(1116, 20000, false, 1),
                new LootInfo(74, 23333, false, 1),
                new LootInfo(2893, 3333, false, 1),

                new LootInfo(861, 6666, true, 1),
                new LootInfo(642, 30000, true, 2),
                new LootInfo(1114, 10000, true, 1),
                new LootInfo(2381, 1428, true, 1)
            };
            m.LootContainer = 317;
            return m;