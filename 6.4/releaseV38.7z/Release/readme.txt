The file directory names should nor the .exe should be changed. The files are dynamically compiled
and allow maximize customization. However, the syntax isn't the nicest and most
easiest to use. I had the ability to change names on my TODO list but never got around to it.

For efficiency reasons, all the config files, monsters, spells etc. are compiled into .NET assembly 
code. Therefore, the server first checks if the assembly files exist. If you change any
of the files such as config, DELETE the asm folder in the same directory to make sure the server
loads the new changes. It was also on my TODO list to look at timestamps but I never got around
to finishing it.

To create an account, use Account Manager as the login name and leave the password blank.

Questions, comments, etc., please post on my otfans tibia 6.4 forum or send me a message
via sourceforge.


JOPIROP. ALL RIGHTS RESERVED.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.